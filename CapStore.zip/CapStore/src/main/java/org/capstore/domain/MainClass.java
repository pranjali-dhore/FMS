/*package org.capstore.domain;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class MainClass {
	AnnotationConfiguration config=new AnnotationConfiguration();
	config.addAnnotatedClass(Customer.class); 
	config.configure();
	
	new SchemaExport(config).create(true, true);
	
	//Session Factory
	SessionFactory factory= config.buildSessionFactory();
	
	//Session and Transaction
	Session session=factory.openSession();
	session.beginTransaction();
	session.save(student);
	session.save(student1);
	session.save(student2);
	session.save(student3);
	
	session.getTransaction().commit();
	
	
	
	}
}
*/