package org.capstore.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.capstore.domain.Customer;
import org.capstore.service.ICustomerService;
/*import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
*/
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CustomerController {


	private ICustomerService customerService;
	private Customer searchcustomer=null;

	@RequestMapping("/customerForm")
	public String showCustForm(Map<String, Object> maps){
		SimpleDateFormat myFormat=new SimpleDateFormat("dd-MMM-yyyy");
		List<Customer> customers= customerService.getAllCustomers();
		maps.put("cust",customers);
		maps.put("custSearch",searchcustomer);
		maps.put("customer",new Customer());
		
		if(searchcustomer!=null){
		maps.put("customer", searchcustomer);
		
		Date customer_regdate=searchcustomer.getCustomer_regdate();
	
			if(customer_regdate!=null)
			{		
					String regdate=myFormat.format(customer_regdate);
					maps.put("customer_regdate", regdate);
			}
			
		}
		 return "customer";
	}
	@RequestMapping(value={"/showCustomer","/updateEmployee"},method=RequestMethod.POST)
	public String showCustDetails(Map<String, Object> map,
			@Valid @ModelAttribute("cust") Customer customer, BindingResult result){
		List<Customer> customers= customerService.getAllCustomers();
		map.put("custs",customers);
		map.put("custSearch",searchcustomer);
		if(result.hasErrors()){
			//System.out.println("Search Object:" + searchEmployee);
			//System.out.println(result);
			return "customer";
		}
		else{
			searchcustomer=null;
			customerService.saveCustomer(customer);
			return "redirect:/customerForm";
		}
	}
	
	
	
}
