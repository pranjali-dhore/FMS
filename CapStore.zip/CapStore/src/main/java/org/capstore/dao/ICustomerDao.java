package org.capstore.dao;

import java.util.List;

import org.capstore.domain.Customer;

public interface ICustomerDao {

public void saveCustomer(Customer customer);
	
	public List<Customer> getAllCustomers();
	
	/*public void deleteEmployee(Integer employeeId);*/
	
	public Customer searchCustomer(Integer customer_id);

	
}
