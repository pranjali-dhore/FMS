package org.capstore.dao;

import java.util.List;

import org.capstore.domain.Customer;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class CustomerDaoImpl implements ICustomerDao{

	@Autowired(required=true)
	private SessionFactory sessionFactory;
	@Override
	public void saveCustomer(Customer customer) {
	
		sessionFactory.getCurrentSession().saveOrUpdate(customer);
	}
	@Override
	public List<Customer> getAllCustomers() {
		
		return sessionFactory.getCurrentSession().createQuery("from Customer").list();
	}
	@Override
	public Customer searchCustomer(Integer customer_id) {

		Customer Cust=(Customer) sessionFactory.getCurrentSession().get(Customer.class, customer_id);
		return Cust;
	}
	

}
