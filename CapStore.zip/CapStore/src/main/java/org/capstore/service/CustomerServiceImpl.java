package org.capstore.service;

import java.util.List;

import org.capstore.dao.ICustomerDao;
import org.capstore.domain.Customer;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CustomerServiceImpl implements ICustomerService {

		@Autowired(required=true)
		private ICustomerDao customerDao;
		
		@Transactional
	
		public void saveCustomer(Customer customer) {{
			customerDao.saveCustomer(customer);
		}
		
	}

		@Transactional
		public List<Customer> getAllCustomers() {
			return customerDao.getAllCustomers();
		}
		@Transactional
		public Customer searchCustomer(Integer customer_id) {
			
			return customerDao.searchCustomer(customer_id);
		}
		}


