package org.capstore.service;
import java.util.List;

import org.capstore.domain.Customer;
import org.springframework.stereotype.Service;

public interface ICustomerService {
	
	public void saveCustomer(Customer customer);
	
	public List<Customer> getAllCustomers();
/*	public void deleteEmployee(Integer employeeId);*/
	public Customer searchCustomer(Integer customer_id);
}
