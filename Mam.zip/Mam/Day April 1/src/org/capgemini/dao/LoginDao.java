package org.capgemini.dao;

import org.capgemini.pojo.Customer;
import org.capgemini.pojo.LoginUser;

public interface LoginDao {
	public boolean isValidLogin(LoginUser loginUser) ;
	public void saveCustomer(Customer customer);

}
