package org.capgemini.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ShowServlet
 */
public class ShowServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String uname=request.getParameter("userName");
		String uemail=request.getParameter("email");
		
		
		//Creates the session object
		HttpSession session=request.getSession();
		session.setAttribute("userName", uname);
		session.setAttribute("userEmail", uemail);
		
		//cookie
		
		Cookie usercookie=new Cookie("user", uname);
		Cookie emailcookie=new Cookie("uemail", uemail);
		
		
		usercookie.setMaxAge(30);
		response.addCookie(usercookie);
		response.addCookie(emailcookie);
		
		
	
		PrintWriter out=response.getWriter();
		out.println("<form method='get' action='DetailsServlet'>");
		out.println("User Name:" + uname);
		out.println("User Email:" + uemail);
		
		out.println("<input type='hidden' name='uemail' value='"+uemail+"'>" );
		out.println("<input type='submit' name='Next'>");
		out.println("</form>");
		
	}

}
