package org.capgemini.test.dao;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.capgemini.dao.EmployeeDao;
import org.capgemini.dao.EmployeeDaoImpl;
import org.capgemini.pojo.Employee;
import org.junit.Test;

public class DaoTesting {
	
	private EmployeeDao empDao=new EmployeeDaoImpl();

	@Test
	public void test() {
		
		assertTrue(true);
		
	}

}
