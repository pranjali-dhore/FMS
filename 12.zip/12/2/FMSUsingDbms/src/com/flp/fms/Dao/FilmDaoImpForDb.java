package com.flp.fms.Dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

import com.flp.fms.domain.Film;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;

public class FilmDaoImpForDb implements IFilmDao{

	private Map<Integer, Film> film_Repository=new HashMap<>();
	
	
	
	//ADDING LIST OF LANGUAGES
	@Override
	public List<Language> getOriginalLanguage() {
		List<Language>languages=new ArrayList<>();
		
		Connection con=getConnection();
		String sql="select * from LANGUAGE";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Language lang=new Language();
				lang.setLanguage_Id(rs.getInt(1));
				lang.setLanguage_Name(rs.getString(2));
				
				
				languages.add(lang);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return languages;
	}

	
	//ADDING LIST OF CATEGORIES
	@Override
	public List<Category> getCategory() {
		List<Category> category=new ArrayList<>();
		Connection con=getConnection();
		String sql="select * from CATEGORY";
		
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Category category1=new Category();
				category1.setCategory_Id(rs.getInt(1));
				category1.setCategory_Name(rs.getString(2));
				
				
				category.add(category1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return category;
	}
	
	//CRUD Operation
	    
	   //ADD FILM
		@Override
		public void addFilm(Film film) {
			//film_Repository.put(film.getFilm_Id(), film);
			
			
			
			
			Connection con=getConnection();
			String sql="insert into FILM(title,description,releaseYear,originalLanguage,rentalDuration,LENGTH,replacementCost,ratings,specialFeatures,category)"
					+ "	 values(?,?,?,?,?,?,?,?,?,?)";
			
			int count=0;
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				pst.setString(1, film.getTitle());
				pst.setString(2, film.getDescription());
				pst.setDate(3, new Date(film.getRealeaseYear().getTime()));
				int language=film.getOriginalLanguage().getLanguage_Id();
				pst.setInt(4, language);
				pst.setDate(5, new Date(film.getRentalDuration().getTime()));
				pst.setInt(6, film.getLength());
				pst.setDouble(7,film.getReplacementCost());
				
				pst.setInt(8,film.getRatings());
				pst.setString(9,film.getSpecialFeatures());
				int category=film.getCategory().getCategory_Id();
				pst.setInt(10,category);
				count=pst.executeUpdate();
				
				
				//Fetching last film id 
				String sql1="select filmid from FILM order by filmid desc limit 1 ";
				PreparedStatement pst1=con.prepareStatement(sql1);
				ResultSet rs=pst1.executeQuery();
				int film_id=0;
				while(rs.next())
				{
					film_id=rs.getInt(1);
					
				}
				
				
				//insert into film_languages
				String sql2="insert into film_language values(?,?)";
				PreparedStatement pst2=con.prepareStatement(sql2);
			     List<Language> lang=film.getLanguages();
			     System.out.println(lang);
				for(Language lang1:lang){
				pst2.setInt(1, film_id);
				pst2.setInt(2,lang1.getLanguage_Id());
			    count=pst2.executeUpdate();
				}
				
				String sql3="insert into film_actors values(?,?)";
				PreparedStatement pst3=con.prepareStatement(sql3);
			    List<Actor> actor=film.getActors();
				for(Actor act1:actor){
				pst3.setInt(1, film_id);
				pst3.setInt(2,act1.getActor_Id());
				 count=pst3.executeUpdate();
				}
				
				
				
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(film);
			//return count;
			
		}


		//LISTING FILM
		@Override
		public List<Film> getAllFilms() {
			
			Connection con=getConnection();
			List<Film> films=new ArrayList<>();
			String sql="select * from FILM";
			
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				ResultSet rs=pst.executeQuery();
				while(rs.next()){
					Film film=new Film();
					film.setFilm_Id(rs.getInt(1));
					film.setTitle(rs.getString(2));
					film.setDescription(rs.getString(3));
					film.setRealeaseYear(rs.getDate(4).valueOf(rs.getDate(4).toString()));
					//Original Language
					int lang_id=rs.getInt(5);
					Language orgLang=getOrgLang(lang_id);
					film.setOriginalLanguage(orgLang);
					
					//Rental Duration
					film.setRentalDuration(rs.getDate(6).valueOf(rs.getDate(6).toString()));
					
					//length
					film.setLength(rs.getInt(7));
					
					//replacementCost
					film.setReplacementCost(rs.getDouble(8));
					
					//rating
					film.setRatings(rs.getInt(9));
					
					//Special Features
					film.setSpecialFeatures(rs.getString(10));
					
					int category_id=rs.getInt(11);
					Category category=getCategoryforListing(category_id);
					film.setCategory(category);
					
					//other Lang
					List<Integer> lang_ids=getLanguagesIDs(film.getFilm_Id());
					List<Language> lang_name=new ArrayList<>();
					for(Integer langid:lang_ids){
						lang_name.add(getOrgLang(langid));
					}
					film.setLanguages(lang_name);
					
					//Actors
					
					
					List<Actor> act=new ArrayList<>();
					List<Integer> actor_id=getActorIDS(film.getFilm_Id());
					for(Integer actor:actor_id){
						act.add(getActors(actor));
					}
					film.setActors(act);
					films.add(film);
					
					
				}
				
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			
	
			return films;
		}
        
		
		//GET ACTORS NAME
		private Actor getActors(Integer actor) {
			Actor actor1=new Actor();
			Connection con=getConnection();
			String str="select * from ACTOR where actorID=?";
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setInt(1, actor);
				ResultSet rs=pst.executeQuery();
				while(rs.next()){
					actor1.setActor_Fname(rs.getString(2));
					actor1.setActor_Lname(rs.getString(3));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return actor1;
		}


		//GET ALL ACTORS IDS
		private List<Integer> getActorIDS(int film_Id) {
			Connection con=getConnection();
			List<Integer> actorids=new ArrayList<>();
			String str="select * from film_actors where film_id=?";
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setInt(1, film_Id);
				ResultSet rs=pst.executeQuery();
				
				
				while(rs.next()){
					actorids.add(rs.getInt(2));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return actorids;

		}


		//GET LANGUAGES IDS
		private List<Integer> getLanguagesIDs(int film_Id) {
			Connection con=getConnection();
			String str="select * from film_language where film_id=?";
			List<Integer> id=new ArrayList<>();
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setInt(1, film_Id);
				ResultSet rs=pst.executeQuery();
				
				
				while(rs.next()){
					id.add(rs.getInt(2));
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return id;
		}


		//GET CATEGORY
		private Category getCategoryforListing(int category_id) {
			Connection con=getConnection();
			Category category=new Category();
			String str="select * from CATEGORY where categoryID=?";
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setInt(1, category_id);
				ResultSet rs=pst.executeQuery();
				
				while(rs.next()){
					category.setCategory_Name(rs.getString(2));
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return category;
		}


		//GET ORIGINAL LANGUAGE
		private Language getOrgLang(int lang_id) {
			Language lang=new Language();
			Connection con=getConnection();
			String str="select * from LANGUAGE where languageID=?";
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setInt(1, lang_id);
				ResultSet rs=pst.executeQuery();
				
				while(rs.next()){
					lang.setLanguage_Name(rs.getString(2));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return lang;
		}


		

		//REMOVE FILM BY ID
		@Override
		public int removeFilmByID(int filmID) {
			
			Connection con=getConnection();
			int count=0;
			
			String str="delete from FILM where filmid=?";
			String str1="delete from film_language where film_id=?";
			String str2="delete from film_actors where film_id=?";
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setInt(1, filmID);
			    count=pst.executeUpdate();
			    
			    
			    
			    PreparedStatement pst1=con.prepareStatement(str1);
			    pst1.setInt(1, filmID);
			    count=pst1.executeUpdate();
			    
			    
			    PreparedStatement pst2=con.prepareStatement(str2);
			    pst2.setInt(1, filmID);
			    count=pst2.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			return count;
		}
		
		
		//REMOBE FILM BY TITLE
		public int removeFilmByTitle(String filmTitle) {

			Connection con=getConnection();
			int count=0;
			int filmID=0;
			String str="delete from FILM where title=?";
			String str3="select filmid from FILM where title=?";
			String str1="delete from film_language where film_id=?";
			String str2="delete from film_actors where film_id=?";
			try {
				PreparedStatement pst=con.prepareStatement(str);
				pst.setString(1, filmTitle);
			    count=pst.executeUpdate();
			    
			    PreparedStatement pst3=con.prepareStatement(str3);
			    pst3.setString(1, filmTitle);
			    ResultSet rs=pst3.executeQuery();
			    
			    while(rs.next())
			    {
			    	filmID=rs.getInt(1);
			    }
			    
			    PreparedStatement pst1=con.prepareStatement(str1);
			    pst1.setInt(1, filmID);
			    count=pst1.executeUpdate();
			    
			    
			    PreparedStatement pst2=con.prepareStatement(str2);
			    pst2.setInt(1, filmID);
			    count=pst2.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			return count;
		}
		
		
		//REMOVE BY RATING
	public int removeFilmByRating(int rating) {
		Connection con=getConnection();
		int count=0;
		int filmID=0;
		String str="delete from FILM where ratings=?";
		String str3="select filmid from FILM where ratings=?";
		String str1="delete from film_language where film_id=?";
		String str2="delete from film_actors where film_id=?";
		try {
			PreparedStatement pst=con.prepareStatement(str);
			pst.setInt(1, rating);
		    count=pst.executeUpdate();
		    
		    PreparedStatement pst3=con.prepareStatement(str3);
		    pst3.setInt(1, rating);
		    ResultSet rs=pst3.executeQuery();
		    
		    while(rs.next())
		    {
		    	filmID=rs.getInt(1);
		    }
		    
		    PreparedStatement pst1=con.prepareStatement(str1);
		    pst1.setInt(1, filmID);
		    count=pst1.executeUpdate();
		    
		    
		    PreparedStatement pst2=con.prepareStatement(str2);
		    pst2.setInt(1, filmID);
		    count=pst2.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return count;
		}

		
		//SEARCH FILM
		/*public Film searchFilm(int filmId1) {
			
			//Map<Integer, Film> filmList=getAllFilms();
			Collection<Film>filmList1=filmList.values();
			Film filmCurrent=new Film();
			boolean flag=false;
			for(Film film:filmList1)
			{
				if(filmId1==film.getFilm_Id())
				{
					System.out.println("Film is exists");
					System.out.println(film);
					filmCurrent=film;
					flag=true;
					break;
				}
			}
			
			return filmCurrent ;
		}

		*/
		//UPDATE FILM
		public int updateFilm(Film film1,int filmId) {
			 
			int  count=0;
			Connection con=getConnection();
			String sql="update FILM set title=?,description=?,releaseYear=?,originalLanguage=?,rentalDuration=?,LENGTH=?,replacementCost=?,ratings=?,specialFeatures=?,category=? where filmid=?";
			String sql1="delete from film_language where film_id=?";
			String sql4="delete from film_actors where film_id=?";
			
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				//pst.setString(1, film.getTitle());
				pst.setString(1, film1.getTitle());
				pst.setString(2, film1.getDescription());
				pst.setDate(3, new Date(film1.getRealeaseYear().getTime()));
				int language=film1.getOriginalLanguage().getLanguage_Id();
				pst.setInt(4, language);
				pst.setDate(5, new Date(film1.getRentalDuration().getTime()));
				pst.setInt(6, film1.getLength());
				pst.setDouble(7,film1.getReplacementCost());
				
				pst.setInt(8,film1.getRatings());
				pst.setString(9,film1.getSpecialFeatures());
				int category=film1.getCategory().getCategory_Id();
				pst.setInt(10,category);
				pst.setInt(11, filmId);
				
				count=pst.executeUpdate();
				
				
				//delete from film_language
				PreparedStatement pst1=con.prepareStatement(sql1);
				pst1.setInt(1, filmId);
			    count=pst1.executeUpdate();
			    
			  //delete from film_actors
				PreparedStatement pst4=con.prepareStatement(sql4);
				pst4.setInt(1, filmId);
			    count=pst4.executeUpdate();
			    
			    //insert into film_language
			
				String sql2="insert into film_language values(?,?)";
				PreparedStatement pst2=con.prepareStatement(sql2);
			     List<Language> lang=film1.getLanguages();
			     System.out.println(lang);
				for(Language lang1:lang){
				pst2.setInt(1, filmId);
				pst2.setInt(2,lang1.getLanguage_Id());
			    count=pst2.executeUpdate();
				}
			    
				String sql3="insert into film_actors values(?,?)";
				PreparedStatement pst3=con.prepareStatement(sql3);
			    List<Actor> actor=film1.getActors();
				for(Actor act1:actor){
				pst3.setInt(1, filmId);
				pst3.setInt(2,act1.getActor_Id());
				 count=pst3.executeUpdate();
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


			return count;
		}
	
		
		//CONNECTION CODE
		public Connection getConnection(){

			Connection connection=null;

			try {
				Class.forName("com.mysql.jdbc.Driver");
				connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/phase2fmsdatabase","root","Pass1234");


			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}



			return connection;
		}

		
		
		//SEARCH BY ID
		public Film getSearchFilmByID(int id) {
			Connection con=getConnection();
			Film film=null;
			String sql="select * from FILM where filmid=?";
			
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				pst.setInt(1, id);
				ResultSet rs=pst.executeQuery();
				while(rs.next()){
				 film=new Film();
				
				if(id==rs.getInt(1)){
					film.setFilm_Id(rs.getInt(1));
					film.setTitle(rs.getString(2));
					film.setDescription(rs.getString(3));
					film.setRealeaseYear(rs.getDate(4).valueOf(rs.getDate(4).toString()));
					//Original Language
					int lang_id=rs.getInt(5);
					Language orgLang=getOrgLang(lang_id);
					film.setOriginalLanguage(orgLang);
					
					//Rental Duration
					film.setRentalDuration(rs.getDate(6).valueOf(rs.getDate(6).toString()));
					
					//length
					film.setLength(rs.getInt(7));
					
					//replacementCost
					film.setReplacementCost(rs.getDouble(8));
					
					//rating
					film.setRatings(rs.getInt(9));
					
					//Special Features
					film.setSpecialFeatures(rs.getString(10));
					
					int category_id=rs.getInt(11);
					Category category=getCategoryforListing(category_id);
					film.setCategory(category);
					
					//other Lang
					List<Integer> lang_ids=getLanguagesIDs(film.getFilm_Id());
					List<Language> lang_name=new ArrayList<>();
					for(Integer langid:lang_ids){
						lang_name.add(getOrgLang(langid));
					}
					film.setLanguages(lang_name);
					
					//Actors
					
					
					List<Actor> act=new ArrayList<>();
					List<Integer> actor_id=getActorIDS(film.getFilm_Id());
					for(Integer actor:actor_id){
						act.add(getActors(actor));
					}
					film.setActors(act);
					/*films.add(film);*/
				}
					
				}
				
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			
			return film;
		}


		
		//UPDATE TITLE
		public int updateTitle(String title,int filmId) {
			
			int count=0;
			Connection con=getConnection();
			String sql="update FILM set title=? where filmid=?";
			
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				pst.setString(1, title);
				pst.setInt(2, filmId);
				
				count=pst.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return count;
		}


		//UPDATE RATING
		public int updateRating(int rating, int filmId1) {
			
			int count=0;
			Connection con=getConnection();
			String sql="update FILM set ratings=? where filmid=?";
			
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				pst.setInt(1, rating);
				pst.setInt(2, filmId1);
				
				count=pst.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return count;
		}



		//SEARCH BY RATING
		public List<Film> searchFilmByRating(int rating) {
			Connection con=getConnection();
			List<Film> films=new ArrayList<>();
			String sql="select * from FILM where ratings=?";
			
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				pst.setInt(1, rating);
				ResultSet rs=pst.executeQuery();
				while(rs.next()){
					Film film=new Film();
					film.setFilm_Id(rs.getInt(1));
					film.setTitle(rs.getString(2));
					film.setDescription(rs.getString(3));
					film.setRealeaseYear(rs.getDate(4).valueOf(rs.getDate(4).toString()));
					//Original Language
					int lang_id=rs.getInt(5);
					Language orgLang=getOrgLang(lang_id);
					film.setOriginalLanguage(orgLang);
					
					//Rental Duration
					film.setRentalDuration(rs.getDate(6).valueOf(rs.getDate(6).toString()));
					
					//length
					film.setLength(rs.getInt(7));
					
					//replacementCost
					film.setReplacementCost(rs.getDouble(8));
					
					//rating
					film.setRatings(rs.getInt(9));
					
					//Special Features
					film.setSpecialFeatures(rs.getString(10));
					
					int category_id=rs.getInt(11);
					Category category=getCategoryforListing(category_id);
					film.setCategory(category);
					
					//other Lang
					List<Integer> lang_ids=getLanguagesIDs(film.getFilm_Id());
					List<Language> lang_name=new ArrayList<>();
					for(Integer langid:lang_ids){
						lang_name.add(getOrgLang(langid));
					}
					film.setLanguages(lang_name);
					
					//Actors
					
					
					List<Actor> act=new ArrayList<>();
					List<Integer> actor_id=getActorIDS(film.getFilm_Id());
					for(Integer actor:actor_id){
						act.add(getActors(actor));
					}
					film.setActors(act);
					films.add(film);
					
					
				}
				
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			
	
			return films;
		}


		//SEARCH BY TITLE
		public Film searchFilmByTitle(String title) {
			Connection con=getConnection();
			Film film=new Film();
			String sql="select * from FILM where title=?";

			try {
				PreparedStatement pst=con.prepareStatement(sql);
				pst.setString(1, title);
				ResultSet rs=pst.executeQuery();
				while(rs.next()){

					film.setFilm_Id(rs.getInt(1));
					film.setTitle(rs.getString(2));
					film.setDescription(rs.getString(3));
					film.setRealeaseYear(rs.getDate(4).valueOf(rs.getDate(4).toString()));
					//Original Language
					int lang_id=rs.getInt(5);
					Language orgLang=getOrgLang(lang_id);
					film.setOriginalLanguage(orgLang);

					//Rental Duration
					film.setRentalDuration(rs.getDate(6).valueOf(rs.getDate(6).toString()));

					//length
					film.setLength(rs.getInt(7));

					//replacementCost
					film.setReplacementCost(rs.getDouble(8));

					//rating
					film.setRatings(rs.getInt(9));

					//Special Features
					film.setSpecialFeatures(rs.getString(10));

					int category_id=rs.getInt(11);
					Category category=getCategoryforListing(category_id);
					film.setCategory(category);

					//other Lang
					List<Integer> lang_ids=getLanguagesIDs(film.getFilm_Id());
					List<Language> lang_name=new ArrayList<>();
					for(Integer langid:lang_ids){
						lang_name.add(getOrgLang(langid));
					}
					film.setLanguages(lang_name);

					//Actors


					List<Actor> act=new ArrayList<>();
					List<Integer> actor_id=getActorIDS(film.getFilm_Id());
					for(Integer actor:actor_id){
						act.add(getActors(actor));
					}
					film.setActors(act);



				}



			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	return film;
		}


	


		
		
	

}
