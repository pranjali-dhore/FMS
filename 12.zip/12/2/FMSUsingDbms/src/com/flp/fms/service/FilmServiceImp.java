package com.flp.fms.service;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.fms.Dao.FilmDaoImpForDb;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmServiceImp implements IFilmService{

	
	//OBJECT OF DAO CLASS
	private FilmDaoImpForDb filmDao= new FilmDaoImpForDb();
	
	
	
	//LIST FOR ORIGINAL LANGUAGE
	@Override
	public List<Language> getLanguage() {
		return filmDao.getOriginalLanguage();
	}
	
	
	//LIST FOR CATEGORY
	@Override
	public List<Category> getCategory() {
		return filmDao.getCategory();
	}
	
	
	//ADD FILM
	@Override
	public void addFilm(Film film) {
		
		//film.setFilm_Id(generate_Film_Id());
		filmDao.addFilm(film);
		
	}
	
	//SEARCH FILM FOR UPDATE
	public Film getSearchFilmByID(int id) {
		
		return filmDao.getSearchFilmByID(id);
	}
	
	
	
	//LISTING FILM
	@Override
	public List<Film> getAllFilms() {

		return filmDao.getAllFilms();
	}
	
	
	
	
	
	
	//REMOVE FILM BY ID
	@Override
	public int removeFilmByID(int filmID) {
		// TODO Auto-generated method stub
		return filmDao.removeFilmByID(filmID);
	}
	
	
	//REMOVE BY TITLE
		@Override
		public int removeFilmByTitle(String filmTitle) {
			
			return filmDao.removeFilmByTitle(filmTitle);
		}


		//REMOVE BY RATING
		@Override
		public int removeFilmByRating(int rating) {
			// TODO Auto-generated method stub
			return filmDao.removeFilmByRating(rating);
		}
	
	
	
	/*public Film searchFilms(int filmId1) {
		// TODO Auto-generated method stub
		return filmDao.searchFilm(filmId1);
	}
	*/
	
	//UPDATE FILM
	@Override
	public int  updateFilm(Film film1,int filmId) {
		return filmDao.updateFilm(film1,filmId);
		
	}


	//UPDATE TITLE
	@Override
	public int updateTitle(String title,int filmId) {
		
		return filmDao.updateTitle(title,filmId);
	}


	//UPDATE RATING
	@Override
	public int updateRating(int rating, int filmId1) {
		
		return filmDao.updateRating(rating,filmId1);
	}


	//SEARCH BY ID
	@Override
	public Film searchFilmByID(int id) {
		// TODO Auto-generated method stub
		return filmDao.getSearchFilmByID(id);
	}


	@Override
	public List<Film> searchFilmByRating(int rating) {
		// TODO Auto-generated method stub
		return filmDao.searchFilmByRating(rating);
	}


	@Override
	public Film searchFilmByTitle(String title) {
		// TODO Auto-generated method stub
		return filmDao.searchFilmByTitle(title);
	}


	

}
