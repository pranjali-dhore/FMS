package com.flp.fms.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.flp.fms.domain.Actor;

public class ActorDaoImplForDb implements IActorDao{
	
	FilmDaoImpForDb filmDao=new FilmDaoImpForDb();

	@Override
	public List<Actor> getActorList() {
		List<Actor> actor=new ArrayList<>();
Connection con=filmDao.getConnection();
		
		String sql="select * from ACTOR";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Actor actor1=new Actor();
				actor1.setActor_Id(rs.getInt(1));
				actor1.setActor_Fname(rs.getString(2));
				actor1.setActor_Lname(rs.getString(3));
				actor.add(actor1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return actor;
	}

	@Override
	public List<Actor> addActor() {
		// TODO Auto-generated method stub
		return getActorList();
	}

}
