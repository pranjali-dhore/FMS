package com.flp.fms.service;

import java.util.List;

import com.flp.fms.Dao.ActorDaoImplForDb;
import com.flp.fms.domain.Actor;

public class ActorServiceImpl implements IActorService {
	
	ActorDaoImplForDb actorDao=new ActorDaoImplForDb();
	@Override
	public List<Actor> getActorList() {
		
		return actorDao.addActor();
	}
	@Override
	public List<Actor> addActor() {
		// TODO Auto-generated method stub
		return actorDao.getActorList();
	}

}
