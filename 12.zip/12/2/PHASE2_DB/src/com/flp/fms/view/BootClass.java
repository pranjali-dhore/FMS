package com.flp.fms.view;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.flp.fms.domain.Film;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImp;
import com.flp.fms.service.IFilmService;
import com.flp.fms.util.Validate;


public class BootClass {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int option;
		UserInteraction userInteraction=new UserInteraction();
		IFilmService filmservice=new FilmServiceImp();
		ActorServiceImpl actorServe=new ActorServiceImpl();
		do{
			menuSelection();
			System.out.println("Enter your option:[1-6]");
			option=sc.nextInt();
			switch(option){

			//ADDING FILM IN REPOSITORY
			case 1:
				Film film=userInteraction.addFilm(filmservice.getLanguage(),filmservice.getCategory(),actorServe.getActorList());
				filmservice.addFilm(film);
				break;

				//MODIFYING THE FILM FROM REPOSITORY
			case 2:
				int filmId1=userInteraction.readFilmId();

				Film film1=filmservice.getSearchFilmByID(filmId1);
				System.out.println("film:"+film1);

				if(film1==null)
					System.out.println("Film Not Present");

				else{
					String choice;
					do{

						modifyMenuSelection();
						System.out.println("Enter your option:[1-5]");
						option=sc.nextInt();

						switch(option){

						//BY TITLE
						case 1:
							System.out.println("Enter new title:");
							String title=sc.next();
							int count=filmservice.updateTitle(title,filmId1);
							if(count>0)
								System.out.println("Film updated successfully!!!");
							break;

							//BY RATING	
						case 2:
							System.out.println("Enter Rating:");
							int rating=sc.nextInt();
							int count1=filmservice.updateRating(rating,filmId1);
							if(count1>0)
								System.out.println("Film updated successfully!!!");

							break;


							//BY ALL FIELDS	
						case 3:
							Film film2=userInteraction.addFilm(filmservice.getLanguage(),filmservice.getCategory(),actorServe.getActorList());

							int count2=filmservice.updateFilm(film2,filmId1);
							if(count2>0)
								System.out.println("Film updated successfully!!!");
							break;


						case 4:
							break;

						}
						System.out.println("Wish to do more modification?[y|n]");
						choice=sc.next();
					}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');

				}
				break;


				//DELETE OPERATION
			case 3:
				String choice;
				do{
					deleteMenuSelection();
					System.out.println("Enter your choice: ");
					int opt1=sc.nextInt();

					switch(opt1){

					//DELETE BY ID
					case 1:
						System.out.println("Please enter film Id to delete: ");
						int filmId=sc.nextInt();
						//Film film1=filmservice.getSearchFilmByID(filmId);
						int count =filmservice.removeFilmByID(filmId);
						if(count>0)
							System.out.println("Film deleted successfully!!!");
						break;

						//DELETE BY TITLE
					case 2:
						System.out.println("Please enter film Title to delete: ");
						String filmTitle=sc.next();
						int count1=filmservice.removeFilmByTitle(filmTitle);
						if(count1>0)
							System.out.println("Film deleted successfully!!!");
						break;

						//DELETE BY RATING
					case 3:
						System.out.println("Please enter film Rating to delete: ");
						int rating=sc.nextInt();
						int count2=filmservice.removeFilmByRating(rating);
						if(count2>0)
							System.out.println("Film deleted successfully!!!");
						break;

					case 4:
						break;
					}
					System.out.println("Wish to do more deletion?[y|n]");
					choice=sc.next();
				}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');

				break;

				//SEARCH OPERATION
			case 4:

				searchMenuSelection();
				System.out.println("Choose your option:");
				option=sc.nextInt();
				do{
					switch(option){
					//SEARCH BY ID
					case 1:

						System.out.println("Enter film id to search:");
						int id=sc.nextInt();
						Film filmSer=filmservice.getSearchFilmByID(id);

						List<Film> filmser=new ArrayList<>();
						filmser.add(filmSer);
						userInteraction.getAllFilm(filmser);
						break;

						//SEARCH BY RATING
					case 2:
						System.out.println("Enter of what rating films are need to be search:");
						int rating=sc.nextInt();
						List<Film>filmrating=filmservice.searchFilmByRating(rating);
						userInteraction.getAllFilm(filmrating);

						break;


					case 3:
						System.err.println("Enter title for the film to search:");
						String title=sc.next();
						Film filmtitle=filmservice.searchFilmByTitle(title);
						List<Film> filmTitle1=new ArrayList<>();
						filmTitle1.add(filmtitle);
						userInteraction.getAllFilm(filmTitle1);


					}

					System.out.println("Wish to continue(y/Y)");
					choice=sc.next();

				}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');

				break;


				//LIST OPERATION
			case 5:
				List<Film>filmList=filmservice.getAllFilms();
				userInteraction.getAllFilm(filmList);
				break;

				//EXIT	
			case 6:
				System.exit(0);
			}
		}while(option<6);
	}

	//MAIN MENU
	public static void menuSelection(){
		System.out.println("1.Add Film");
		System.out.println("2.Modify Film");
		System.out.println("3.Remove Film");
		System.out.println("4.Search Film");
		System.out.println("5.GetAll Film");
		System.out.println("6.Exit");

	}


	//DELETE MENU
	public static void deleteMenuSelection(){

		System.out.println("1.Delete by ID");
		System.out.println("2.Delete by Title");
		System.out.println("3.Delete by Ratings");
		System.out.println("4.Exit");

	}


	//MODIFY MENU
	public static void modifyMenuSelection(){

		System.out.println("1.Modify by Title");
		System.out.println("2.Modify by Ratings");
		System.out.println("3.Modify All info");
		System.out.println("4.Exit");

	}

	public static void searchMenuSelection(){
		System.out.println("1.Search by ID");
		System.out.println("2.Search by rating");
		System.out.println("3.Search by Title");
	}
}
