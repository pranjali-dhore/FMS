package com.flp.fms.domain;

public class Actor {
private int Actor_Id;
private String Actor_FirstName;
private String Actor_LastName;
private int Film_id;

//No Argument Constructor
public Actor(){}

// Argument Constructor
public Actor(int actor_Id, String actor_FirstName, String actor_LastName, int film_id) {
	super();
	Actor_Id = actor_Id;
	Actor_FirstName = actor_FirstName;
	Actor_LastName = actor_LastName;
	Film_id = film_id;
}
// getter and setters
public int getActor_Id() {
	return Actor_Id;
}
public void setActor_Id(int actor_Id) {
	Actor_Id = actor_Id;
}
public String getActor_FirstName() {
	return Actor_FirstName;
}
public void setActor_FirstName(String actor_FirstName) {
	Actor_FirstName = actor_FirstName;
}
public String getActor_LastName() {
	return Actor_LastName;
}
public void setActor_LastName(String actor_LastName) {
	Actor_LastName = actor_LastName;
}
public int getFilm_id() {
	return Film_id;
}
public void setFilm_id(int film_id) {
	Film_id = film_id;
}
//ToString method
@Override
public String toString() {
	return "Actor [Actor_Id=" + Actor_Id + ", Actor_FirstName=" + Actor_FirstName + ", Actor_LastName=" + Actor_LastName
			+ ", Film_id=" + Film_id + "]";
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((Actor_FirstName == null) ? 0 : Actor_FirstName.hashCode());
	result = prime * result + Actor_Id;
	result = prime * result + ((Actor_LastName == null) ? 0 : Actor_LastName.hashCode());
	result = prime * result + Film_id;
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Actor other = (Actor) obj;
	if (Actor_FirstName == null) {
		if (other.Actor_FirstName != null)
			return false;
	} else if (!Actor_FirstName.equals(other.Actor_FirstName))
		return false;
	if (Actor_Id != other.Actor_Id)
		return false;
	if (Actor_LastName == null) {
		if (other.Actor_LastName != null)
			return false;
	} else if (!Actor_LastName.equals(other.Actor_LastName))
		return false;
	if (Film_id != other.Film_id)
		return false;
	return true;
}


}