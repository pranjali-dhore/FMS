package com.flp.fms.dao;

import java.util.HashSet;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.film;

public class ActorDaoImplForList implements IActorDao {
@Override
public Set<Actor> getActor() {
	Set<Actor> actors=new HashSet<>();
	film fm = new  film();
	actors.add(new Actor(101,"Salman","Khan",fm.getFilm_id()));
	actors.add(new Actor(102,"Sharuk","Khan",fm.getFilm_id()));
	actors.add(new Actor(103,"Kamal","Hasan",fm.getFilm_id()));
	actors.add(new Actor(104,"Hritik","Roshan",fm.getFilm_id()));
	actors.add(new Actor(105,"Sunny","Deol",fm.getFilm_id()));
	actors.add(new Actor(106,"Amir","Khan",fm.getFilm_id()));
	actors.add(new Actor(107,"Ranvir","Singh",fm.getFilm_id()));
	actors.add(new Actor(108,"Ranbir","Kapoor",fm.getFilm_id()));
	actors.add(new Actor(109,"Siddharth","Malhotra",fm.getFilm_id()));
	actors.add(new Actor(110,"Irfan","Khan",fm.getFilm_id()));
	
	return actors;
	
}
}
