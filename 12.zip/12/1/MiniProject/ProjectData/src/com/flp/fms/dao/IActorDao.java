package com.flp.fms.dao;


import java.util.List;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Language;

public interface IActorDao {
	public Set<Actor> getActor();
}
