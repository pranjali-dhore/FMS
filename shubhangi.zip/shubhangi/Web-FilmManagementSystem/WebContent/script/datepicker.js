/**
 * 
 */


   $(function() {
    $( "#datepicker" ).datepicker();
    
  });


   $(function() {
	    $( "#datepicker1" ).datepicker();
	    
	  });
