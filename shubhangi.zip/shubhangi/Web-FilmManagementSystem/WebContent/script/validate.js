/**
 * 
 */

function validateField()
{
	var filmtitle=addfilm.filmtitle.value;
	var flag=true;
	
	var letters=/^[A-Za-z]+$/;
	
		if(filmtitle.match(letters))
			{
				document.getElementById("titleError").innerHTML="";
				return true;
			}
		else
			{
			document.getElementById("titleError").innerHTML="*please enter correct Filmtitle ";
			filmtitle.focus();
			return false;
			}
	
	return flag;
	
}

function validateDescription()
{
	var desc = addfilm.filmdescription.value;

	var letters = /^[A-Za-z]+$/;  
	if(desc.match(letters))  
	{  
		document.getElementById("descerror").innerHTML="";
		return true;  
	}  
	else  
	{  
		document.getElementById("descerror").innerHTML="*Description should not be Null"; 
		desc.focus();  
		return false;  
	}  
}




function validatefilmDuration()
{
	var filmDuration=addfilm.filmduration.value;
	
	if(filmDuration>0 && filmDuration<1000)
		{
		document.getElementById("durationError").innerHTML="";
		return true;
		}
	else
		{
		document.getElementById("durationError").innerHTML="*please enter film duration between 0-1000 minutes";
		return false;
		}
	
}

function validateRentalDuration()
{

	var rentalDurartionDate=addfilm.rentaldate.value;
	var releaseDate=addfilm.releasedate.value;
	
	if(rentalDurartionDate>releaseDate)
		{
		document.getElementById("rentalError").innerHTML="";
		return true;
		}
	else
		{
		document.getElementById("rentalError").innerHTML="*please enter rental duration date greater than released date";
		return false;
		}
	
	
}






