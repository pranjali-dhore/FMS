package com.flp.fms.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.flp.fms.dao.ActorDaoimplForList;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.domain.Actor;

public class ActorServiceimpl implements IActorService {

	private IActorDao actorDao=new ActorDaoimplForList();
		
		@Override
		public List<Actor> getActors() {
			
			return actorDao.getActors();
		}
	

	
		
}
