package com.flp.fms.dao;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public interface IFilmDao {

	
	public List<Language> getLanguages();
	public List<Category> getCategory();
	public void addFilm(Film film);
	//public Map<Integer, Film> getallFilms();
	public Connection getConnection();
	
	public void saveFilm(Film film);
	ArrayList<Film> getAllfilms();
	public boolean deleteFilms(int film_id);
	ArrayList<Film> searchFilm(Film film);
	
	void modifyFilm(Film film);
	
}
