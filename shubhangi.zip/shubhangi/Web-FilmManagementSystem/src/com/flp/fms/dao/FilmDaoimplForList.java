package com.flp.fms.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.sql.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmDaoimplForList implements IFilmDao {
	
	private Map<Integer, Film> film_repository=new HashMap<>();
	
public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/fms","root","Pass1234");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return connection;
	}

	@Override
	public List<Language> getLanguages() {
		List<Language> languages=new ArrayList<>();
		
		
		
Connection con=getConnection();
		
		String sql="select * from languages";
		
		try {
			Statement stmt=con.createStatement();
			
			ResultSet rs=stmt.executeQuery(sql);
			
			while(rs.next()){
				
				languages.add(new Language(rs.getInt(1), rs.getString(2)));
				}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return languages;
	}
		


	@Override
	public List<Category> getCategory() {
		List<Category> cat=new ArrayList<>();
		
		Connection con=getConnection();
		
		String sql="select * from category";
		
		try {
			Statement stmt=con.createStatement();
			
			ResultSet rs=stmt.executeQuery(sql);
			
			while(rs.next()){
				
				cat.add(new Category(rs.getInt(1), rs.getString(2)));
				
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
		
		
		
		return cat;
	}

	@Override
	public void addFilm(Film film) {
		film_repository.put(film.getFilm_Id(), film);
		
	}


	

	@Override
	public void saveFilm(Film film) {
		Connection con=getConnection();
		
		String sql="insert into film(title,description,releaseYear,originalLanguage,rentalDuration,film_length,replacementCost,ratings,specialFeatures,category)"
				+ "values(?,?,?,?,?,?,?,?,?,?)";
		
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
		
			pst.setString(1, film.getTitle());
			pst.setString(2, film.getDescription());
			pst.setDate(3, new Date(film.getRelease_Year().getTime()));
			pst.setInt(4, film.getOriginal_Language().getLanguage_Id());
			pst.setDate(5, new Date(film.getRental_Duration().getTime()));
			pst.setInt(6, film.getFilmLength());
			pst.setDouble(7, film.getReplacement_Cost());
			pst.setInt(8, film.getRatings());
			pst.setString(9, film.getSpecial_Features());
			pst.setInt(10, film.getCategory().getCategory_Id());
			
			
			int count=pst.executeUpdate();
			storeActors(film);
			storeLanguages(film);
		
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	

	public int retrieveFilmId(){
		Connection con=getConnection();
		int film_id=0;
		
		String sql="select film_id from film order by film_id desc limit 1";
		
		try {
			Statement stmt=con.createStatement();
			
			ResultSet rs=stmt.executeQuery(sql);
			
			while(rs.next()){
				
				film_id=rs.getInt(1);
				
			}
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("fid:"+film_id);
		return film_id;
	}
	
	public void storeLanguages(Film film){
		Connection con=getConnection();
		
		String sql="insert into film_language(film_id,language_id)"
				                          +"values(?,?)";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			List<Language> langs=film.getLanguages();
			Iterator<Language> itr= langs.iterator();
		
			while(itr.hasNext()){
			pst.setInt(1, retrieveFilmId());
			int langid=itr.next().getLanguage_Id();
			pst.setInt(2, langid);
			int count=pst.executeUpdate();
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void storeActors(Film film){
		Connection con=getConnection();
		
		System.out.println("StoreActors");
		
		String sql="insert into film_actors(film_id,actor_id)"
				+ "values(?,?)";
		try {
			System.out.println("Storeactors try block");
			PreparedStatement pst=con.prepareStatement(sql);
			List<Actor> actors=film.getActors();
			ListIterator<Actor> litr=actors.listIterator();
			//Iterator<Actor> itr= actors.iterator();
			
			
			for(Actor act:actors)
			{
				System.out.println("Storeactors while loop");
				pst.setInt(1, retrieveFilmId());
				int actid=act.getActor_Id();
				pst.setInt(2, actid);
				int count=pst.executeUpdate();
			}
			
			
			/*while(litr.hasNext())
			{
			System.out.println("Storeactors while loop");
			pst.setInt(1, retrieveFilmId());
			int actid=litr.next().getActor_Id();
			pst.setInt(2, actid);
			int count=pst.executeUpdate();
			}
			*/
			
			System.out.println("Storeactors outside while loop");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Override
	public ArrayList<Film> getAllfilms() {
		Connection con=getConnection();	
		ArrayList<Film> films=new ArrayList<Film>();
		 String sql="select * from film";
		 
			try {
				PreparedStatement pst=(PreparedStatement) con.prepareStatement(sql);
				ResultSet rs=pst.executeQuery();
				while(rs.next())
				{
					Film film=new Film();
					film.setFilm_Id(rs.getInt(1));
					
					film.setTitle(rs.getString(2));
					
					film.setDescription(rs.getString(3));
				
					film.setRelease_Year(rs.getDate(4));
					
					
					
					
					
					
					String subsql;
					subsql="select language_name from languages where language_Id="+rs.getInt(5);
					PreparedStatement pst1=con.prepareStatement(subsql);
					ResultSet rs3=pst1.executeQuery();
					Language lang=new Language();
					if(rs3.next())
					{
						lang.setLanguage_Id(rs.getInt(5));
						lang.setLanguage_Name(rs3.getString(1));
					}
					film.setOriginal_Language(lang);
					
					
					
					
					
					
					
					film.setRental_Duration(rs.getDate(6));
					
					film.setFilmLength(rs.getInt(7));
					
					film.setReplacement_Cost(rs.getInt(8));
					
					film.setRatings(rs.getInt(9));
					
					

					film.setSpecial_Features(rs.getString(10));
					
					subsql="select category_name from category where category_id="+rs.getInt(11);
					PreparedStatement pst3=con.prepareStatement(subsql);
				    rs3=pst3.executeQuery();
					if(rs3.next())
					{
						Category cat=new Category();
						cat.setCategory_Id(rs.getInt(11));
						cat.setCategory_Name(rs3.getString(1));
						film.setCategory(cat);
					}
					
					subsql="select language_id from film_language where film_id="+rs.getInt(1);
					System.out.println(rs.getInt(1));
					pst3=con.prepareStatement(subsql);
				    rs3=pst3.executeQuery();
				    List<Language> languages=new ArrayList<>();
					while(rs3.next())
					{
												
						String subsql1="select language_name from languages where language_id="+rs3.getInt(1);
						PreparedStatement pst2=con.prepareStatement(subsql1);
						ResultSet rs1=pst2.executeQuery();
						while(rs1.next()){
							Language langs=new Language();
							langs.setLanguage_Id(rs3.getInt(1));
							langs.setLanguage_Name(rs1.getString(1));
							languages.add(langs);
							
						}
					}
					film.setLanguages(languages);
					
					
					subsql="select Actor_id from film_actors where film_id="+rs.getInt(1);
				
					pst3=con.prepareStatement(subsql);
				    rs3=pst3.executeQuery();
				   List<Actor> actors=new ArrayList<>();
					while(rs3.next())
					{
						String subsql1="select firstName,lastName from actors where actor_id="+rs3.getInt(1);
						PreparedStatement pst2=con.prepareStatement(subsql1);
						ResultSet rs1=pst2.executeQuery();
						while(rs1.next()){
							Actor actr=new Actor();
							actr.setActor_Fname(rs1.getString(1));
							actr.setActor_Lname(rs1.getString(2));
							actr.setActor_Id(rs3.getInt(1));
							actors.add(actr);
							
						}
					}
					film.setActors(actors);
					film.setLanguages(languages);
					System.out.println(film);
					films.add(film);
					
					
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return films;
	}
	
	public boolean deleteFilms(int film_id)
	{
		Connection con=getConnection();
		
		boolean flag=false;
		
		String sql="delete from film where film_id=?";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setInt(1, film_id);
			
			
			int count=pst.executeUpdate();
			
			if(count>0)
				flag=true;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return flag;
		
	}
	
	
	
	@Override
	public ArrayList<Film> searchFilm(Film film) 
	{
		Connection con=getConnection();
		int count=0;
		String sql="select * from film where";

        ArrayList<Film> films=new ArrayList<Film>();
		System.out.println(film);
		if(film!=null)
		{
			if(film.getFilm_Id()>0)
			{
				
				sql+=" film_id="+film.getFilm_Id();
				
				count=1;
			}
			
			if(film.getTitle()!=null)
			{
				if(count==1)
				{
					sql+=" and Title='"+film.getTitle()+"'";
				}
				else
				{
					sql+=" Title='"+film.getTitle()+"'";
				}
				count=2;
			}
		

			if(film.getRatings()>0)
			{
				if(count==1||count==2)
				{
					sql+=" and ratings="+film.getRatings();
				}
				else
				{
					sql+=" ratings="+film.getRatings();
				}
				count=3;
			}
			if(film.getActors()!=null)
			{
				Actor actor=new Actor();
				List<Actor> act=film.getActors();
				for(Actor a:act)
					actor=a;
				if(count==1||count==2||count==3)
				{
					sql+=" and film_id In(Select film_id from film_actors where actor_id="+actor.getActor_Id()+")";
					
				}else
				{
				sql+=" film_id In(Select film_id from film_actors where actor_id="+actor.getActor_Id()+")";
				}
				count=4;
			}
			if(film.getLanguages()!=null)
			{
				Language lang=new Language();
				List<Language> langs=film.getLanguages();
			
				for(Language l:langs)
					lang=l;
				if(count==1||count==2||count==3||count==4)
				{
					sql+=" and( film_id In(Select film_id from film_language where language_id="+lang.getLanguage_Id()+") or film_id In( Select film_id from film where OriginalLanguage="+lang.getLanguage_Id()+"))";
					
				}else
				{
				sql+=" ( film_id In(Select film_id from film_language where language_id="+lang.getLanguage_Id()+") or film_id In (Select film_id from film where OriginalLanguage="+lang.getLanguage_Id()+"))";
				
				}
				count=5;
			}
		
			 
			if(film.getRelease_Year()!=null)
			{
				if(count==1||count==2||count==3||count==4||count==5)
				{
					sql+=" releaseYear='"+new java.sql.Date(film.getRelease_Year().getTime())+"'";
				}
				else
				{
					sql+=" releaseYear='"+new java.sql.Date(film.getRelease_Year().getTime())+"'";
				}
				count=6;
			}
			System.out.println(sql);
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				ResultSet rs=pst.executeQuery();
			
				while(rs.next())
				{
					Film film1=new Film();
					film1.setFilm_Id(rs.getInt(1));
					film1.setDescription(rs.getString(3));
					film1.setTitle(rs.getString(2));
					film1.setRelease_Year(rs.getDate(4));
					
					String subsql;
					subsql="select language_name from languages where language_id="+rs.getInt(5);
					PreparedStatement pst1=con.prepareStatement(subsql);
					ResultSet rs3=pst1.executeQuery();
					Language lang=new Language();
					if(rs3.next())
					{
						lang.setLanguage_Id(rs.getInt(5));
						lang.setLanguage_Name(rs3.getString(1));
					}
					film1.setOriginal_Language(lang);
					film1.setRental_Duration(rs.getDate(6));
					film1.setFilmLength(rs.getInt(7));
					film1.setReplacement_Cost(rs.getInt(8));
					film1.setRatings(rs.getInt(9));
					film1.setSpecial_Features(rs.getString(10));
					
					subsql="select category_name from category where category_id="+rs.getInt(11);
					PreparedStatement pst3=con.prepareStatement(subsql);
				    rs3=pst3.executeQuery();
					if(rs3.next())
					{
						Category cat=new Category();
						cat.setCategory_Id(rs.getInt(11));
						cat.setCategory_Name(rs3.getString(1));
						film1.setCategory(cat);
					}
					
					subsql="select language_id from film_language where film_id="+rs.getInt(1);
					System.out.println(rs.getInt(1));
					pst3=con.prepareStatement(subsql);
				    rs3=pst3.executeQuery();
				    List<Language> languages=new ArrayList<>();
					while(rs3.next())
					{
												
						String subsql1="select language_name from languages where language_id="+rs3.getInt(1);
						PreparedStatement pst2=con.prepareStatement(subsql1);
						ResultSet rs1=pst2.executeQuery();
						while(rs1.next()){
							Language langs=new Language();
							langs.setLanguage_Id(rs3.getInt(1));
							langs.setLanguage_Name(rs1.getString(1));
							languages.add(langs);
							
						}
					}
					film1.setLanguages(languages);
					subsql="select Actor_id from film_actors where film_id="+rs.getInt(1);
				
					pst3=con.prepareStatement(subsql);
				    rs3=pst3.executeQuery();
				    List<Actor> actors=new ArrayList<>();
					while(rs3.next())
					{
						String subsql1="select firstName,lastName from actors where actor_id="+rs3.getInt(1);
						PreparedStatement pst2=con.prepareStatement(subsql1);
						ResultSet rs1=pst2.executeQuery();
						while(rs1.next()){
							Actor actr=new Actor();
							actr.setActor_Fname(rs1.getString(1));
							actr.setActor_Lname(rs1.getString(2));
							actr.setActor_Id(rs3.getInt(1));
							actors.add(actr);
							
						}
					}
					film1.setActors(actors);
					film1.setLanguages(languages);
					System.out.println(film1);
					films.add(film1);
			} }catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			
		}
		System.out.println(films);
		return films;
	}

	//To update films
	
	@Override
	public void modifyFilm(Film film) {
		 Connection con=getConnection();
			
			String sql="UPDATE film set title='"+film.getTitle()+"',description='"+film.getDescription()
						+"',releaseYear='"+new java.sql.Date(film.getRelease_Year().getTime())+
					"',originalLanguage='"+film.getOriginal_Language().getLanguage_Id()
					+"',rentalDuration='"+new java.sql.Date(film.getRental_Duration().getTime())
					+"',film_length="+film.getFilmLength()+",replacementCost="+film.getReplacement_Cost()
					+ ",ratings="+film.getRatings()+",specialFeatures='"+film.getSpecial_Features()
					+"',category='"+film.getCategory().getCategory_Id()
					+ "' where film_id="+ film.getFilm_Id();
			System.out.println(sql);
			
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				
				int count=pst.executeUpdate();
				List<Language> langs=film.getLanguages();
				//Iterator<Language> itr= langs.iterator();
				
			
    /*
				while(itr.hasNext()){
					String sql1="UPDATE film_language set language_id="+itr.next().getLanguage_Id()
							+"where film_id="+ film.getFilm_Id();
					
				PreparedStatement pst1=con.prepareStatement(sql1);
				//count=pst1.executeUpdate();
				System.out.println(sql1);
				}*/
				
				for(Language lan:langs)
				{
					String sql1="UPDATE film_language set language_id="+lan.getLanguage_Id()
							+" where film_id="+ film.getFilm_Id();
					System.out.println(sql1);
					//PreparedStatement pst1=con.prepareStatement(sql1);
					PreparedStatement pst1=con.prepareStatement(sql1);
					
					count=pst1.executeUpdate();
					System.out.println(sql1);
				}
				

				
				List<Actor> actors=film.getActors();
				Iterator<Actor> itr2= actors.iterator();
				
				while(itr2.hasNext()){
					String sql2="UPDATE film_actors set actor_id="+itr2.next().getActor_Id()
							+" where film_id="+ film.getFilm_Id();
					
					PreparedStatement pst2=con.prepareStatement(sql2);

					count=pst2.executeUpdate();
					System.out.println(sql2);
				}

				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		
	}
	
	
	
	
	
	
	
}
