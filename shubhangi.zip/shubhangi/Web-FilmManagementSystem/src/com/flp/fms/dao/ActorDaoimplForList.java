package com.flp.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.flp.fms.domain.Actor;

public class ActorDaoimplForList implements IActorDao {

	@Override
	public List<Actor> getActors() {
		
		IFilmDao filmdao=new FilmDaoimplForList();
		Connection con=filmdao.getConnection();
		
		
		List<Actor> actors=new ArrayList<Actor>();
		
	   String sql="SELECT * FROM actors";
		
	   try {
		PreparedStatement pst=con.prepareStatement(sql);
	
		ResultSet rs=pst.executeQuery();
		
		while(rs.next())
		{
			actors.add(new Actor(rs.getInt(1), rs.getString(2),rs.getString(3)));
		}
	   
	   
	   
	   } catch (SQLException e) {
		
		e.printStackTrace();
	}
		
		
		
		/*actors.add(new Actor(1,"Shahrukh","Khan"));
		actors.add(new Actor(2,"Salman","Khan"));
		actors.add(new Actor(3,"Shahid","Kapoor"));
		actors.add(new Actor(4,"Hritik","Roshan"));
		actors.add(new Actor(5,"Aamir","Khan"));
		actors.add(new Actor(6,"Ranbir","Kapur"));*/
		
		return actors;
	}

}
