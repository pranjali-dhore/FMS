package com.flp.fms.domain;

public class Actor {

	//private fields
	private int actor_Id;
	private String actor_Fname;
	private String actor_Lname;
	
	//no argument constructor
	public Actor()
	{
		
	}
	
	//constructor with fields
	public Actor(int actor_Id,String actor_Fname,String actor_Lname)
	{
		this.actor_Id=actor_Id;
		this.actor_Fname=actor_Fname;
		this.actor_Lname=actor_Lname;
	}
	
	//public getters and setters..
	public int getActor_Id() {
		return actor_Id;
	}
	public void setActor_Id(int actor_Id) {
		this.actor_Id = actor_Id;
	}
	public String getActor_Fname() {
		return actor_Fname;
	}
	public void setActor_Fname(String actor_Fname) {
		this.actor_Fname = actor_Fname;
	}
	public String getActor_Lname() {
		return actor_Lname;
	}
	public void setActor_Lname(String actor_Lname) {
		this.actor_Lname = actor_Lname;
	}
	
	//overridden toString() method.
	@Override
	public String toString() {
		return "Actor [actor_Id=" + actor_Id + ", actor_Fname=" + actor_Fname + ", actor_Lname=" + actor_Lname + "]";
	}
	
	
}
