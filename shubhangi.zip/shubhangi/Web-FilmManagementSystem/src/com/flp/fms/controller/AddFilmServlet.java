package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceimpl;
import com.flp.fms.service.FilmServiceimpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class AddFilmServlet
 */
public class AddFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		//ArrayList<Film> film=
		
		
		
		IActorService actorservice=new ActorServiceimpl();
		IFilmService filmservice=new FilmServiceimpl();
		
		List<Actor> actor= actorservice.getActors(); 
		
		List<Language> languages=filmservice.getLanguages();
		List<Category> category=filmservice.getCategory();
				
		PrintWriter out=response.getWriter();
		
		out.println("<html>");
		out.println("<head><title>Add film</title>"
				+"<script type='text/javascript' src='script/validate.js'></script>"
				+"<link rel='stylesheet' href='//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css'>"
				+"<script src='//code.jquery.com/jquery-1.10.2.js'></script>"
				+"<script src='//code.jquery.com/ui/1.11.4/jquery-ui.js'></script>"
				+"<script type='text/javascript' src='script/datepicker.js'></script>"
				+"</head>"
				+"<body bgcolor='peachpuff'><form name='addfilm' method='get' action='SaveFilmServlet'>"
				+"<h3>Film Registration Form</h3>"
				+"<table>"
				
				+"<tr><td>Film Title:</td>"
				+"<td><input type='text' name='filmtitle' size='20' onmouseout='return validateField()'>"
				+"<div id='titleError'></div>"
				+"</td></tr>"	
				
				+"<tr><td>Description:</td>"
				+"<td><textarea name='filmdescription' rows='4' cols='25' onmouseout='return validateDescription()'></textarea></td>"
				+"<td><div id='descerror'></div></td></tr>"
				
				+"<tr><td>Release Date:</td>"
				+"<td><input type='text' name='releasedate' size='20' id='datepicker'></td></tr>"
				
				+"<tr><td>Rental Duration:</td>"
				+"<td><input type='text' name='rentaldate' size='20' id='datepicker1'  onmouseout='return validateRentalDuration()' ></td>"
				+"<td><div id='rentalError'></div></td></tr>"
				
				
				+"<tr><td>Film Duration:</td>"
				+"<td><input type='text' name='filmduration' size='20' onmouseout='return validatefilmDuration()'></td>"
				+"<td><div id='durationError'></div></td></tr>"
				
				
				+"<tr><td>Replacement Cost:</td>"
				+"<td><input type='text' name='filmreplacementcost' size='20'></td></tr>"
				
				+"<tr><td>Ratings</td>"
				+"<tr><td><input type='radio' name='ratings' value='1'>1</td></tr>"
				+"<tr><td><input type='radio' name='ratings' value='2'>2</td></tr>"
				+"<tr><td><input type='radio' name='ratings' value='3'>3</td></tr>"
				+"<tr><td><input type='radio' name='ratings' value='4'>4</td></tr>"
				+"<tr><td><input type='radio' name='ratings' value='5'>5</td></tr>"
				+"</tr>"
				
				+"<tr><td>Special Features:</td>"
				+"<td><textarea rows='4' name='filmspecialfeatures' cols='25'></textarea>"
				+"</td></tr>"
				);

//category of film		
		out.println("<tr><td>CATEGORY:</td>"
				+ "<td>"
				+ "<select name='category'>");
		for(Category cat:category)
		{
			out.println("<option value='"+cat.getCategory_Id()+"'>"+
										  cat.getCategory_Id()+" "+
										  cat.getCategory_Name()+
										  "</option>");
		}
		out.println("</select></td></tr>");
		
				
//actor
		
				out.println("<tr><td>Actor</td>"
						+ "<td><select name='actor' multiple=' '>");
				for(Actor actor1:actor)
				{
				out.print("<option value='"+actor1.getActor_Id()+"'>"+
											actor1.getActor_Id()+" "+
											actor1.getActor_Fname()+" "+
											actor1.getActor_Lname()+
											"</option>");	
				}
				out.println("</select></td></tr>");
					
//original language
					
				out.println("<tr><td>Original Language:</td>"
						+ "<td>"
						+ "<select name='language'>");
				for(Language lang1:languages)
				{
					out.println("<option value='"+lang1.getLanguage_Id()+"'>"+
												   lang1.getLanguage_Id()+" "+
												   lang1.getLanguage_Name()+"</option>");
				}
						
				out.println("</select></td></tr>");
				
//list of other languages				
				
				out.println("<tr><td>Other Languages:</td>"
						+ "<td>"
						+ "<select name='languages' multiple=' '>");
				for(Language lang2:languages)
				{
					out.println("<option value='"+lang2.getLanguage_Id()+"'>"+
													lang2.getLanguage_Id()+" "+
													lang2.getLanguage_Name()+
													"</option>");
				}
				
				out.println("</select></td></tr>");		
						
				out.println("<tr>"
						+ "<td></td>"
						+ "	<td><input type='submit' value='Save'>"
						+ "<input type='reset' value='Clear'>"
						+ "</td></tr>"
						+ "</table></form></body></html>"					
						);		
						
		}

}
