package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceimpl;
import com.flp.fms.service.FilmServiceimpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class ModifyPageServlet
 */
public class ModifyPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		IFilmService film_service=new FilmServiceimpl ();
		List<Film> films=film_service.getAllfilms();
		
	
	PrintWriter out=response.getWriter();
		
		out.println("<html>");
		out.println("<head></head>"
				+ "<body bgcolor='peachpuff'>"
				+"<h1 align='center'>Film Details</h1>"
				+ "<div style='margin-left:500px;'><br>"
				+"</br> </div>"
				+ "<table border='1'>"
				+ "<tr>"
				+ "<th>Film Id</th>"
				+ "<th>Title</th>"
				+ "<th>Category</th>"
				+ "<th>Description</th>"
				+ "<th>Release Year</th>"
				+ "<th>Rental Duration</th>"
				+ "<th>Original Language</th>"
				+ "<th>Other Languages</th>"
				+ "<th>Length</th>"
				+ "<th>Replacement Cost</th>"
				+ "<th>Ratings</th>"
				+ "<th>Special Feature</th>"
				+ "<th>Actors</th>"
				+ "</tr>");
		List<Actor> actors=new ArrayList<>();
		List<Language> lang=new ArrayList<>();
			for(Film film:films){
				out.println("<tr>");
				out.println("<td>"+film.getFilm_Id()+"</td>");
				out.println("<td>"+film.getTitle()+"</td>");
				out.println("<td>"+film.getCategory().getCategory_Name()+"</td>");
				out.println("<td>"+film.getDescription()+"</td>");
				out.println("<td>"+film.getRelease_Year()+"</td>");
				out.println("<td>"+film.getRental_Duration()+"</td>");
				out.println("<td>"+film.getOriginal_Language().getLanguage_Name()+"</td>");
				
				lang=film.getLanguages();
				out.println("<td>");
				for(Language lan:lang)
				{
					out.println(lan.getLanguage_Name());
				}
				out.println("</td>");
			//	out.println("<td>"+film.getLanguages()+"</td>");
				out.println("<td>"+film.getFilmLength()+"</td>");
				out.println("<td>"+film.getReplacement_Cost()+"</td>");
				out.println("<td>"+film.getRatings()+"</td>");
				out.println("<td>"+film.getSpecial_Features()+"</td>");
			
				actors=film.getActors();
				out.println("<td colspan='2'>");
				for(Actor act:actors){
					out.println( act.getActor_Fname());
					out.println(act.getActor_Lname());
				
				}
				out.println("</td>");
				out.println("<td><a href='ModifyFilmServlet?film_Id="+film.getFilm_Id()+"'>Update</a></td>");
				out.println("</tr>");
			}
				out.println("</table></body>");
	
				out.println("</html>");
		
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
