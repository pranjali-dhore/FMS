package com.flp.fms.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.service.FilmServiceimpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class DeleteServlet
 */
public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String filmId=request.getParameter("film_id");
		
		IFilmService filmservice=new FilmServiceimpl();
		
		boolean flag=filmservice.deleteFilms(Integer.parseInt(filmId));
		
		
		if(flag){
			request.getRequestDispatcher("DeleteFilmServlet").forward(request, response);
		}
		
		
//		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

}
