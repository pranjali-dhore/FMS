package com.flp.fms.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceimpl;
import com.flp.fms.service.IFilmService;


public class SaveFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		Film film=new Film();
		IFilmService filmservice=new FilmServiceimpl();
		
		film.setTitle(request.getParameter("filmtitle"));
		film.setDescription(request.getParameter("filmdescription"));
		
		int length=Integer.parseInt(request.getParameter("filmduration"));
		film.setFilmLength(length);
		
		String rel_date=request.getParameter("releasedate");
		Date releasedate=new Date(rel_date);
		film.setRelease_Year(releasedate);
		
		String rental_d=request.getParameter("rentaldate");
		Date rentaldate=new Date(rental_d);
		film.setRental_Duration(rentaldate);
		
		
		int replacement_cost=Integer.parseInt(request.getParameter("filmreplacementcost"));
		film.setReplacement_Cost(replacement_cost);
		
		int rating=Integer.parseInt(request.getParameter("ratings"));
		film.setRatings(rating);
		
		film.setSpecial_Features(request.getParameter("filmspecialfeatures"));
		
		
		Category cat=new Category();
		cat.setCategory_Id(Integer.parseInt(request.getParameter("category")));
		film.setCategory(cat);

		Language lang=new Language();
		lang.setLanguage_Id(Integer.parseInt(request.getParameter("language")));
		film.setOriginal_Language(lang);
		
		
		String[] actors=request.getParameterValues("actor");
		List<Actor> act =new ArrayList<Actor>();
		for(String str:actors)
		{
			Actor actor = new Actor();
			actor.setActor_Id(Integer.parseInt(str));
			act.add(actor);
		}
	
		film.setActors(act);
		
		
		String[] langs=request.getParameterValues("languages");	
		List<Language> langList = new ArrayList<Language>();
		for(String str:langs){
			Language language=new Language();
			language.setLanguage_Id(Integer.parseInt(str));
			langList.add(language);
		}
		film.setLanguages(langList);
		
		
		
		
		
	System.out.println(film);
	
	filmservice.saveFilm(film);
	
	request.getRequestDispatcher("AddFilmServlet").forward(request, response);
	
	}

}
