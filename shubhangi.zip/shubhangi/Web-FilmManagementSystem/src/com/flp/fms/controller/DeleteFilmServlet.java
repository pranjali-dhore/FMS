package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceimpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class DeleteFilmServlet
 */
public class DeleteFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IFilmService filmservice=new FilmServiceimpl();
		//Film film=new Film();
		
		//Map<Integer,Film> films=filmservice.getAllfilms();
		
		List<Film> films=filmservice.getAllfilms();
		
		PrintWriter out=response.getWriter();
		

		out.println("<html>");
		out.println("<head>ListAll Films</head>"
				+ "<body bgcolor='peachpuff'>"
				+ "<table>"
				+ "<tr>"
				+ "<th>FilmId</th>"         //1
				+ "<th>Film Title</th>"    //2
				+ "<th>FilmDescription</th>"   //3
				+ "<th>Release date</th>"     //4
				+ "<th>OrgLang</th>"          //5
				+ "<th>rental date</th>"         //6
				+ "<th>FilmLength</th>"          //7
				+ "<th>Replacement cost</th>"    //8
				+ "<th>Ratings</th>"           //9
				+ "<th>Features</th>"        //10
				+ "<th>Category</th>"           //11
				+ "<th>list of languages</th>"   //12
				+ "<th>List of Actors</th>"      //13
				
			
				+ "</tr>");
		
		
		for(Film temp:films)
		{
			
			
			out.println("<tr>");
			out.println("<td><a href='DeleteServlet?film_id="+temp.getFilm_Id()+"'>DELETE</a></td>");
			out.println("<td>"+temp.getFilm_Id()+"</td>");  //1
			out.println("<td>"+temp.getTitle()+"</td>");   //2
			out.println("<td>"+temp.getDescription()+"</td>");  //3
			out.println("<td>"+temp.getRelease_Year()+"</td>");  //4
			out.println("<td>"+temp.getOriginal_Language().getLanguage_Name()+"</td>");   //5
 			out.println("<td>"+temp.getRental_Duration()+"</td>");   //6
			
			out.println("<td>"+temp.getFilmLength()+"</td>");   //7
			out.println("<td>"+temp.getReplacement_Cost()+"</td>");  //8
			out.println("<td>"+temp.getRatings()+"</td>");   //9
			
			 out.println("<td>"+temp.getSpecial_Features()+"</td>");      //10
			out.println("<td>"+temp.getCategory().getCategory_Name()+"</td>");   	   //11
			//out.println("</tr>");
		
			
			List<Language>langs=new ArrayList<>();        //12
			langs=temp.getLanguages();
			out.println("<td>");
			for(Language lang:langs)
				out.println(lang.getLanguage_Name());
			out.println("</td>");
			
			
			
			List<Actor> actors =new ArrayList<>();  
			actors=temp.getActors();       //13
			out.println("<td>");
			for(Actor act:actors)
				out.println(act.getActor_Fname()+" "+act.getActor_Lname());
			out.println("</td>");
			out.println("</tr>");
		}
			out.println("</table></body>");

			out.println("</html>");
		
		
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
}
