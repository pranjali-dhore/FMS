package com.flp.fms.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.FilmServiceimpl;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class ModifyServlet
 */
public class ModifyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IFilmService filmService=new FilmServiceimpl();
		
		Film film=new Film();
		
		film.setFilm_Id(Integer.parseInt(request.getParameter("filmid")));
		film.setTitle(request.getParameter("title"));
		film.setDescription(request.getParameter("description"));
		film.setFilmLength(Integer.parseInt(request.getParameter("length")));
		film.setReplacement_Cost(Double.parseDouble(request.getParameter("replacement_cost")));
		film.setSpecial_Features(request.getParameter("special_feature"));
		
		String[] langs=request.getParameterValues("lang");	
		List<Language> langList = new ArrayList<Language>();
	
		for(String str:langs){
			Language language=new Language();
			language.setLanguage_Id(Integer.parseInt(str));
			langList.add(language);
		}
		film.setLanguages(langList);
		
		Language language1=new Language();
		language1.setLanguage_Id(Integer.parseInt(request.getParameter("originallang")));
		film.setOriginal_Language(language1);
		
		Category category=new Category();
		category.setCategory_Id(Integer.parseInt(request.getParameter("category")));
		film.setCategory(category);
		
		String[] actors=request.getParameterValues("actor");
		List<Actor> act=new ArrayList<Actor>();
		for(String str:actors){
			Actor actor=new Actor();
			actor.setActor_Id(Integer.parseInt(str));
			act.add(actor);
		}
		film.setActors(act);
		
		film.setRatings(Integer.parseInt(request.getParameter("ratings")));
		
		String ry=request.getParameter("release_date");
		Date regdate=new Date(ry);
		film.setRelease_Year(regdate);
		
		String rd=request.getParameter("rental_duration");
		Date rendate=new Date(rd);
		film.setRental_Duration(rendate);
		
		System.out.println(film);
		
		//Persist film Object into DataBase
		filmService.modifyFilm(film);
		
		//response.sendRedirect("SaveCustomerServlet");
		//request.getRequestDispatcher("../Greetings.html").forward(request, response);
	}





	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
