package com.flp.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.service.ActorServiceimpl;
import com.flp.fms.service.FilmServiceimpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

/**
 * Servlet implementation class ModifyFilmServlet
 */
public class ModifyFilmServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
IFilmService film_service=new FilmServiceimpl();
		
		String filmid=request.getParameter("film_Id");
		System.out.println("$$$$"+filmid);
		DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
		
		Film film=new Film();
		film.setFilm_Id(Integer.parseInt(filmid));
		
		List<Film> films=film_service.searchFilm(film);
		
		
		IActorService actor_service=new ActorServiceimpl();
		List<Language> languages=film_service.getLanguages();
		List<Actor> actors=actor_service.getActors();
		List<Category> category=film_service.getCategory();
		PrintWriter out=response.getWriter();
		
		for(Film f:films){
			System.out.println(f);
			out.println("<html>");
			out.println("<head><title>Update Film</title>"
					+"<link href='http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css' rel='stylesheet'>"
					+" <script src='http://code.jquery.com/jquery-1.10.2.js'></script>"
					+" <script src='http://code.jquery.com/ui/1.10.4/jquery-ui.js'></script>"
					);
			out.println("<script>"
	  				+"$(function() {"
	  				+"$( '#datepicker-13' ).datepicker({ maxDate: '0',dateFormat: 'dd-MM-yy' }).val();"
	  				+"$( '#datepicker-13' ).datepicker('show');"
	  				+"});"
	  				+"</script>"
	  				+"<script>"
	  				+"$(function() {"
	  				+" $('#datepicker-14').datepicker({dateFormat: 'dd-MM-yy'});"
	  				+"$( '#datepicker-14' ).datepicker('show');"
	  				+" });"
	  				+"</script>");
			out.println("</script>");
			out.println("<script type='text/javascript' src='script/validate.js'></script>");
			out.println("</head>");
			out.println("<body bgcolor='peachpuff'>");
			out.println("<form id='updateForm' method='get' name='myForm' action='ModifyServlet'>");
			out.println("<table>"
					   +"<th>Update Film</th>"
					   +"<tr><td></td><td></td>"
					   +"</tr>"
					   +"<tr><td></td>"
					   +"</tr>"
					   +"<tr>"
					   +"<input type='hidden' name='filmid' value="+f.getFilm_Id()+">"
					   +"<td>Film Title</td>"
					   +"<td><input type='text' name='title' value=" + f.getTitle() + " onmouseout='return  validateField()'/>"
					   +"<div id='titleErr' class='errMsg'></div>"
					   +"</td></tr>"
					   +"<tr>"
					   +"<td>Film Description</td>"
					   +"<td><textarea name='description' onmouseout='return validateDescription()'>"+ f.getDescription() +"</textarea>"
					   +"<div id='descriptionErr' class='errMsg'></div>"
					   +"</td></tr>"
					   +"<tr>"
					   +"<td>Release Date</td>"
					   +"<td><input type='text' id='datepicker-13' name='release_date' value="+ df.format(f.getRelease_Year()) +" placeholder='DD/MM/YYYY'></td>"
					   +"</tr>");
					   out.println("<tr>"
					   +"<td>Original Language</td>");
					   out.println("<td><select name='originallang' >");
					   for(Language lang:languages){
						   if((f.getOriginal_Language().getLanguage_Name()).equals(lang.getLanguage_Name())){
							out.println("<option value='"+ lang.getLanguage_Id()+"' selected>"
									+lang.getLanguage_Name()+ "</option>");
						   }
						   else{
							   out.println("<option value='"+ lang.getLanguage_Id()+"'>"
										+lang.getLanguage_Name()+ "</option>");
						   }
							
					   }
					   
					 out.println("</select></td></tr>");
					   
					 out.println("<tr>"
							   +"<td>Languages</td>");
							   out.println("<td><select name='lang' multiple>");
							   for(Language lang1:f.getLanguages()){
							   for(Language lang:languages){
								  
								   if(lang1.getLanguage_Name().equals(lang.getLanguage_Name()))
								   {
									out.println("<option value='"+ lang.getLanguage_Id()+"' selected>"
											+lang.getLanguage_Name()+ "</option>");
								   }
									else{
										out.println("<option value='"+ lang.getLanguage_Id()+"'>"
												+lang.getLanguage_Name()+ "</option>");
									}
							      }	
							   }
							   
							 out.println("</select></td></tr>");
							   
			out.println("<tr>"
					   +"<td>Rental Duration</td>"
					   +"<td><input type='text' id='datepicker-14' name='rental_duration' value="+df.format(f.getRental_Duration())+">"
					   +"<div id='rentalErr' class='errMsg'></div></td>"
					   +"</tr><tr>"
					   +"<td>Length</td>"
					   +"<td><input type='text' name='length' value="+f.getFilmLength()+" onmouseout='return validatefilmDuration()'/>"
					   +"<div id='lengthErr' class='errMsg'></div>"
					   +"</td></tr>"
					   +"<tr>"
					   +"<td>Replacement Cost</td>"
					   +"<td><input type='text' name='replacement_cost' value="+f.getReplacement_Cost()+" onmouseout='return isreplacementvalidate()'/>"
					   +"<div id='replacement_costErr' class='errMsg'></div>"
					   +"</td></tr><tr>"
					   +"<td>Ratings</td>"
					   +"<td> <input type='radio' name='ratings' value='1' checked> 1"
					   +"<input type='radio' name='ratings' value='2' > 2"
					   	+"<input type='radio' name='ratings' value='3'> 3"
					   +"<input type='radio' name='ratings' value='4' > 4"
					   	+"<input type='radio' name='ratings' value='5'> 5"
					   +"<div id='ratingsErr' class='errMsg'></div>"
					   +"</td></tr><tr>"
					   +"<td>Special Feature</td>"
					   +"<td><textarea name='special_feature'  onmouseout='return isspecialvalidate()'>"+f.getSpecial_Features()+"</textarea>"
					   +"<div id='special_featureErr' class='errMsg'></div>"
					   +"</td></tr>"
					);
			
			 out.println("<tr>"
					   +"<td>Actors</td>");
					  out.println("<td><select name='actor' multiple>");
					  for(Actor act1:f.getActors()){
					   for(Actor act:actors){
						  
							if(act1.getActor_Fname().equals(act.getActor_Fname())){
							out.println("<option value='"+ act.getActor_Id()+"' selected>"
									+act.getActor_Fname()+" "+act.getActor_Lname()+ "</option>");
							   }
						   else{
								   out.println("<option value='"+ act.getActor_Id()+"'>"
											+act.getActor_Fname()+" "+act.getActor_Lname()+ "</option>");
							  }}
						  
						   	
					   }
					   
					 out.println("</select></td></tr>");
					 
					 out.println("<tr>"
							   +"<td>Category</td>");
							   out.println("<td><select name='category' >");
							   for(Category cat:category){
								   if((f.getCategory().getCategory_Name()).equals(cat.getCategory_Name())){
									out.println("<option value='"+ cat.getCategory_Id()+"' selected>"
											+cat.getCategory_Name()+ "</option>");
								   }else{
									   out.println("<option value='"+ cat.getCategory_Id()+"'>"
												+cat.getCategory_Name()+ "</option>"); 
								   }
							   }
							   
							 out.println("</select></td></tr>");
					 
			out.println("<tr>"
					+"<td></td>"
					+"<td><input type='submit' value='Update'>"
					+"<input type='reset' value='Clear'>"
					 +"</td>"
				+"</tr>");
	        out.println("</table>");
	        out.println("</form");
			out.println("</body>");
			out.println("</html>");
			
		
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
