package org.cap.onetoone;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Customer {
	
	@Id
	@GeneratedValue
	private int custId;
	private String custName;
	private String contact;
	
	@OneToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@JoinColumn(name="custDet_FK")
	private CustomerDetails customerDetails;

	
	public Customer(){}

	public Customer(int custId, String custName, String contact, CustomerDetails customerDetails) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.contact = contact;
		this.customerDetails = customerDetails;
	}
	public Customer(String custName, String contact, CustomerDetails customerDetails) {
		super();
		
		this.custName = custName;
		this.contact = contact;
		this.customerDetails = customerDetails;
	}

	public int getCustId() {
		return custId;
	}


	public void setCustId(int custId) {
		this.custId = custId;
	}


	public String getCustName() {
		return custName;
	}


	public void setCustName(String custName) {
		this.custName = custName;
	}


	public String getContact() {
		return contact;
	}


	public void setContact(String contact) {
		this.contact = contact;
	}


	public CustomerDetails getCustomerDetails() {
		return customerDetails;
	}


	public void setCustomerDetails(CustomerDetails customerDetails) {
		this.customerDetails = customerDetails;
	}


	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", contact=" + contact + ", customerDetails="
				+ customerDetails + "]";
	}
	
	
	

}
