package org.cap.onetomany;

import org.cap.onetoone.Customer;
import org.cap.onetoone.CustomerDetails;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class TestClass {

	public static void main(String[] args) {
		AnnotationConfiguration config=new AnnotationConfiguration();
		config.addAnnotatedClass(Employee.class);
		config.addAnnotatedClass(Company.class);
		config.configure();
		
		new SchemaExport(config).create(true, true);
		
		SessionFactory factory= config.buildSessionFactory();
		Session session=factory.openSession();
		session.beginTransaction();
		
		Company cap=new Company(1001, "Capgemini India (p) Ltd ");
		Company tcs=new Company(1002, "TATA Consultancy");
		
		Employee emp=new Employee("Tom", "1200", cap);
		Employee emp1=new Employee("JAck", "3400", cap);
		Employee emp2=new Employee("Ram", "1670", tcs);
		Employee emp3=new Employee("Rock", "15600", tcs);
		
		session.save(emp);
		session.save(emp1);
		session.save(emp2);
		session.save(emp3);

		session.getTransaction().commit();
		
		session.close();
		
		
		
	}

}
