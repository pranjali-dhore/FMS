package org.cap.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.Service.LoginService;
import org.cap.Service.LoginServiceImp;
import org.cap.pojo.Customer;

/**
 * Servlet implementation class ListAllCustomer
 */
public class ListAllCustomer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListAllCustomer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
LoginService loginService=new LoginServiceImp();
		
		ArrayList<Customer> customers=loginService.getAllEmployees();
		
		
		PrintWriter out=response.getWriter();
		
		out.println("<html>");
		out.println("<head>ListAll Employee</head>"
				+ "<body>"
				+ "<table>"
				+ "<tr>"
				+ "<th>Employee Id</th>"
				+ "<th>FirstName</th>"
				+ "<th>LastName</th>"
				+ "<th>Address</th>"
				+ "<th>Gender</th>"
				+ "<th>RegDate</th>"
				+ "<th>regfee</th>"
				+ "<th>Customer Type</th>"
				+ "</tr>");
		
			for(Customer cust:customers){
				out.println("<tr>");
				out.println("<td>"+cust.getId()+"</td>");
				out.println("<td>"+cust.getFirstName()+"</td>");
				out.println("<td>"+cust.getLastName()+"</td>");
				out.println("<td>"+cust.getAdress()+"</td>");
				out.println("<td>"+cust.getGender()+"</td>");
				out.println("<td>"+cust.getRegDate()+"</td>");
				out.println("<td>"+cust.getRegFee()+"</td>");
				out.println("<td>"+cust.getCustType()+"</td>");
				out.println("</tr>");
			}
				out.println("</table></body>");
	
				out.println("</html>");
		
	}

}
