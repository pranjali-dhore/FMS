package org.cap.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.Service.LoginService;
import org.cap.Service.LoginServiceImp;
import org.cap.pojo.Customer;

/**
 * Servlet implementation class SearchServlet
 */
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	int Id ;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response, int Id) throws ServletException, IOException {
	
	}
	
	
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	 PrintWriter out=response.getWriter();
	    ArrayList<Customer> customers=new ArrayList<Customer>();
		
		out.println("<html>");
		out.println("<head>ListAll Employee</head>"
				+ "<body>"
				+ "<table>"
				+ "<tr>"
				+ "<th>Employee Id</th>"
				+ "<th>FirstName</th>"
				+ "<th>LastName</th>"
				+ "<th>Address</th>"
				+ "<th>Gender</th>"
				+ "<th>RegDate</th>"
				+ "<th>regfee</th>"
				+ "<th>Customer Type</th>"
				+ "</tr>");
		
			for(Customer cust:customers){
				out.println("<tr>");
				out.println("<td>"+cust.getId()+"</td>");
				out.println("<td>"+cust.getFirstName()+"</td>");
				out.println("<td>"+cust.getLastName()+"</td>");
				out.println("<td>"+cust.getAdress()+"</td>");
				out.println("<td>"+cust.getGender()+"</td>");
				out.println("<td>"+cust.getRegDate()+"</td>");
				out.println("<td>"+cust.getRegFee()+"</td>");
				out.println("<td>"+cust.getCustType()+"</td>");
				out.println("</tr>");
			}
				out.println("</table></body>");
	
				out.println("</html>");
				LoginService loginService=new LoginServiceImp();
				 int id = Integer.parseInt(request.getParameter("searchid"));  
				 ArrayList<Customer> customer = loginService.searchId(id);
				// out.println(Id);
	}
	}


