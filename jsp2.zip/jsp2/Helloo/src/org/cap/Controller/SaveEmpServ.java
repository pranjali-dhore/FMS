package org.cap.Controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.Service.LoginService;
import org.cap.Service.LoginServiceImp;
import org.cap.pojo.Customer;

/**
 * Servlet implementation class SaveEmpServ
 */
public class SaveEmpServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SaveEmpServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       LoginService loginService=new LoginServiceImp();
		
		Customer cust = new Customer();
		
		cust.setFirstName(request.getParameter("fname"));
		cust.setLastName(request.getParameter("lname"));
		cust.setAdress(request.getParameter("address"));
		cust.setGender(request.getParameter("gendar"));
		
		
		String regdate=request.getParameter("regDate");
		Date regDate=new Date(regdate);
		cust.setRegDate(regDate);
		
		double regfees=Double.parseDouble(request.getParameter("regFee"));
		cust.setRegFee(regfees);
		

		String custtype=request.getParameter("custType");
		cust.setCustType(custtype);
		
		System.out.println(cust);
		
		//Persist customer Object into DataBase
		loginService.saveEmployee(cust);
		
		//response.sendRedirect("SaveCustomerServlet");
		request.getRequestDispatcher("../pages/EmployeeLogin.html").forward(request, response);
		
	}

}
