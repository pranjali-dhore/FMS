package org.cap.pojo;

import java.util.Date;

public class Customer {
	private int id ;
	private String FirstName;
	private String LastName;
	private String adress;
	private String gender;
	private Date regDate;
	private double regFee;
	private String custType;
	public Customer(){}
	
	public Customer(int id,String firstName, String lastName, String adress, String gender, Date regDate, double regFee,
			String custType) {
		super();
		this.id = id;
		FirstName = firstName;
		LastName = lastName;
		this.adress = adress;
		this.gender = gender;
		this.regDate = regDate;
		this.regFee = regFee;
		this.custType = custType;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getRegDate() {
		return regDate;
	}

	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}

	public double getRegFee() {
		return regFee;
	}

	public void setRegFee(double regFee) {
		this.regFee = regFee;
	}

	public String getCustType() {
		return custType;
	}

	public void setCustType(String custType) {
		this.custType = custType;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", FirstName=" + FirstName + ", LastName=" + LastName + ", adress=" + adress
				+ ", gender=" + gender + ", regDate=" + regDate + ", regFee=" + regFee + ", custType=" + custType + "]";
	}
	

}
