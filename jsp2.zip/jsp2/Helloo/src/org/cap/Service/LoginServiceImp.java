package org.cap.Service;
import java.util.ArrayList;

import org.cap.Dao.LoginDaoImp;
import org.cap.Dao.Logindao;
import org.cap.pojo.Customer;
import org.cap.pojo.LoginUser;

public class LoginServiceImp implements LoginService  {
	private Logindao loginDao=new LoginDaoImp();
	@Override
	public boolean isValidLogin(LoginUser loginUser) {
		
		 return loginDao.isValidLogin(loginUser);
	}

	@Override
	public void saveEmployee(Customer cust) {
		loginDao.saveEmployee(cust);
		
	}
	@Override
	public ArrayList<Customer> getAllEmployees() {
		// TODO Auto-generated method stub
		return loginDao.getAllCustomer();
	}
	@Override
	public ArrayList<Customer> searchId(int id)
	{
		return loginDao.searchId(id);
	}
	@Override
	public boolean deleteEmployee(int id) {
		return loginDao.deleteEmployee(id);
	}
}
