package org.cap.Service;

import java.util.ArrayList;

import org.cap.pojo.Customer;
import org.cap.pojo.LoginUser;

public interface LoginService {
	public boolean isValidLogin(LoginUser loginUser);
	public void saveEmployee(Customer cust);
	public ArrayList<Customer>  getAllEmployees();
	public ArrayList<Customer> searchId(int id);
	public boolean deleteEmployee(int id);
}
