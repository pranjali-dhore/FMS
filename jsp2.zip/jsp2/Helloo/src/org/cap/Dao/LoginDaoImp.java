package org.cap.Dao;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.cap.pojo.Customer;
import org.cap.pojo.LoginUser;



public class LoginDaoImp implements Logindao{

Customer cust = new Customer();
	@Override
	public boolean isValidLogin(LoginUser loginUser)  {
		boolean flag=false;
		Connection con=getConnection();
		String sql="select * from logintable where username=? and password=?";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, loginUser.getUserName());
			pst.setString(2, loginUser.getUserPwd());
			
			ResultSet rs=pst.executeQuery();
			
			if(rs.next())
				flag=true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return flag;
	}

	
	public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/login","root","Pass1234");
			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return connection;
	}
		
	


	@Override
	public void saveEmployee(Customer cust) {

		Connection con=getConnection();
		System.out.println("customer connection");
		/*
		String sql="insert into Customer2(FirstName,LastName ,adress ,gender ,regDate ,regFee,custType) "
											+ "	 values(?,?,?,?,?,?,?)";*/
		
		String sql="insert into Customer2(FirstName,LastName ,adress ,gender ,regDate ,regFee,custType)"+"  values(?,?,?,?,?,?,?)";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			pst.setString(1, cust.getFirstName());
			pst.setString(2, cust.getLastName());
			pst.setString(3, cust.getAdress() );
			pst.setString(4,cust.getGender());
			pst.setDate(5,new Date(cust.getRegDate().getTime()));
			pst.setDouble(6, cust.getRegFee() );
			pst.setString(7, cust.getCustType());
			
			
			
			int count=pst.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	@Override
	public ArrayList<Customer> getAllCustomer() {
        ArrayList<Customer> customers=new ArrayList<>();
		
		String sql="select * from Customer2";
		Connection con=getConnection();
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()){
				Customer cust=new Customer();
				
				cust.setId(rs.getInt(1));
				cust.setFirstName(rs.getString(2));
				cust.setLastName(rs.getString(3));
				cust.setAdress(rs.getString(4));
				cust.setGender(rs.getString(5));
			    cust.setRegDate((rs.getDate(6).valueOf(rs.getDate(6).toString())));
				cust.setRegFee(rs.getInt(7));
				cust.setCustType(rs.getString(8));
				
				
				
				//Adding the employee into arraylist
				customers.add(cust);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return customers;
	}
//	public ArrayList<Customer> searchId()
//	{
//		String str = sc.next();
//		for (film fm : lst)
//		{
//			if(str.equals(fm.getTittle()))
//			{
//				System.out.println(fm);
//				break;
//			}
//			else
//			{
//			System.out.println("Soory! Film is Not found .. Try again");
//			}
//		}
//	}
	
	@Override
	public ArrayList<Customer> searchId(int id)
	{
		//Customer cust=new Customer();
		 ArrayList<Customer> customers=new ArrayList<>();
		 String sql="select * from Customer2 where id= "+"?";
			Connection con=getConnection();
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				pst.setInt(1, id);
				ResultSet rs=pst.executeQuery();
				
				while(rs.next()){
					for(Customer cust:customers){
					
					
					cust.setId(rs.getInt(1));
					cust.setFirstName(rs.getString(2));
					cust.setLastName(rs.getString(3));
					cust.setAdress(rs.getString(4));
					cust.setGender(rs.getString(5));
				    cust.setRegDate((rs.getDate(6).valueOf(rs.getDate(6).toString())));
					cust.setRegFee(rs.getInt(7));
					cust.setCustType(rs.getString(8));
					
					
					
					//Adding the employee into arraylist
					customers.add(cust);
				}
				}
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			return customers;
	}


@Override
public boolean deleteEmployee(int id) {
	Connection con=getConnection();
	boolean flag=false;
	String sql="delete from Customer2 where id=?";
	
	try {
		PreparedStatement pst=con.prepareStatement(sql);
		pst.setInt(1, id);

		int count=pst.executeUpdate();
		
		if(count>0)
			flag=true;
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
	return flag;
}
}
	
	

