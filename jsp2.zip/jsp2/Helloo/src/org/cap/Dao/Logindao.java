package org.cap.Dao;

import java.util.ArrayList;

import org.cap.pojo.Customer;
import org.cap.pojo.LoginUser;

public interface Logindao {
	public boolean isValidLogin(LoginUser loginUser) ;
	public void saveEmployee(Customer cust);
	public ArrayList<Customer> getAllCustomer();
	public ArrayList<Customer> searchId(int Id);
	public boolean deleteEmployee(int id);
	//public boolean deleteEmployee(int id);
	
}
