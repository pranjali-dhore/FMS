package org.capgemini.Demo1;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class login
 */
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	@Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Servlet#destroy()
	 */
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	
	String uname=request.getParameter("username");
	String pswd=request.getParameter("password");
//	if(uname.equals("tom")&&(pswd.equals("1234")))
//			{
//		         response.sendRedirect("pages/Success.html");
//			}
//	else
//	{
//		response.sendRedirect("pages/login.html");
//	}
//		
	 boolean flag=false;
		Connection conn =null;
		Statement st=null;
		ResultSet rs=null;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Class loaded");
			 conn= DriverManager.getConnection("jdbc:mysql://localhost:3306/login", "root", "Pass1234");
			System.out.println("Connection");
			st=conn.createStatement();
			

			String query="select * from login";
			rs=st.executeQuery(query);

	   
	     
	    	  while(rs.next())
				{
					if(uname.equals(rs.getString(1))&& pswd.equals(rs.getString(2)))
					{
						flag=true;
						response.sendRedirect("pages/Success.html");
						break;
					}
						
					
				}
	    	  if(flag==false){
					response.sendRedirect("pages/login.html");
	    	  }
	         

	      rs.close();
	      st.close();
	      conn.close();
	} catch ( Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
}
	
	


