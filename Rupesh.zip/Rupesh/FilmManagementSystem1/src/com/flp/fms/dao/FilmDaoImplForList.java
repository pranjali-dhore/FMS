package com.flp.fms.dao;
import java.sql.Date;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmDaoImplForList implements IFilmDao{
	
	
	
	
	private Map<Integer, Film> film_Repository=new HashMap<>();
	
	
	
	
	@Override
	public List<Language> getLanguages() {
		
		List<Language> languages=new ArrayList<>();
		/*languages.add(new Language(1, "English",0));
		languages.add(new Language(2, "Hindi",0));
		languages.add(new Language(3, "Telegu",0));
		languages.add(new Language(4, "Marati",0));
		languages.add(new Language(5, "Kananta",0));
		languages.add(new Language(6, "Tamil",0));
		languages.add(new Language(7, "Malayalam",0));
		*/
		
		/*categories.add(new Category(1, "Drama", 0));
		categories.add(new Category(2, "Comedy",0));
		categories.add(new Category(3, "Horror",0));
		categories.add(new Category(4, "Scientific",0));
		categories.add(new Category(5, "Romantic",0));
		categories.add(new Category(6, "Action",0));*/
		
		
		
		Connection con= ActorDaoImplForList. getConnection();
		
		String sql="select * from Language";
		try {
			
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				
				
				Language language1=new Language();
				
				
				language1.setLanguage_Id(rs.getInt(1));
				language1.setLanguage_Name(rs.getString(2));
				
				
				languages.add(language1);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
		return languages;
	}
	
	
	

	@Override
	public List<Category> getCategory() {
		
		List<Category> categories=new ArrayList<>();
		
		
		/*categories.add(new Category(1, "Drama", 0));
		categories.add(new Category(2, "Comedy",0));
		categories.add(new Category(3, "Horror",0));
		categories.add(new Category(4, "Scientific",0));
		categories.add(new Category(5, "Romantic",0));
		categories.add(new Category(6, "Action",0));*/
		
		
		
		Connection con= ActorDaoImplForList. getConnection();
		
		String sql="select * from Category";
		try {
			
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				
				
				Category category1=new Category();
				
				
				category1.setCategory_Id(rs.getInt(1));
				category1.setCategory_Name(rs.getString(2));
				
				
				categories.add(category1);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
		
		return categories;
	}
	
	
	
	@Override
	public void addFilm(Film film) {
	//	film_Repository.put(film.getFilm_Id(), film);
		Film film1 = new Film();
		

		Connection con= ActorDaoImplForList. getConnection();
		
		String sql="Insert into film (title,description,releaseYear,originalLanguage,rentalDuration,length,replacementCost,ratings,specialFeatures,category)"+" values (?,?,?,?,?,?,?,?,?,?)";
		
		
	try {
			
		PreparedStatement pst=con.prepareStatement(sql);
		pst.setString(1, film.getTitle());
		pst.setString(2,film.getDescription());
		pst.setDate(3, new java.sql.Date(film.getReleaseYear().getTime()));
		pst.setInt(4, film.getOriginalLanguage().getLanguage_Id());
		pst.setDate(5, new java.sql.Date(film.getRentalDuration().getTime()));
		pst.setInt(6, film.getLength());
		pst.setDouble(7, film.getReplacementCost());
		pst.setInt(8, film.getRatings());
		pst.setString(9,film.getSpecialFeatures());
		pst.setInt(10,film.getCategory().getCategory_Id());
		int count=pst.executeUpdate();
		
		//if insertion to film table is success execute
		if(count>0){
			
			//insertion to third party tables
			int filmId=0;
			
			sql="select count(title) from film";
					
			PreparedStatement stmt = con.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()){
					
				filmId = rs.getInt(1);
			}
			
			
			sql="insert into film_actors (film_id,actor_id) values(?,?)";
			pst = con.prepareStatement(sql);
			
			//getting all the actors in the film
			List<Actor> actors = film.getActors();			
			for(Actor act: actors){
				pst.setInt(1, filmId );
				pst.setInt(2, act.getActor_Id() );
				
				count=pst.executeUpdate();
			}
			
							
			sql="insert into film_language(film_id,language_id) values(?,?)";
			pst = con.prepareStatement(sql);
			
			//getting all the other languages
			List<Language> languages = film.getLanguages();				
			for(Language lang: languages){
				pst.setInt(1, filmId );
				pst.setInt(2, lang.getLanguage_Id());
				
				count=pst.executeUpdate();
			}
			
		}
	}
		catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
		
		
		
		
		
	}
	
	

	
	

	@Override
	public Map<Integer, Film> getAllFilms() {
		
		return film_Repository;
	}
	

	
	
	
}
