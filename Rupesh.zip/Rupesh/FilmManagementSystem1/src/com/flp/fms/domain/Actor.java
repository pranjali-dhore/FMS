package com.flp.fms.domain;

public class Actor {
	
	//Private Fields
	private int actor_Id;
	private String first_Name;
	private String last_Name;
	private int film_Id;
	
	//No args Constructor
	public Actor() {}

   //Args Constructor
	public Actor(int actor_Id, String first_Name, String last_Name, int film_Id) {
		super();
		this.actor_Id = actor_Id;
		this.first_Name = first_Name;
		this.last_Name = last_Name;
		this.film_Id = film_Id;
	}


	//Getters and Setters
	public int getActor_Id() {
		return actor_Id;
	}


	public void setActor_Id(int actor_Id) {
		this.actor_Id = actor_Id;
	}


	public String getFirst_Name() {
		return first_Name;
	}


	public void setFirst_Name(String first_Name) {
		this.first_Name = first_Name;
	}


	public String getLast_Name() {
		return last_Name;
	}


	public void setLast_Name(String last_Name) {
		this.last_Name = last_Name;
	}


	public int getFilm_Id() {
		return film_Id;
	}


	public void setFilm_Id(int film_Id) {
		this.film_Id = film_Id;
	}
	
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + actor_Id;
		result = prime * result + film_Id;
		result = prime * result + ((first_Name == null) ? 0 : first_Name.hashCode());
		result = prime * result + ((last_Name == null) ? 0 : last_Name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Actor other = (Actor) obj;
		if (actor_Id != other.actor_Id)
			return false;
		if (film_Id != other.film_Id)
			return false;
		if (first_Name == null) {
			if (other.first_Name != null)
				return false;
		} else if (!first_Name.equals(other.first_Name))
			return false;
		if (last_Name == null) {
			if (other.last_Name != null)
				return false;
		} else if (!last_Name.equals(other.last_Name))
			return false;
		return true;
	}

	//to string method
	@Override
	public String toString() {
		return "Actor [actor_Id=" + actor_Id + ", first_Name=" + first_Name + ", last_Name=" + last_Name + ", film_Id="
				+ film_Id + "]";
	}


	
	
	

}
