package com.flp.fms.domain;

public class Language {
	
	//Private Fields
	private int language_Id;
	private String Language_Name;
	private int film_Id;
	
	//No args Constructor
	public Language(){}
	
	//Args Constructor
	public Language(int language_Id, String language_Name, int film_Id) {
		super();
		this.language_Id = language_Id;
		Language_Name = language_Name;
		this.film_Id = film_Id;
	}


	//Getters and Setters
	public int getLanguage_Id() {
		return language_Id;
	}
	public void setLanguage_Id(int language_Id) {
		this.language_Id = language_Id;
	}
	public String getLanguage_Name() {
		return Language_Name;
	}
	public void setLanguage_Name(String language_Name) {
		Language_Name = language_Name;
	}
	public int getFilm_Id() {
		return film_Id;
	}
	public void setFilm_Id(int film_Id) {
		this.film_Id = film_Id;
	}
	
	//to string method
	@Override
	public String toString() {
		return "Language [language_Id=" + language_Id + ", Language_Name=" + Language_Name + ", film_Id=" + film_Id
				+ "]";
	}
	
	

}
