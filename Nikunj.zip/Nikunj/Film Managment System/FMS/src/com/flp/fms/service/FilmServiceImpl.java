package com.flp.fms.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;

public class FilmServiceImpl implements IFilmService{
	private IFilmDao filmDao=new FilmDaoImplForList();
	//getting languages
	@Override
	public List<Language> getLanguages() {
		
		return filmDao.getLanguages();
	}
	//getting the categories of film
	@Override
	public List<Category> getCategory() {
		
		return filmDao.getCategory();
	}
	//adding film to the repository
	@Override
	public void addFilm(Film film) {
		film.setFilm_Id(generateFilmId());
		filmDao.addFilm(film);
		
		
	}
	//getting all movies from the repository
	@Override
	public Map<Integer, Film> getAllFilms() {
		return filmDao.getAllFilms();
	}
	//for generating the filmid for new films that should be added into the repository
	public int generateFilmId()
	{	int filmid=0;
		double id=Math.random()*2300;
		do{
			filmid=(int) id;
		}while(checkFilmIdValid(filmid));
		return filmid;
		
		
	}
	//checking whether the generated filmid already exists in the repository
	private boolean checkFilmIdValid(int filmid) {
		Set <Integer> keys=getAllFilms().keySet();
		boolean flag=false;
		if(keys.isEmpty()||keys==null)
		{
			flag=false;
		}
		else
		{
			for(Integer key:keys)
			{
				if(key==filmid)
				{
					flag=true;
					break;
				}
			}
		}
		return flag;
	}
	
	//returing the film which is searched
	@Override
	public HashMap<Integer, Film> searchfilm() {
	
		return  filmDao.searchfilm();
	}
	
	//removing the film from repository based on the category selected
	@Override
	public void removeFilm(Film film) {
		// TODO Auto-generated method stub
		filmDao.removeFilm(film);
	}
	
}
