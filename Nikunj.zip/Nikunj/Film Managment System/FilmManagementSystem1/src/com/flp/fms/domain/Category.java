package com.flp.fms.domain;

public class Category {
	
	//Private Fields
	private int category_Id;
	private String category_Name;
	private int filmid;
	
	//No args Constructor
	public Category(){}

	//Args Constructor
	public Category(int category_Id, String category_Name, int filmid) {
		super();
		this.category_Id = category_Id;
		this.category_Name = category_Name;
		this.filmid = filmid;
	}

	//Getters and Setters
	public int getCategory_Id() {
		return category_Id;
	}

	public void setCategory_Id(int category_Id) {
		this.category_Id = category_Id;
	}

	public String getCategory_Name() {
		return category_Name;
	}

	public void setCategory_Name(String category_Name) {
		this.category_Name = category_Name;
	}

	public int getFilmid() {
		return filmid;
	}

	public void setFilmid(int filmid) {
		this.filmid = filmid;
	}

	//to string method
	@Override
	public String toString() {
		return "Category [category_Id=" + category_Id + ", category_Name=" + category_Name + ", filmid=" + filmid + "]";
	}
}
