package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.domain.Actor;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
//import com.flp.fms.service.IActorServiceImpl;

//import com.flp.fms.service.IActorServiceImpl;

/**
 * Servlet implementation class UserInteractionServlet
 */
public class UserInteractionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	

	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		
		
PrintWriter out=response.getWriter();
		
		/*
		
		List<Language> languages=filmService.getLanguages();
		List<Category> category=filmService.getCategory();
		*/
		

FilmServiceImpl filmService=new FilmServiceImpl();
IActorService actorService=new ActorServiceImpl();

 List<Actor> actor= actorService.getActorList();

		
		out.println("<html>");
		out.println("<head>");
		
		out.println("<link rel='stylesheet' href='//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css'>");
		out.println("<script src='//code.jquery.com/jquery-1.10.2.js'></script>");
		out.println(" <script src='//code.jquery.com/ui/1.11.4/jquery-ui.js'></script>");
		
		
		out.println( "<script>");
		out.println(  "  $(function() {");
		out.println(  "    $( '#datepicker').datepicker({  maxDate: '0', dateformat:'dd-mmm-yyyy'});");
	
		out.println( "  });");
		out.println(  "  </script>");
		
		out.println( "<script>");
		out.println(  "  $(function() {");
		out.println(  "  $( '#datepicker1').datepicker();");
		out.println( "  });");
		out.println(  "  </script>");
		
		out.println(  "<script type='text/javascript' src='script/validate.js'> </script>");
		out.println(  "");
	
		
	
		out.println("<title>Film Details</title>");
		out.println("</head>");
		out.println("<body>");
		out.println("<form name='filmf' method='post' >");
		
		

		out.println("<h2><center>Film Registration Form</center></h1>");
		out.print("<table>");


		out.println("<tr>"
			+"<td>FilmTitle:</td>"
			+"<td><input type='text' name='filmtitle' size='20' onmouseout='return  istitlevalidate()'>"
			+"<div id='titleerr' class='errMsg'> </div>"
			+"</td>"
			+"</tr>");
			
			
		out.println("<tr>"
			+"<td>Film Description:</td>"
			+"<td>"
			+"<textarea rows='4' name='filmdescription' cols='25'></textarea>"
			+"<div id='descerr' class='errMsg'> </div> "
			+"</td>"
			+"</tr>");
			
			
			
			out.println("<tr>"
			+"<td>Release Date:</td>"
			+"<td>"
			+"<input type='date' name='releasedate' size='20'>"
			+"</td>"
			+"</tr>");
			
				
			out.println("<tr>"
			+"<td>Rental Duration:</td>"
			+"<td><input type='date' name='rentalduration' size='20'></td>"
			+"<div id='lengtherr' class='errMsg'> </div> "
			+"</tr>");
			
			

			out.println("<tr>"
			+"<td>FilmLength:</td>"
			+"<td><input type='text' name='filmlength' size='20' onmouseout='return  islengthvalid()' >"
			+"<div id='lenghterr' class='errMsg'> </div>"
			+"</td>"
			
			+"</tr>"
			+"<tr>");
			
			out.println("<tr>"
			+"<td>Replacement Cost:</td>"
			+"<td><input type='text' name='replacementcost' size='20'></td>"
			+"<div id='replacementcosterr' class='errMsg'> </div> "
			+"</tr>");
			
			
			out.println("<tr>"
				+"<td>Film Rating:</td>"
				+"<td>"
				+"<select name='rating'>"
					+"<option value='1'>1</option>"
					+"<option value='2'>2</option>"
					+"<option value='3'>3</option>"
					+"<option value='4'>4</option>"
					+"<option value='5'>5</option>"
				+"</select>"
				
				+"</td>"
			+"</tr>");
			
			
			
			out.println("<tr>"
			+"<td>Special Features:</td>"
			+"<td>"
				+"<textarea rows='4' name='specialfeature' cols='25'></textarea>"
			+"</td>"
			+"</tr>");
			
		
			
			
			
			
			out.print("<tr><td>Actor</td><td>:</td>"
					+ "<td><select name='actor'>");
			for(Actor actor1:actor){
				out.print("<option>"+actor1.getActor_Id()+" "+actor1.getFirst_Name()+" "+actor1.getLast_Name()+"</option>");
			}
			out.print("</select></td></tr>");
			
			
			
			
			/*out.print("<tr><td>Original Language</td><td>:</td>"
					+ "<td><select name='orgLang'>");
			
			for(Language lang:languages){
				out.print("<option>"+lang.getLanguage_Id()+" "+lang.getLanguageName()+"</option>");
			}
		out.print("</select></td></tr>");
			
			*/
			
			
			
			
		
			/*
			out.print("<tr><td>Category</td><td>:</td>"
					+ "<td><select name='category'>");
			for(Category category1:category){
				out.print("<option>"+category1.getCategory_Id()+" "+category1.getcategory_name()+"</option>");
			}
		out.print("</select></td></tr>");
		*/
		
				
			
			
			out.println("<tr>"
				+"<td></td>"
				+"<td><input type='submit' value='Save'>"
				+"<input type='reset' value='Clear'>"
				 +"</td>"
			+"</tr>");
			
        	out.println("</table>");


		out.println("</form>");


		out.println("</body>");
		out.println("</html>");

		
		
		
		
	}
		
		
		
	}

	

