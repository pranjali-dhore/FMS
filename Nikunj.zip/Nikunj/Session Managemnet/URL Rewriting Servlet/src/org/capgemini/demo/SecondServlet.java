package org.capgemini.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SecondServlet
 */
public class SecondServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();
		
		out.println("<h1>Welcome to SecondServlet");
		
		
		ServletContext serContxt= getServletContext();
	
		String cmpEmail=serContxt.getInitParameter("companyEmail");
		
		out.println("<h3>Company Email : " + cmpEmail +"</h3><br><br>");
		
		ServletConfig config=getServletConfig();
		
out.println("<br><br>Name :" + config.getInitParameter("userName"));
		
		out.println("Role:" + config.getInitParameter("userRole"));

	
	}

}
