package com.flp.fms.Dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.flp.fms.domain.Film;
import java.util.List;
import java.util.Map;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;

public class FilmDaoImpForOrgLang implements IFilmDao{

	private Map<Integer, Film> film_Repository=new HashMap<>();
	@Override
	public List<Language> getOriginalLanguage() {
   
		List<Language>languages=new ArrayList<>();
		
		/*languages.add(new Language(1, "English"));
		languages.add(new Language(2, "Hindi"));
		languages.add(new Language(3, "Telegu"));
		languages.add(new Language(4, "Marati"));
		languages.add(new Language(5, "Kananta"));
		languages.add(new Language(6, "Tamil"));
		languages.add(new Language(7, "Malayalam"));*/
		
		Connection con=getConnection();
		String sql="select * from LANGUAGE";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Language lang=new Language();
				lang.setLanguage_Id(rs.getInt(1));
				lang.setLanguage_Name(rs.getString(2));
				
				
				languages.add(lang);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return languages;
	}

	@Override
	public List<Category> getCategory() {
		List<Category> category=new ArrayList<>();
		
		Connection con=getConnection();
		String sql="select * from CATEGORY";
		/*category.add(new Category(1, "Comic"));
		category.add(new Category(2, "Horrer"));
		category.add(new Category(3, "Action"));*/
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Category category1=new Category();
				category1.setCategory_Id(rs.getInt(1));
				category1.setCategory_Name(rs.getString(2));
				
				
				category.add(category1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return category;
	}
	
	//CURD Operation
		@Override
		public int addFilm(Film film) {
			
		
			Connection con=getConnection();
			String sql="insert into FILM(title,description,releaseYear,originalLanguage,rentalDuration,LENGTH,replacementCost,ratings,specialFeatures,category)"
					+ "	 values(?,?,?,?,?,?,?,?,?,?)";
			
			int count=0;
			try {
				PreparedStatement pst=con.prepareStatement(sql);
				pst.setString(1, film.getTitle());
				pst.setString(2, film.getDescription());
				pst.setDate(3, new Date(film.getRealeaseYear().getTime()));
				int language=film.getOriginalLanguage().getLanguage_Id();
				pst.setInt(4, language);
				pst.setDate(5, new Date(film.getRentalDuration().getTime()));
				pst.setInt(6, film.getLength());
				pst.setDouble(7,film.getReplacementCost());
				
				pst.setInt(8,film.getRatings());
				pst.setString(9,film.getSpecialFeatures());
				int category=film.getCategory().getCategory_Id();
				pst.setInt(10,category);
				count=pst.executeUpdate();
				
				
				//Fetching last film id 
				String sql1="select filmid from FILM order by filmid desc limit 1 ";
				PreparedStatement pst1=con.prepareStatement(sql1);
				ResultSet rs=pst1.executeQuery();
				int film_id=0;
				while(rs.next())
				{
					film_id=rs.getInt(1);
					
				}
				
				
				//insert into film_languages
				String sql2="insert into film_language values(?,?)";
				PreparedStatement pst2=con.prepareStatement(sql2);
			     List<Language> lang=film.getLanguages();
			     System.out.println(lang);
				for(Language lang1:lang){
				pst2.setInt(1, film_id);
				pst2.setInt(2,lang1.getLanguage_Id());
			    count=pst2.executeUpdate();
				}
				
				String sql3="insert into film_actors values(?,?)";
				PreparedStatement pst3=con.prepareStatement(sql3);
			    List<Actor> actor=film.getActors();
				for(Actor act1:actor){
				pst3.setInt(1, film_id);
				pst3.setInt(2,act1.getActor_Id());
				 count=pst3.executeUpdate();
				}
				
				
				
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(film);
			return count;
		}


		@Override
		public Map<Integer, Film> getAllFilms() {
			
			return film_Repository;
		}

		@Override
		public Map<Integer, Film> searchFilm() {
			return film_Repository;
			
		}

		@Override
		public Map<Integer, Film> removeFilm() {
			
			return  film_Repository;
		}


		public Connection getConnection(){
			
			Connection connection=null;
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
				connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/filmmanagementsystem","root","Pass1234");
				
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
			return connection;
		}
	
	

}
