package com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Service.LoginService;
import com.Service.LoginServiceImpl;

/**
 * Servlet implementation class DeleteServletNew1
 */
@WebServlet("/DeleteServletNew1")
public class DeleteServletNew1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	//protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			String cusId=request.getParameter("cusId");
			LoginService loginService=new LoginServiceImpl();
			
			boolean flag=loginService.deleteCustomer(Integer.parseInt(cusId));
			
			if(flag){
				request.getRequestDispatcher("DeleteServletnew").forward(request, response);
			}
			
		}

}
