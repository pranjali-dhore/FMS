package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Service.LoginService;
import com.Service.LoginServiceImpl;
import com.pojo.Customer;

/**
 * Servlet implementation class SearchServlet
 */
@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		LoginService loginService=new LoginServiceImpl();
		ArrayList<Customer> customer=loginService.getAllCustomer();
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<head><title>Search Customer</title>"
				+ "<script type='text/javascript' src='script/validate.js'></script>"
				+ "<link rel='stylesheet' type='text/css' href='css/mystyles.css'>"
							
				+ "</head>"
				+ "<body><form name='f1'>"
				+ "<div>"
				+ "<label>Choose Customer Id</label>"
				+ "<select name='cusId'>");
		for(Customer cus:customer){
			out.println("<option value='"+ cus.getCusId()+"'>" + cus.getCusId() +"</option>");
		}
				out.println("</select>"
						+ "<input type='button' name='Search' value='Search' onClick='displayCustomer()'>"
				+ "</div>"
				+ "<div id='displayCus'> "
				+ "<h2>Customer Details</h2>"
				
				+ "</div>"
				+ "</form></body>");
		
		
		out.println("</html>");
	}

	

}
