package com.flp.fms.dao;
import com.flp.fms.domain.*;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface IFilmDao {
	public List<Language> getLanguages();
	public List<Category> getCategory();
	public Map<Integer, film> getAllFilms();
	//public Set<Actor> getActor();
	//public void addFilm(film film1);
	public void addFilm(film fm);
	
	
}
