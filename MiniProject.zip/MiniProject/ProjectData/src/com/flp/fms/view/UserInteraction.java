package com.flp.fms.view;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.flp.fms.domain.Actor;
import com.flp.fms.domain.Category;
import com.flp.fms.domain.Language;
import com.flp.fms.domain.film;
import com.flp.fms.util.*;
import com.flp.fms.view.*;
public class UserInteraction {
private static final int Collection = 0;
Scanner sc=new Scanner(System.in);
	
	//Return fully qualified film object
	public film addFilm(List<Language> languages,List<Category> categories,Set<Actor> actors){
		
		film fm = new film();
		boolean flag=true;
		
		String title=null;
		do{
		System.out.println("Enter The Film Title  ");
		title=sc.nextLine();
		flag=Validate.isValidTitle(title);
			if(!flag)
				System.out.println("Invalid Title. Please Enter Valid Title!");
		}while(!flag);
		fm.setTittle(title);
		
	//Releasedate
		String releaseDate;
		boolean date_flag=false;
		Date release_Date=null;
		do{
			
			do{
				System.out.println("Enter Release Date of Film [DD-MM-YYYY]:");
				releaseDate=sc.next();
				flag=Validate.isValidDate(releaseDate);
				if(!flag)
					System.out.println("Please enter date in this Format[---DD-MMM-yyyy---]!");
			}while(!flag);
			
			Date today=new Date();
			release_Date=new Date(releaseDate);
			if(release_Date.before(today)|| release_Date.equals(today))
				date_flag=true;
		
			if(!date_flag)
				System.out.println("Invalid Date! Date should be current date or Past Date!");
		}while(!date_flag);
	fm.setReleaseYear(release_Date);
	
	
	// rentalDuration
	String rentalDate=null;
	boolean date_flag1=false;
	Date rental_Date=null;
	do{
		
		do{
			System.out.println("Enter RentalDuration:");
			rentalDate=sc.next();
			flag=Validate.isValidDate(rentalDate);
			if(!flag)
				System.out.println("Please enter date in this Format[---DD-MMM-yyyy---]!");
		}while(!flag);
		
		rental_Date=new Date(rentalDate);
				if(rental_Date.after(release_Date))
			date_flag1=true;
		if(!date_flag1)
			System.out.println("Invalid Date! Date should be current date or After current Date!");
	}while(!date_flag1);
fm.setRetalDuration(rental_Date);
		
//length
int length=0;

do{
	System.out.println("Enter Length between [1-1000]");
	length=sc.nextInt();
	flag=Validate.isValidLength(length);
		if(!flag)
			System.out.println("Invalid Length. Please Enter Valid Length!");
	}while(!flag);
	fm.setLength(length);
	
	// Replacement Cost
	
	double replacementcost=0;
	do{
		System.out.println("Enter replacement cost [---Greater than 1000---]");
		replacementcost=sc.nextDouble();
		flag=Validate.isValidReplacementCost(replacementcost);
			if(!flag)
				System.out.println("Invalid replacementcost. Please Enter Valid replacementcost!");
		}while(!flag);
		fm.setReplacementCost(replacementcost);
 // Rating
		
		int rating=0;
		do{
			System.out.println("Enter the Rating of the Film");
			rating=sc.nextInt();
			flag=Validate.isValidRating(rating);
				if(!flag)
					System.out.println("Invalid rating. Please Enter Valid rating [1-5]!");
			}while(!flag);
			fm.setRatings(rating);
//Choose Language
			System.out.println("---Choose Original Language---");
			Language language= selectLanguage(languages);
			//fm.setLanguage(languages);
			fm.setOriginalLanguage(language);
			
			System.out.println("---Choose Category--- ");
			Category category= selectCategory(categories);
			fm.setCategory(category);
			
//Add all languages
			List<Language> languages2=new ArrayList<>();
			String choice;
			boolean flag_langs;
			do{
				System.out.println("Choose All Languages for the Film---:");
				Language language1= selectLanguage(languages);
				
				
				flag_langs=Validate.checkDuplicateLanguage(languages2, language1);
				if(!flag_langs)
					languages2.add(language1);
				else
					System.out.println("Language already Exists. Please try other languages!");
				
				
				System.out.println("Wish to add More Languages ?[y|n]");
				choice=sc.next();
			}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
			fm.setLanguage(languages2);
//Choose ACtor
			Set<Actor> actor2 = new HashSet<>();
			
			do{
				System.out.println("Choose All Actors for the Film:");
				Actor actor=selectActor(actors);
				actor2.add(actor);
				
				System.out.println("Wish to add More Actors?[y|n]");
				choice=sc.next();
			}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
			fm.setActors(actor2);
			//Description
			String description=null;
			System.out.println("Enter Description of Film ");
			description=sc.next();
			fm.setDescription(description);
			
	//SpecialFeature
			String SpecialFeature=null;
			System.out.println("Enter the SpecialFeature");
			SpecialFeature=sc.next();
			fm.setSpecialFeature(SpecialFeature);
			//Get Title and validate it
		return fm;
		
	}
public Language selectLanguage(List<Language>  languages){
		
		Language sel_language=null;
		boolean flag;
		do{	
			//Print Langauge Details
			for(Language language:languages)
				System.out.println(language.getLanguage_id() + "\t" + language.getLanguage_name());
			
			System.out.println("---Choose the Language from set ---:");
			int option=sc.nextInt();
			
			flag=false;
			
			//Check the Language Object
			for(Language language: languages)
			{
				if(option==language.getLanguage_id())
				{
					sel_language=language;
					flag=true;
					break;
				}
			}
			
			//Print Error Message
			if(!flag)
				System.out.println("Please select valid Language Id");
		}while(!flag);	
		
		return sel_language;

}
//Get all Category of film
public Category selectCategory(List<Category>  categories){
	
	Category sel_category=null;
	boolean flag;
	do{	
//Print Category Details
		for(Category category:categories)
			System.out.println(category.getCategory_id() + "\t" + category.getCategory_name());
		
		System.out.println("---Choose the category--:");
		int option=sc.nextInt();
		
		flag=false;
		
//Check the Category Object
		for(Category category:categories)
		{
			if(option==category.getCategory_id())
			{
				sel_category= category;
				flag=true;
				break;
			}
		}
		
		//Print Error Message
		if(!flag)
			System.out.println("Please select valid category Id");
	}while(!flag);	
	
	return sel_category;

}

//Get List of Actor
public Actor selectActor(Set<Actor> actors){
	
	Actor sel_actor=null;
	boolean flag;
	do{	
//Print Actor Details
		for(Actor actor1:actors)
			System.out.println(actor1.getActor_Id() + "\t" + actor1.getActor_FirstName()+"\t"+actor1.getActor_LastName());
		
		System.out.println("---Choose the Actors of Film--:");
		int option=sc.nextInt();
		
		flag=false;
		
//Check the Actor Object
		for(Actor actor1:actors)
		{
			if(option==actor1.getActor_Id())
			{
				sel_actor= actor1;
				flag=true;
				break;
			}
		}
		
		//Print Error Message
		if(!flag)
			System.out.println("Please select valid Actor Id");
	}while(!flag);	
	
	return sel_actor;

}
public void getAllFilm(Collection<film> lst) {

	for(film fm:lst){
		String languages="";
		for(Language language:fm.getLanguage())
			languages=languages+language.getLanguage_name()+",";
		
		System.out.println(fm.getFilm_id() + "\t" +
				fm.getTittle() + "\t"+
				fm.getReleaseYear() + "\t"+
				fm.getRetalDuration()+"\t"+
				fm.getReplacementCost()+"\t"+
				fm.getRatings()+"\t"+languages);
		}
}
	
	public void searchFilm(Collection<film> lst)
	{
	
		System.out.println("Enter the Id You want to search ?");
		int f_Id = sc.nextInt();
		for (film fm : lst)
		{
			if(f_Id==fm.getFilm_id())
			{
				System.out.println(fm);
				break;
			}
			else
			{
			System.out.println("Soory! Film is Not found .. Try again");
			}
		}
	}
	public void searchFilmByName(Collection<film> lst)
	{
	
		System.out.println("Enter the Name You want to search");
		String str = sc.next();
		for (film fm : lst)
		{
			if(str.equals(fm.getTittle()))
			{
				System.out.println(fm);
				break;
			}
			else
			{
			System.out.println("Soory! Film is Not found .. Try again");
			}
		}
	}
	public void searchFilmByRating(Collection<film> lst)
	{
	
		System.out.println("Enter the Rating You want to search");
		int rating = sc.nextInt();
		int count =0;
		boolean flag= false;
		for (film fm : lst)
		{
			List<film> fm1 = new ArrayList<>();
			if(rating==fm.getRatings())
			{
				fm1.add(fm);
				System.out.println(fm1);
				count=1;
//				count=count+1;
			}
		}
	if(count==0)
	{
			System.out.println("Soory! Film is Not found .. Try again");
	}

		}
//Remove Film by filmId	
	public void deleteFilm(Collection<film> lst)
		{
			System.out.println("Enter the Id You want to search");
			int f_Id = sc.nextInt();
			boolean flag= false;
			for (film fm : lst)
			{
				
				if(f_Id==fm.getFilm_id())
				{
					//System.out.println(fm);
					lst.remove(fm);
					flag=true;
					System.out.println("Film Id "+ f_Id+"Removed");
					System.out.println(lst);
					break;
				}
				if(flag== false)
				{
				System.out.println("Soory! Film is Not found .. Try again");
				}
			}	
		}
//Remove Film Record By Film Name
			public void DeleteFilmByFilmName(Collection<film> lst){
				System.out.println("Please Enter Film Id you want to Delete-->");
				String title=sc.next();
				boolean flag=false;
				//check if repository is Empty
				if(lst.isEmpty()){
					
					System.out.println("Film Repository is Empty");
				}
				else
					{		
					for(film film:lst)
						{
						 if(title==film.getTittle())
							{
							
							lst.remove(film);
							System.out.println("Film Object with Film Name-->" + film.getTittle()+"Removed");
							flag=true;
							break;
							}
						}
					
				
					if(flag==false)
					{
					System.out.println("Film Not Found");
					}
					
				}
				
				
			}
//Remove Film Record By Film Rating
			public void DeleteFilmByRating(Collection<film> lst){
				System.out.println("Please Enter Film Rating you want to Delete-->");
				int ratings=sc.nextInt();
				boolean flag=false;
				//check if repository is Empty
				if(lst.isEmpty()){
						
						System.out.println("Film Repository is Empty");
					
					}
				else		
				{
					for(film film:lst)
					{
					 if(ratings==film.getRatings())
						 {
						
							lst.remove(film);
							System.out.println("Film Object with Rating-->" + film.getRatings()+"Removed");
							flag=true;
						
						 }
					}
					
					if(flag==false)
					System.out.println("Not Found");
					
				}
				
			}
}
