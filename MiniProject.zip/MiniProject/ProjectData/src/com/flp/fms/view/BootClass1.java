package com.flp.fms.view;

import java.util.Collection;
import java.util.Map;
import java.util.Scanner;

import com.flp.fms.dao.IActorDao;
import com.flp.fms.domain.film;
import com.flp.fms.service.ActorServiceImpl;
import com.flp.fms.service.FilmServiceImpl;
import com.flp.fms.service.IActorService;
import com.flp.fms.service.IFilmService;

public class BootClass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int option;
		String choice;
		UserInteraction userInteraction=new UserInteraction();
		IFilmService filmService=new FilmServiceImpl();
	    IActorService actorServicec = new ActorServiceImpl();
		do
		{
	    menuSelection();
		System.out.println("Enter your option:[1-6]");
		option=sc.nextInt();
		switch(option){
			case 1:
				film fm=userInteraction.addFilm(filmService.getLanguages(),filmService.getCategory(),actorServicec.getActor());
				
				filmService.addFilm(fm);
				System.out.println(fm);
				break;
			case 2:
				break;
			case 3:
				Map<Integer, film>  film_lst2= filmService.getAllFilms();
				Collection<film> lst2=film_lst2.values();
				userInteraction.deleteFilm(lst2);
				break;
			case 4:
				String choice1 = null;
				do{
					
				System.out.println("Enter Your Choice :");
				System.out.println("Enter 1 : Search By Id");
				System.out.println("Enter 2 : Search By Tittle");
				System.out.println("Enter 3 : Search By Rating");
				
				int opt = sc.nextInt();
				
				if(opt==1)
				{
					Map<Integer, film>  film_lst3= filmService.getAllFilms();
					Collection<film> lst3=film_lst3.values();
					userInteraction.searchFilm(lst3);
				}
				else if (opt==2) {
					Map<Integer, film>  film_lst4= filmService.getAllFilms();
					Collection<film> lst4=film_lst4.values();
					userInteraction.searchFilmByName(lst4);
				}
				else if(opt==3){
					Map<Integer, film>  film_lst5= filmService.getAllFilms();
					Collection<film> lst5=film_lst5.values();
					userInteraction.searchFilmByRating(lst5);
				}
				else
				{
					
					System.out.println("Not Valid Choice");
				}
				System.out.println("Enter Your Choice :");
				choice1=sc.next();
				}while(choice1.charAt(0)=='y' ||choice1.charAt(0)=='Y' );
				break;
			case 5:
				Map<Integer, film>  film_lst1= filmService.getAllFilms();
				Collection<film> lst1=film_lst1.values();
				userInteraction.getAllFilm(lst1);
				
				
				break;
			case 6:
				System.exit(0);
		}
		System.out.println("Wish to do more Operation?[y|n]");
		choice=sc.next();
		}while(choice.charAt(0)=='y'||choice.charAt(0)=='Y');
		}
		

	

	public static void menuSelection(){
		System.out.println("1.Add Film");
		System.out.println("2.Modify Film");
		System.out.println("3.Remove Film");
		System.out.println("4.Search Film");
		System.out.println("5.GetAll Film");
		System.out.println("6.Exit");
		
	}

}

