package com.flp.fms.service;

import java.util.Set;

import com.flp.fms.dao.ActorDaoImplForList;
import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.dao.IActorDao;
import com.flp.fms.dao.IFilmDao;
import com.flp.fms.domain.Actor;

public class ActorServiceImpl implements IActorService {
	private IFilmDao filmDao=new FilmDaoImplForList();
	
	private IActorDao actorDao = new ActorDaoImplForList();
	@Override
	public Set<Actor> getActor() {
		return actorDao.getActor();
	}

}
