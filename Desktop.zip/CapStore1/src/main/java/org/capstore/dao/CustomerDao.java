package org.capstore.dao;

import org.capstore.domain.Customer;

public interface CustomerDao {
	
	public void saveCustomer(Customer customer);

}
