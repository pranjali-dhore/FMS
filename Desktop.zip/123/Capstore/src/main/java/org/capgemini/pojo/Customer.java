package org.capgemini.pojo;

import java.sql.Date;

import javax.validation.constraints.NotNull;

public class Customer {
	
	
	@NotNull
	private int customer_id;
	private String customer_first_name;
	private String customer_last_name;
	private String customer_country;
	private String customer_state;
	private String customer_city;
	private int customer_zip;
	private String customer_street_name;
	private int customer_door_no;
	private Date customer_regdate;
	private int customer_mobile_no;
	private String customer_email_id;
	private String customer_password;
	private String customer_verification_code;
	private int customer_email_verified;
	
	//Default Constructor
	public Customer()
	{
		
	}
	
	//Parameterized Constructor
	public Customer(int customer_id, String customer_first_name, String customer_last_name, String customer_country,
			String customer_state, String customer_city, int customer_zip, String customer_street_name,
			int customer_door_no, Date customer_regdate, int customer_mobile_no, String customer_email_id,
			String customer_password, String customer_verification_code, int customer_email_verified) {
		super();
		this.customer_id = customer_id;
		this.customer_first_name = customer_first_name;
		this.customer_last_name = customer_last_name;
		this.customer_country = customer_country;
		this.customer_state = customer_state;
		this.customer_city = customer_city;
		this.customer_zip = customer_zip;
		this.customer_street_name = customer_street_name;
		this.customer_door_no = customer_door_no;
		this.customer_regdate = customer_regdate;
		this.customer_mobile_no = customer_mobile_no;
		this.customer_email_id = customer_email_id;
		this.customer_password = customer_password;
		this.customer_verification_code = customer_verification_code;
		this.customer_email_verified = customer_email_verified;
	}

	//Getters and Setters
	public int getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}

	public String getCustomer_first_name() {
		return customer_first_name;
	}

	public void setCustomer_first_name(String customer_first_name) {
		this.customer_first_name = customer_first_name;
	}

	public String getCustomer_last_name() {
		return customer_last_name;
	}

	public void setCustomer_last_name(String customer_last_name) {
		this.customer_last_name = customer_last_name;
	}

	public String getCustomer_country() {
		return customer_country;
	}

	public void setCustomer_country(String customer_country) {
		this.customer_country = customer_country;
	}

	public String getCustomer_state() {
		return customer_state;
	}

	public void setCustomer_state(String customer_state) {
		this.customer_state = customer_state;
	}

	public String getCustomer_city() {
		return customer_city;
	}

	public void setCustomer_city(String customer_city) {
		this.customer_city = customer_city;
	}

	public int getCustomer_zip() {
		return customer_zip;
	}

	public void setCustomer_zip(int customer_zip) {
		this.customer_zip = customer_zip;
	}

	public String getCustomer_street_name() {
		return customer_street_name;
	}

	public void setCustomer_street_name(String customer_street_name) {
		this.customer_street_name = customer_street_name;
	}

	public int getCustomer_door_no() {
		return customer_door_no;
	}

	public void setCustomer_door_no(int customer_door_no) {
		this.customer_door_no = customer_door_no;
	}

	public Date getCustomer_regdate() {
		return customer_regdate;
	}

	public void setCustomer_regdate(Date customer_regdate) {
		this.customer_regdate = customer_regdate;
	}

	public int getCustomer_mobile_no() {
		return customer_mobile_no;
	}

	public void setCustomer_mobile_no(int customer_mobile_no) {
		this.customer_mobile_no = customer_mobile_no;
	}

	public String getCustomer_email_id() {
		return customer_email_id;
	}

	public void setCustomer_email_id(String customer_email_id) {
		this.customer_email_id = customer_email_id;
	}

	public String getCustomer_password() {
		return customer_password;
	}

	public void setCustomer_password(String customer_password) {
		this.customer_password = customer_password;
	}

	public String getCustomer_verification_code() {
		return customer_verification_code;
	}

	public void setCustomer_verification_code(String customer_verification_code) {
		this.customer_verification_code = customer_verification_code;
	}

	public int getCustomer_email_verified() {
		return customer_email_verified;
	}

	public void setCustomer_email_verified(int customer_email_verified) {
		this.customer_email_verified = customer_email_verified;
	}

	//To String Method
	@Override
	public String toString() {
		return "Customer [customer_id=" + customer_id + ", customer_first_name=" + customer_first_name
				+ ", customer_last_name=" + customer_last_name + ", customer_country=" + customer_country
				+ ", customer_state=" + customer_state + ", customer_city=" + customer_city + ", customer_zip="
				+ customer_zip + ", customer_street_name=" + customer_street_name + ", customer_door_no="
				+ customer_door_no + ", customer_regdate=" + customer_regdate + ", customer_mobile_no="
				+ customer_mobile_no + ", customer_email_id=" + customer_email_id + ", customer_password="
				+ customer_password + ", customer_verification_code=" + customer_verification_code
				+ ", customer_email_verified=" + customer_email_verified + "]";
	}
	
	
}
