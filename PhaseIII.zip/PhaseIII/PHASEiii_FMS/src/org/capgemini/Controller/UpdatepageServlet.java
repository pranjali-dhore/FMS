package org.capgemini.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.DAO.IFilmDaoIml;
import org.capgemini.Service.iFilmServiceImpl;
import org.capgemini.pOJO.Actor;
import org.capgemini.pOJO.Film;
import org.capgemini.pOJO.Language;

/**
 * Servlet implementation class UpdatepageServlet
 */
public class UpdatepageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdatepageServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		iFilmServiceImpl filmservice=new iFilmServiceImpl();
		List<Film> film=filmservice.getAllFilms();
		PrintWriter out=response.getWriter();
		out.println("<head>");
		out.print("<link rel='stylesheet' type='text/css' href='css/mystyles.css'>");
		out.println("</head>"
				+  "<style>"
				+ "table {"
				+ "  border-collapse: collapse;"
				+ "  width: 100%;"
				+ "}"

				+ "th, td {"
				+ " text-align: left;"
				+ " padding: 8px;"
				+ "}"

				+ "tr:nth-child(even){background-color: #c0c0c0}"

				+ "th {"
				+ "  background-color: teal;"
				+ "  color: white;"
				+ "}"
				+ "</style>");
		
		
		out.println("<body>"
			/*	+ "<form action='DeleteServlet1' method='post'>"*/
				+ "<h2 align='center'>List Of Films</h2>"
				+ "<table border=2px>"
				+ "<tr>"
				+ "<th>Film Id</th>"
				+ "<th>Title</th>"
				+ "<th>Description</th>"
				+ "<th>Release Year</th>"
				+ "<th>Original Language</th>"
				+ "<th>Languages</th>"
				+ "<th>Rental Duration</th>"
				+ "<th>Length</th>"
				+ "<th>Replacement Cost</th>"
				+ "<th>Ratings</th>"
				+ "<th>Special Features</th>"
				+ "<th>Actors</th>"
				+ "<th>Category</th>"
				+ "<th>Update</th>"
				+ "</tr>");
		for(Film film1:film){
			List<Language> languages=film1.getLanguages();
			
			String langs="";
			for(Language lang:languages)
			{
				langs=langs+lang.getLanguage_name()+",";
			}
			
			List<Actor> actors=film1.getActors();
			String actors1="";
			for(Actor actor:actors)
			{
				actors1=actors1+actor.getActor_FirstName()+" "+actor.getActor_LastName()+",";
			}
			out.println("<tr>");
			out.println("<td>"+film1.getFilm_id()+"</td>");
			out.println("<td>"+film1.getTittle()+"</td>");
			out.println("<td>"+film1.getDescription()+"</td>");
			out.println("<td>"+film1.getReleaseYear()+"</td>");
			out.println("<td>"+film1.getOriginalLanguage().getLanguage_name()+"</td>");
			out.println("<td>"+langs.substring(0, (langs.length()-1))+"</td>");
			out.println("<td>"+film1.getRetalDuration()+"</td>");
			out.println("<td>"+film1.getLength()+"</td>");
			out.println("<td>"+film1.getReplacementCost()+"</td>");
			out.println("<td>"+film1.getRatings()+"</td>");
			out.println("<td>"+film1.getSpecialFeature()+"</td>");
			out.println("<td>"+actors1.substring(0, (actors1.length()-1))+"</td>");
			out.println("<td>"+film1.getCategory().getCategory_name()+"</td>");
			out.print("<td><a href='UpdateServlet?id="+film1.getFilm_id()+"'><h5 style='color:#E45E9D;'>Edit</h5></a></td>");
			out.println("</tr>");
		}
			out.println("</table></body>");
	}



	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
