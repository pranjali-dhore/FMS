package org.capgemini.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.Service.IActorServiceImplementation;
import org.capgemini.Service.IFilmService;
import org.capgemini.Service.iFilmServiceImpl;
import org.capgemini.pOJO.Actor;
import org.capgemini.pOJO.Category;
import org.capgemini.pOJO.Film;
import org.capgemini.pOJO.Language;

/**
 * Servlet implementation class UpdateServlet
 */
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
PrintWriter out=response.getWriter();
		
		IFilmService filmser=new iFilmServiceImpl();
		IActorServiceImplementation actorService=new IActorServiceImplementation();
		
		
		
		List<Actor> actor=actorService.getActorList();
		List<Language> languages=filmser.getLanguage();
		List<Category> category=filmser.getCategory();
		
		
		int id=Integer.parseInt(request.getParameter("id"));
		
		Film film=filmser.getSearchFilmByID(id);
		
		List<Actor> actFilm=film.getActors();
		List<Language>langFilm=film.getLanguages();
		DateFormat df=new SimpleDateFormat("dd-MMM-yyyy");
		
		System.out.println("edit");
		System.out.println(film);
		
		out.print("<head>");
		out.print("<script type='text/javascript' src='scripts/validate.js'></script>"
				+"<link rel='stylesheet' href='//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css'>"
				+ "<script src='//code.jquery.com/jquery-1.10.2.js'></script>"
				+"<script src='//code.jquery.com/ui/1.11.4/jquery-ui.js'></script>"
				
				+ " <link rel='stylesheet' type='text/css' href='css/mystyles.css'>"
				/*+ "<link rel='stylesheet' type='text/css' href='css/jquery-ui-1.9.2.custom.css'>"
				+ "<link rel='stylesheet' type='text/css' href='css/jquery-ui-1.9.2.custom.min.css'>"
				+ "<link rel='stylesheet' type='text/css' href='css/jquery-ui-1.9.2.custom.min.css'>"*/
				+ "<script type='text/javascript' src='scripts/jquery-1.8.3.js'></script>"
				+ "<script type='text/javascript' src='scripts/jquery-ui-1.9.2.custom.js'></script>"
				+ "<script type='text/javascript' src='scripts/jquery-ui-1.9.2.custom.min.js'></script>"
				+ "<script type='text/javascript' src='scripts/dateSelector.js'></script>");
/*">
 ");
*/		out.print("</head>");
		
		out.print("<html>");
		out.print("<body>");
		out.print("<form name='film' method='post' action='Updateservlet2'>");
		out.print("<h1 align='center'>Fill The Details of Film</h1>");
		out.println("<center> "
				+ "<table>"
				+ "<tr>"
				+ "<td><label>Film Title</label></td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='title' onmouseout='return validateDetails()' value='"+film.getTittle()+"'>"
				+ "<div id='titleErr'></div>"
				+ "</td>"
				+ "</tr>");
		out.print("<tr>"
				+ "<td><label>Description</label></td>"
				+ "<td>:</td>"
				+ "<td><textarea rows='4' name='desc' cols='25'>"+film.getDescription()+"</textarea></td><"
				+ "/tr>");
		
		out.print("<tr>"
				+ "<td>Release Year</td>"
				+ "<td>:</td><td>"
				+ "	<input type='text' name='release'  id='relYear' value='"+df.format(film.getReleaseYear())+"' />"
				+ "</td>"
				+ "</tr>");
		

		out.print("<tr><td>Original Language</td><td>:</td>"
				+ "<td><select name='orgLang'>");
		for(Language lang:languages){
			if(lang.getLanguage_name().equals(film.getOriginalLanguage().getLanguage_name())){
				out.print("<option value='"+lang.getLanguage_id()+"' selected>"+lang.getLanguage_id()+" "+lang.getLanguage_name()+"</option>");
				
			}
			else
			out.print("<option value='"+lang.getLanguage_id()+"'>"+lang.getLanguage_id()+" "+lang.getLanguage_name()+"</option>");
		}
		
		out.print("<tr>"
				+ "<td>Rental Duration</td>"
				+ "<td>:</td><td>"
				+ "	<input type='text' name='rentD'  id='rentalDur' value='"+df.format(film.getRetalDuration())+"' />"
				+ "</td>"
				+ "</tr>");
		
		out.print("<tr>"
				+ "<td>Length Of Film</td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='length' size='20' value='"+film.getLength()+"'></td>"
				+ "</tr>");
		
		out.print("<tr>"
				+ "<td>Replacement Cost</td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='cost' size='20' value='"+film.getReplacementCost()+"'></td>"
				+ "</tr>");
		
		out.print("<tr>"
				+ "<td>Ratings</td>"
				+ "<td>:</td>"
				+ "<td><select name='rating' onchange='return isratingSelected()'>");
			for(int i=0;i<=5;i++){
				if(i==film.getRatings()){
					out.print("<option value='"+i+"' selected>"+i+"</option>");
					}
				else
					out.print("<option value='"+i+"' >"+i+"</option>");
			}
				/*+ "<option value=''>Select Rating</option>"
				+ "<option value='1'>1</option>"
				+ "<option value='2'>2</option>"
				+ "<option value='3'>3</option>	"
				+ "<option value='4'>4</option>"
				+ "<option value='5'>5</option>"*/
				out.print( "</select></td>"
				+ "</tr>");
		
	out.print("</select></td></tr>");
		out.print("<tr>"
				+ "<td><label>Special Features:</td>"
				+ "<td>:</td>"
				+ "<td><textarea rows='4' name='spec' cols='25'>"+film.getSpecialFeature()+"</textarea></td>"
				+ "</tr>");
	
	
		
		
	//FOR CATEGORY
	out.print("<tr><td>Category</td><td>:</td>"
			+ "<td><select name='category'>"
			+ "<option value=''>Select category</option>");
	for(Category category1:category){
		if(category1.getCategory_name().equals(film.getCategory().getCategory_name())){
		out.print("<option value='"+category1.getCategory_id()+"' selected>"+category1.getCategory_id()+" "+category1.getCategory_name()+"</option>");
		}
		else
			out.print("<option value='"+category1.getCategory_id()+"'>"+category1.getCategory_id()+" "+category1.getCategory_name()+"</option>");
	}
   out.print("</select></td></tr>");

   //FOR ACTORS
	out.print("<tr><td>Actor</td><td>:</td>"
			+ "<td><select name='actor' multiple=''>"
			+ "<option value''>Select actors</option>");
	boolean flag=false;
	int id1=0;
	for(Actor actor1:actor){
		for(Actor actt:actFilm){
			
		if(actor1.getActor_FirstName().equals(actt.getActor_FirstName()) && actor1.getActor_LastName().equals(actt.getActor_LastName())){
			flag=true;
			 id1=actor1.getActor_Id();
		}
			//out.print("<option value='"+actor1.getActor_Id()+"' selected>"+actor1.getActor_Id()+" "+actor1.getActor_Fname()+" "+actor1.getActor_Lname()+"</option>");
	}
		if(flag==true && id1==actor1.getActor_Id())
			out.print("<option value='"+actor1.getActor_Id()+"' selected>"+actor1.getActor_Id()+" "+actor1.getActor_FirstName()+" "+actor1.getActor_LastName()+"</option>");
		else
			out.print("<option value='"+actor1.getActor_Id()+"' >"+actor1.getActor_Id()+" "+actor1.getActor_FirstName()+" "+actor1.getActor_LastName()+"</option>");
		
	}
	out.print("</select></td></tr>");
	
	
	
		out.print("<tr><td>Other Language</td><td>:</td>"
				+ "<td><select name='othrlang' multiple='' class='ui fluid dropdown'>"
				+ "<option value=''>Select languages</option>");
		boolean flag1=false;
		int id2=0;
		for(Language lang:languages){
			
			for(Language lng:langFilm){
				
				if(lang.getLanguage_name().equals(lng.getLanguage_name())){
					flag1=true;
					 id2=lang.getLanguage_id();
				}
					//out.print("<option value='"+actor1.getActor_Id()+"' selected>"+actor1.getActor_Id()+" "+actor1.getActor_Fname()+" "+actor1.getActor_Lname()+"</option>");
			}
				if(flag1==true && id2==lang.getLanguage_id())
					out.print("<option value='"+lang.getLanguage_id()+"' selected>"+lang.getLanguage_id()+" "+lang.getLanguage_name()+"</option>");
				else
					out.print("<option value='"+lang.getLanguage_id()+"'>"+lang.getLanguage_id()+" "+lang.getLanguage_name()+"</option>");
				
			
		}
	out.print("</select></td></tr>"
			+ "<tr><td><input type='hidden' name='film_id' value='"+id+"'");
	
	out.print("<tr><td></td>"
			+ "<td><input type='submit' value='Submit'</td>"
			+ "</tr>");
			
	
			
			
		
		out.print("</html");
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
