package org.capgemini.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.Service.IFilmService;
import org.capgemini.Service.iFilmServiceImpl;
import org.capgemini.pOJO.Actor;
import org.capgemini.pOJO.Category;
import org.capgemini.pOJO.Film;
import org.capgemini.pOJO.Language;

/**
 * Servlet implementation class AddFilm
 */
public class AddFilm extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public AddFilm() {
        super();
     
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 IFilmService filmService=new iFilmServiceImpl();
			
			Film film = new Film();
			
			film.setTittle(request.getParameter("title"));       
			
			
			film.setDescription(request.getParameter("desc"));  
			
			String regdate=request.getParameter("releasedate");
			Date regDate=new Date(regdate);
			film.setReleaseYear(regDate);
			
			String duration1=request.getParameter("duration");
			Date duration=new Date(duration1);
			film.setRetalDuration(duration);
			
			
			int length=Integer.parseInt(request.getParameter("length"));
			film.setLength(length);
			
		    Language lang = new Language();
		    lang.setLanguage_id(Integer.parseInt(request.getParameter("orgLang")));
		    film.setOriginalLanguage(lang);
			
			int cost=Integer.parseInt(request.getParameter("cost"));
			film.setReplacementCost(cost);
			
            int ratings = Integer.parseInt(( request.getParameter("rating")));
			film.setRatings(ratings);
			
			film.setSpecialFeature((request.getParameter("features")));  
			
			Category cat = new Category();
			cat.setCategory_id(Integer.parseInt(request.getParameter("category")));
			film.setCategory(cat);
			
			
			
			String [] str=request.getParameterValues("othrlang");
			List<Language> lang1=new ArrayList<>();
			for(String str1:str)
			{
		    Language language=new Language();
		    language.setLanguage_id(Integer.parseInt(str1));
		    lang1.add(language);
			}
		film.setLanguages(lang1);
//			Actor actor = new Actor();
//			actor.setActor_Id(actor_Id);
			
			String [] str2=request.getParameterValues("actor");
			List<Actor> act1=new ArrayList<>();
			for(String str3:str2){
				Actor act=new Actor();
				act.setActor_Id(Integer.parseInt(str3));
				act1.add(act);
			}
			film.setActors(act1);
			
			if(film!=null)
			{
				
			
			
			
			System.out.println(film);
			filmService.addFilm(film);
			PrintWriter out=response.getWriter();
			out.println("<html>");
			out.println("<body><center><h1><font color='red'>film added successfully.. </h1></body>");
			out.println("</html>");
			}
			else{
				response.sendRedirect("CreateServlet1");
			}
			//Persist customer Object into DataBase
			 
			
			//response.sendRedirect("SaveCustomerServlet");
			//request.getRequestDispatcher("../pages/SuccessFullyAdd.html.html").forward(request, response);
	}

}
