package org.capgemini.Controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.DAO.IFilmDao;
import org.capgemini.DAO.IFilmDaoIml;
import org.capgemini.Service.IActorService;
import org.capgemini.Service.IActorServiceImplementation;
import org.capgemini.Service.IFilmService;
import org.capgemini.Service.iFilmServiceImpl;
import org.capgemini.pOJO.Actor;
import org.capgemini.pOJO.Category;
import org.capgemini.pOJO.Language;


public class CreateFilm extends HttpServlet {
	private static final long serialVersionUID = 1L;
     public CreateFilm() {
        super();
  
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		IFilmService filmService=new iFilmServiceImpl();
	
		IActorService actorService=new IActorServiceImplementation();
		IFilmDaoIml ser=new IFilmDaoIml();
		//List<Language>languages=ser.getOriginalLanguage();
		
		
		List<Actor> actor=actorService.getActorList();
		List<Language> languages=filmService.getLanguage();
		List<Category> category=filmService.getCategory();
		
		/*System.out.println("Welcome");
		out.println("Welcome");*/
		/*out.print("<head>");
		out.orint("<link rel="stylesheet" type="text/css" href="../css/mystyles.css"><link rel="stylesheet" type="text/css" href="../css/jquery-ui-1.9.2.custom.css">
<link rel="stylesheet" type="text/css" href="../css/jquery-ui-1.9.2.custom.min.css">
<script type="text/javascript" src="../script/jquery-1.8.3.js"></script>
<script type="text/javascript" src="../script/jquery-ui-1.9.2.custom.js"></script>
<script type="text/javascript" src="../script/jquery-ui-1.9.2.custom.min.js"></script> 


<script type="text/javascript" src="../script/datepicker.js"></script>");
*/		
		out.print("<head>");
		out.print("<script type='text/javascript' src='script/validate.js'></script>");
		out.print("</head>");
		
		out.print("<html>");
		out.print("<body>");
		out.print("<form name='film' method='get' >");
		out.print("<h1 align='center'>Fil The Details of Film</h1>");
		out.println("<center> "
				+ "<table>"
				+ "<tr>"
				+ "<td><label>Film Title</label></td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='title' onmouseout='return validateDetails()'>"
				+ "<div id='titleErr'></div>"
				+ "</td>"
				+ "</tr>");
		out.print("<tr>"
				+ "<td><label>Description</label></td>"
				+ "<td>:</td>"
				+ "<td><textarea rows='4' name='desc' cols='25'></textarea></td><"
				+ "/tr>");
		out.print("<tr>"
				+ "<td><label>Special Features:</td>"
				+ "<td>:</td>"
				+ "<td><textarea rows='4' name='spec' cols='25'></textarea></td>"
				+ "</tr>");
		out.print("<tr>"
				+ "<td>Length Of Film</td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='length' size='20'></td>"
				+ "</tr>");
		out.print("<tr>"
				+ "<td>Replacement Cost</td>"
				+ "<td>:</td>"
				+ "<td><input type='text' name='length' size='20'></td>"
				+ "</tr>");
		out.print("<tr>"
				+ "<td>Ratings</td>"
				+ "<td>:</td>"
				+ "<td><select name='rating'>"
				+ "<option value='1'>1</option>"
				+ "<option value='2'>2</option>"
				+ "<option value='3'>3</option>	"
				+ "<option value='4'>4</option>"
				+ "<option value='5'>5</option>"
				+ "</select></td>"
				+ "</tr>");
		
		out.print("<tr><td>Original Language</td><td>:</td>"
				+ "<td><select name='orgLang'>");
		for(Language lang:languages){
			out.print("<option>"+lang.getLanguage_id()+" "+lang.getLanguage_name()+"</option>");
		}
	out.print("</select></td></tr>");
	
	out.print("<tr><td>Category</td><td>:</td>"
			+ "<td><select name='category'>");
	for(Category category1:category){
		out.print("<option>"+category1.getCategory_id()+" "+category1.getCategory_name()+"</option>");
	}
   out.print("</select></td></tr>");

	out.print("<tr><td>Actor</td><td>:</td>"
			+ "<td><select name='actor'>");
	for(Actor actor1:actor){
		out.print("<option>"+actor1.getActor_Id()+" "+actor1.getActor_FirstName()+" "+actor1.getActor_LastName()+"</option>");
	}
	out.print("</select></td></tr>");
	
	out.print("<tr><td></td>"
			+ "<td><input type='submit' value='Submit'</td>"
			+ "</tr>");
		
		out.print("</html");
	
	
	
	}

	
	

}
