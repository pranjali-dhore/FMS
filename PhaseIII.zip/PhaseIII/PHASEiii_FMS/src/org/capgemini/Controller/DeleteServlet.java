package org.capgemini.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capgemini.Service.IFilmService;
import org.capgemini.Service.iFilmServiceImpl;


public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public DeleteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String filmid=request.getParameter("filmid");
		IFilmService filmService=new iFilmServiceImpl();
		boolean flag=filmService.deleteFilm( Integer.parseInt(filmid));
		if(flag){
			request.getRequestDispatcher("DeletePageServlet").forward(request, response);
		}
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<body><center><h1><font color='red'>film Deleted successfully.. </h1></body>");
		out.println("</html>");
	}

	

}
