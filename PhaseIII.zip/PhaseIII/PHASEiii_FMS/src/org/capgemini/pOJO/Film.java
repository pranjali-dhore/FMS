package org.capgemini.pOJO;

import java.util.Date;


public class Film {
	private int Film_id;
	private String tittle;
	private String description;
	private Date releaseYear;
	//private List<Language> languages;
	//private Language originalLanguage;
	private Date retalDuration;
	private int length;
	private double replacementCost;
	private int ratings;
	private String SpecialFeature;
	//private Set<Actor> actors;
	private Category category;
	public Film(){}
	public Film(int film_id, String tittle, String description, Date releaseYear, Date retalDuration, int length,
			double replacementCost, int ratings, String specialFeature, Category category) {
		super();
		Film_id = film_id;
		this.tittle = tittle;
		this.description = description;
		this.releaseYear = releaseYear;
		this.retalDuration = retalDuration;
		this.length = length;
		this.replacementCost = replacementCost;
		this.ratings = ratings;
		SpecialFeature = specialFeature;
		this.category = category;
	}
	public int getFilm_id() {
		return Film_id;
	}
	public void setFilm_id(int film_id) {
		Film_id = film_id;
	}
	public String getTittle() {
		return tittle;
	}
	public void setTittle(String tittle) {
		this.tittle = tittle;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getReleaseYear() {
		return releaseYear;
	}
	public void setReleaseYear(Date releaseYear) {
		this.releaseYear = releaseYear;
	}
	public Date getRetalDuration() {
		return retalDuration;
	}
	public void setRetalDuration(Date retalDuration) {
		this.retalDuration = retalDuration;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public double getReplacementCost() {
		return replacementCost;
	}
	public void setReplacementCost(double replacementCost) {
		this.replacementCost = replacementCost;
	}
	public int getRatings() {
		return ratings;
	}
	public void setRatings(int ratings) {
		this.ratings = ratings;
	}
	public String getSpecialFeature() {
		return SpecialFeature;
	}
	public void setSpecialFeature(String specialFeature) {
		SpecialFeature = specialFeature;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	@Override
	public String toString() {
		return "Film [Film_id=" + Film_id + ", tittle=" + tittle + ", description=" + description + ", releaseYear="
				+ releaseYear + ", retalDuration=" + retalDuration + ", length=" + length + ", replacementCost="
				+ replacementCost + ", ratings=" + ratings + ", SpecialFeature=" + SpecialFeature + ", category="
				+ category + "]";
	}
}
