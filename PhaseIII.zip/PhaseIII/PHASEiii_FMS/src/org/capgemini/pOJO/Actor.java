package org.capgemini.pOJO;

public class Actor {
	private int Actor_Id;
	private String Actor_FirstName;
	private String Actor_LastName;

	public Actor(){}

	public Actor(int actor_Id, String actor_FirstName, String actor_LastName) {
		super();
		Actor_Id = actor_Id;
		Actor_FirstName = actor_FirstName;
		Actor_LastName = actor_LastName;
	}

	public int getActor_Id() {
		return Actor_Id;
	}

	public void setActor_Id(int actor_Id) {
		Actor_Id = actor_Id;
	}

	public String getActor_FirstName() {
		return Actor_FirstName;
	}

	public void setActor_FirstName(String actor_FirstName) {
		Actor_FirstName = actor_FirstName;
	}

	public String getActor_LastName() {
		return Actor_LastName;
	}

	public void setActor_LastName(String actor_LastName) {
		Actor_LastName = actor_LastName;
	}

	@Override
	public String toString() {
		return "Actor [Actor_Id=" + Actor_Id + ", Actor_FirstName=" + Actor_FirstName + ", Actor_LastName="
				+ Actor_LastName + "]";
	}
	
}
