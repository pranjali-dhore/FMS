package org.capgemini.DAO;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.capgemini.pOJO.Category;
import org.capgemini.pOJO.Film;
import org.capgemini.pOJO.Language;

public interface IFilmDao {
	
	
	public List<Language> getOriginalLanguage();
	public List<Category> getCategory();
	public void addFilm(Film film);
	//public void deleteFilm(int filmid);
	public ArrayList<Film> getAllFilms();
	//public Map<Integer, Film> searchFilm();
	public Boolean deleteFilm(int filmid);
	//public void saveFilm(Film film); 
	public ArrayList<Film> searchFilm(Film film);
	public int updateFilm(int id,Film film);
	public Film getSearchFilmByID(int id);

}
