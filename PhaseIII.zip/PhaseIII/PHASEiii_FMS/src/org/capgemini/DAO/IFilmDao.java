package org.capgemini.DAO;

import java.util.List;
import java.util.Map;

import org.capgemini.pOJO.Category;
import org.capgemini.pOJO.Film;
import org.capgemini.pOJO.Language;

public interface IFilmDao {
	
	
	public List<Language> getOriginalLanguage();
	public List<Category> getCategory();
	public void addFilm(Film film);
	public Map<Integer, Film> getAllFilms();
	public Map<Integer, Film> searchFilm();
	public Map<Integer, Film> removeFilm();

}
