package org.capgemini.DAO;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.capgemini.pOJO.Actor;
import org.capgemini.pOJO.Category;
import org.capgemini.pOJO.Film;
import org.capgemini.pOJO.Language;

public class IFilmDaoIml implements IFilmDao{
	private Map<Integer, Film> film_Repository=new HashMap<>();
//Add list of languages into dropDownlist
	@Override
	public List<Language> getOriginalLanguage() {
		List<Language>languages=new ArrayList<>();
		Connection con=getConnection();
		String sql="select * from LANGUAGE";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Language lang=new Language();
				lang.setLanguage_id(rs.getInt(1));
				lang.setLanguage_name(rs.getString(2));
				languages.add(lang);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return languages;
	
	}
	
	
	//Add list of Category into dropDownlist
	@Override
public List<Category> getCategory() {
		
List<Category> category=new ArrayList<>();
		
		Connection con=getConnection();
		String sql="select * from CATEGORY";
		
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Category category1=new Category();
				category1.setCategory_id(rs.getInt(1));
				category1.setCategory_name(rs.getString(2)); 
				
				
				category.add(category1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return category;
	}
	
	@Override
	public void addFilm(Film film) {

		film_Repository.put(film.getFilm_id(), film);
	//	Film film1 = new Film();
		

		Connection con= getConnection();
		
		String sql="Insert into film (title ,description,releaseYear,rentalDuration,LENGTH,	originalLanguage,replacementCost,ratings ,specialFeatures,category)"+" values (?,?,?,?,?,?,?,?,?,?)";
		
	try {
			
		PreparedStatement pst=con.prepareStatement(sql);
		pst.setString(1, film.getTittle());
		pst.setString(2,film.getDescription());
		pst.setDate(3, new java.sql.Date(film.getReleaseYear().getTime()));
		pst.setInt(4, film.getOriginalLanguage().getLanguage_id());
		pst.setDate(5, new java.sql.Date(film.getRetalDuration().getTime()));
		pst.setInt(6, film.getLength());
		pst.setDouble(7, film.getReplacementCost());
		pst.setInt(8, film.getRatings());
		pst.setString(9,film.getSpecialFeature());
		pst.setInt(10,film.getCategory().getCategory_id());
		int count=pst.executeUpdate();
		
		//if insertion to film table is success execute
		if(count>0){
			
			//insertion to third party tables
			int filmId=0;
			
			sql="select count(title) from film";
					
			PreparedStatement stmt = con.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()){
					
				filmId = rs.getInt(1);
			}
			
			
			sql="insert into film_actors (film_id,actor_id) values(?,?)";
			pst = con.prepareStatement(sql);
			
			//getting all the actors in the film
			List<Actor> actors = film.getActors();			
			for(Actor act: actors){
				pst.setInt(1, filmId );
				pst.setInt(2, act.getActor_Id() );
				
				count=pst.executeUpdate();
			}
			
							
			sql="insert into film_language(film_id,language_id) values(?,?)";
			pst = con.prepareStatement(sql);
			
			//getting all the other languages
			List<Language> languages = film.getLanguages();				
			for(Language lang: languages){
				pst.setInt(1, filmId );
				pst.setInt(2, lang.getLanguage_id());
				
				count=pst.executeUpdate();
			}
			
		}
	}
		catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	

		
	}

	@Override
	public Map<Integer, Film> getAllFilms() {
		
		return null;
	}

	@Override
	public Map<Integer, Film> searchFilm() {
		
		return null;
	}

	@Override
	public Map<Integer, Film> removeFilm() {
		
		return null;
	}

public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/phaseiiidatabase","root","Pass1234");
			System.out.println("Establish");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return connection;
	}



}
