package org.capgemini.DAO;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.capgemini.pOJO.Actor;
import org.capgemini.pOJO.Category;
import org.capgemini.pOJO.Film;
import org.capgemini.pOJO.Language;

public class IFilmDaoIml implements IFilmDao{
	private Map<Integer, Film> film_Repository=new HashMap<>();
//Add list of languages into dropDownlist
	@Override
	public List<Language> getOriginalLanguage() {
		List<Language>languages=new ArrayList<>();
		Connection con=getConnection();
		String sql="select * from LANGUAGE";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				Language lang=new Language();
				lang.setLanguage_id(rs.getInt(1));
				lang.setLanguage_name(rs.getString(2));
				languages.add(lang);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return languages;
	
	}
	
	
	//Add list of Category into dropDownlist
	@Override
public List<Category> getCategory() {
		
List<Category> category=new ArrayList<>();
		
		Connection con=getConnection();
		String sql="select * from CATEGORY";
		
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Category category1=new Category();
				category1.setCategory_id(rs.getInt(1));
				category1.setCategory_name(rs.getString(2)); 
				
				
				category.add(category1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return category;
	}
	
	@Override
	public void addFilm(Film film) {

		film_Repository.put(film.getFilm_id(), film);
	

		Connection con= getConnection();
		
		String sql="Insert into film (title ,description,releaseYear,rentalDuration,LENGTH,	originalLanguage,replacementCost,ratings ,specialFeatures,category)"+" values (?,?,?,?,?,?,?,?,?,?)";
		
	try {
			
		PreparedStatement pst=con.prepareStatement(sql);
		pst.setString(1, film.getTittle());
		pst.setString(2,film.getDescription());
		pst.setDate(3, new java.sql.Date(film.getReleaseYear().getTime()));
		pst.setDate(4, new java.sql.Date(film.getRetalDuration().getTime()));
		pst.setInt(5, film.getLength());
		pst.setInt(6, film.getOriginalLanguage().getLanguage_id());
		pst.setDouble(7, film.getReplacementCost());
		pst.setInt(8, film.getRatings());
		pst.setString(9,film.getSpecialFeature());
		pst.setInt(10,film.getCategory().getCategory_id());
		int count=pst.executeUpdate();
		
		//if insertion to film table is success execute
		if(count>0){
			
			//insertion to third party tables
			int filmId=0;
			
			sql="select filmid from film order by filmid desc limit 1";
					
			PreparedStatement stmt = con.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()){
					
				filmId = rs.getInt(1);
			}
			
			
			sql="insert into film_actors (film_id,actor_id) values(?,?)";
			pst = con.prepareStatement(sql);
			
			//getting all the actors in the film
			List<Actor> actors = film.getActors();			
			for(Actor act: actors){
				pst.setInt(1, filmId );
				pst.setInt(2, act.getActor_Id() );
			//	System.out.println(act);
				count=pst.executeUpdate();
			}
			
							
			sql="insert into film_language(film_id,language_id) values(?,?)";
			pst = con.prepareStatement(sql);
			
			//getting all the other languages
			List<Language> languages = film.getLanguages();				
			for(Language lang: languages){
				pst.setInt(1, filmId );
				pst.setInt(2, lang.getLanguage_id());
				
				count=pst.executeUpdate();
			}
			
		}
	}
	
		catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}




public Connection getConnection(){
		
		Connection connection=null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/phaseiiidatabase","root","Pass1234");
			System.out.println("Establish");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return connection;
	}


@Override
public ArrayList<Film> getAllFilms() {
	ArrayList<Film> films=new ArrayList<>();
	
	Connection con=getConnection();
	String sql="select * from film";
	
	
	try {
		PreparedStatement pst=con.prepareStatement(sql);
		ResultSet rs=pst.executeQuery();
		
		while(rs.next()){
			Film film=new Film();
			film.setFilm_id(rs.getInt(1));
			film.setTittle(rs.getString(2));
			film.setDescription(rs.getString(3));
			film.setReleaseYear(rs.getDate(4).valueOf(rs.getDate(4).toString()));
			film.setRetalDuration(rs.getDate(5).valueOf(rs.getDate(5).toString()));
			film.setLength(rs.getInt(6));
			
			//ORIGINAL LAnguage
		    int lang_id=rs.getInt(7);
		   Language lang=getLanguageName(lang_id);
		   film.setOriginalLanguage(lang);
		   
		   
		 /*  System.out.println(lang);*/
		   film.setReplacementCost(rs.getDouble(8));
		   film.setRatings(rs.getInt(9));
		   film.setSpecialFeature(rs.getString(10));
		   
		   //catEGORY

			int category_id=rs.getInt(11);
			Category category=getCategoryforListing(category_id);
			film.setCategory(category);
		   
		   
		 /*  List<Integer> lang_ids = getLanguageIds(film.getFilm_id());
		   List<Language> lang_name=new ArrayList<>();
		   for(Integer langid:lang_ids){
			   lang_name=getLangName(langid);
		   }
		   film.setCategory(lang_name);*/
		   
		   //ACTORS
		   List<Integer> actor_ids=getActorsIds(film.getFilm_id());
		   List<Actor> actor_name=new ArrayList<>();
		   for(Integer actid:actor_ids){
			   List<Actor> actor=new ArrayList<>();
		     actor=getActorName(actid);
		     actor_name.addAll(actor);
		   }
		   film.setActors(actor_name);
		   
		   
		   // OTHER LANGUAGE
		   
		   List<Integer> langids=getLangIDS(film.getFilm_id());
		  
		    List<Language>langName=new ArrayList<>();
		   for(Integer langid:langids){
			  langName.add(getLanguageName(langid));
			  
		   }
		   
		   film.setLanguages(langName);
		
		   films.add(film);
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return films;
}

private List<Integer> getLangIDS(int film_id) {
	List<Integer> langID=new ArrayList<>();
	Connection con=getConnection();
	String str="select * from film_language where film_id="+film_id;
	
	try {
		PreparedStatement pst=con.prepareStatement(str);
		//pst.setInt(1, film_id);
		ResultSet rs=pst.executeQuery();
		System.out.println(film_id);
		
	 while(rs.next()){
		 langID.add(rs.getInt(2));
	 }
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	System.out.println(langID);
	return langID;
	
}


private Category getCategoryforListing(int category_id) {
	// TODO Auto-generated method stub
	Connection con=getConnection();
	Category category=new Category();
	String str="select * from category where categoryID=?";
	try {
		PreparedStatement pst=con.prepareStatement(str);
		pst.setInt(1, category_id);
		ResultSet rs=pst.executeQuery();
		
		while(rs.next()){
			category.setCategory_name(rs.getString(2));
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return category;
}

private List<Actor> getActorName(Integer actid) {
	List<Actor>actor=new ArrayList<>();
	

	Connection con=getConnection();
	String sql="select * from actor where actorID=?";
	
	try {
		PreparedStatement pst=con.prepareStatement(sql);
		pst.setInt(1, actid);
		ResultSet rs=pst.executeQuery();
		while(rs.next()){
			Actor act=new Actor();
			
			act.setActor_FirstName(rs.getString(2));
			act.setActor_LastName(rs.getString(3));
			
			actor.add(act);
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return actor;
}


private List<Integer> getActorsIds(int film_id) {
	List< Integer> actorid=new ArrayList<>();
	
	
	Connection con=getConnection();
	String sql="select * from film_actors where film_id=?";
	
	try {
		PreparedStatement pst=con.prepareStatement(sql);
		pst.setInt(1, film_id);
	   ResultSet rs=pst.executeQuery();
	   
	   while(rs.next()){
		   actorid.add(rs.getInt(2));
	   }
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return actorid;
}


private Language getLanguageName(int lang_id) {
	Connection con=getConnection();
	String sql="select * from language where languageID=?";
	
	Language lang=new Language();
	try {
		PreparedStatement pst=con.prepareStatement(sql);
		pst.setInt(1, lang_id);
		
		ResultSet rs=pst.executeQuery();
		while(rs.next()){
			lang.setLanguage_id(lang_id);
			lang.setLanguage_name(rs.getString(2));
		}
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return lang;
}


@Override
public Boolean deleteFilm(int filmid) {
	Connection con=getConnection();
	boolean flag=false;
	
	//Dlete By using Join
	String sql= "DELETE film ,film_actors,film_language FROM film LEFT JOIN film_actors ON film .filmid = film_actors.film_id LEFT JOIN film_language ON film_language.film_id = film.filmid WHERE film .filmid  =?" ;

	try {
		PreparedStatement pst=con.prepareStatement(sql);
		pst.setInt(1, filmid);
		int count=pst.executeUpdate();
		if(count>0)
			flag=true;
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return flag;
}
 	
public ArrayList<Film> searchFilm(Film film) {
	//List<Film> films=new ArrayList<>();
	   
			Connection con= getConnection();
			int count=0;
			String sql="select * from film where ";
			ArrayList<Film> films=new ArrayList<Film>();
			System.out.println(film);
			if(film!=null)
			{
				if(film.getFilm_id()>0)
				{
					
					sql+="filmid="+film.getFilm_id();
					
					count=1;
				}
				
				if(film.getTittle()!=null)
				{
					if(count==1)
					{
						sql+=" and title='"+film.getTittle()+"'";
					}
					else
					{
						sql+=" title='"+film.getTittle()+"'";
					}
					count=2;
				}
			

				if(film.getRatings()>0)
				{
					if(count==1||count==2)
					{
						sql+=" and ratings="+film.getRatings();
					}
					else
					{
						sql+=" ratings="+film.getRatings();
					}
					count=3;
					
				}
				if(film.getActors()!=null)
				{
					Actor actor=new Actor();
				//	Set<Actor> act=film.getActors();
					List<Actor> act = film.getActors();
					for(Actor a:act)
						actor=a;
					if(count==1||count==2||count==3)
					{
						sql+=" and filmid In(Select film_id from film_actors where actor_id="+actor.getActor_Id()+")";
						
					}else
					{
					sql+=" filmid In(Select film_id from film_actors where actor_id="+actor.getActor_Id()+")";
					}
					count=4;
				}
				if(film.getLanguages()!=null)
				{
					Language lang=new Language();
					List<Language> langs=film.getLanguages();
				
					for(Language l:langs)
						lang=l;
					if(count==1||count==2||count==3||count==4)
					{
						sql+=" and( filmid In(Select film_id from film_language where language_id="+lang.getLanguage_id()+") or filmid In( Select filmid from film where OriginalLanguage="+lang.getLanguage_id()+"))";
						
					}else
					{
					sql+=" ( filmid In(Select film_id from film_language where language_id="+lang.getLanguage_id()+") or filmid In (Select filmid from film where OriginalLanguage="+lang.getLanguage_id()+"))";
					
					}
					count=5;
				}
			
				 
				if(film.getReleaseYear()!=null)
				{
					if(count==1||count==2||count==3||count==4||count==5)
					{
						sql+=" and releaseYear='"+new java.sql.Date(film.getReleaseYear().getTime())+"'";
					}
					else
					{
						sql+="  releaseYear='"+new java.sql.Date(film.getReleaseYear().getTime())+"'";
					}
					count=6;
				}
				System.out.println(sql);
				try {
					PreparedStatement pst=con.prepareStatement(sql);
					ResultSet rs=pst.executeQuery();
				
					while(rs.next())
					{
						Film film1=new Film();
						film1.setFilm_id(rs.getInt(1));
						film1.setTittle(rs.getString(2));
						film1.setDescription(rs.getString(3));
						film1.setReleaseYear(rs.getDate(4));
						film1.setRetalDuration(rs.getDate(5));
						film1.setLength(rs.getInt(6));
						
						String subsql;
						subsql="select NAME from language where languageID="+rs.getInt(7);
						PreparedStatement pst1=con.prepareStatement(subsql);
						ResultSet rs3=pst1.executeQuery();
						Language lang=new Language();
						if(rs3.next())
						{
							lang.setLanguage_id(rs.getInt(7));
							lang.setLanguage_name(rs3.getString(1));
						}
						film1.setOriginalLanguage(lang);
						film1.setReplacementCost(rs.getInt(8));
						film1.setRatings(rs.getInt(9));
						film1.setSpecialFeature(rs.getString(10));
						
						subsql="select NAME from category where categoryID="+rs.getInt(11);
						PreparedStatement pst3=con.prepareStatement(subsql);
					    rs3=pst3.executeQuery();
						if(rs3.next())
						{
							Category cat=new Category();
							cat.setCategory_id(rs.getInt(11));
							cat.setCategory_name(rs3.getString(1));
							film1.setCategory(cat);
						}
						
						subsql="select language_id from film_language where film_id="+rs.getInt(1);
						System.out.println(rs.getInt(1));
						pst3=con.prepareStatement(subsql);
					    rs3=pst3.executeQuery();
					    List<Language> languages=new ArrayList<>();
						while(rs3.next())
						{
													
							String subsql1="select NAME from language where languageID="+rs3.getInt(1);
							PreparedStatement pst2=con.prepareStatement(subsql1);
							ResultSet rs1=pst2.executeQuery();
							while(rs1.next()){
								Language langs=new Language();
								langs.setLanguage_id(rs3.getInt(1));
								langs.setLanguage_name(rs1.getString(1));
								languages.add(langs);
								
							}
						}
						film1.setLanguages(languages);
						subsql="select actor_id from film_actors where film_id="+rs.getInt(1);
					
						pst3=con.prepareStatement(subsql);
					    rs3=pst3.executeQuery();
					   // Set<Actor> actors=new HashSet<>();
					    List<Actor> actors = new ArrayList<>();
						while(rs3.next())
						{
							String subsql1="select firstName,lastName from actor where actorID="+rs3.getInt(1);
							PreparedStatement pst2=con.prepareStatement(subsql1);
							ResultSet rs1=pst2.executeQuery();
							while(rs1.next()){
								Actor actr=new Actor();
								actr.setActor_FirstName(rs1.getString(1));
								actr.setActor_LastName((rs1.getString(2)));
								actr.setActor_Id(rs3.getInt(1));
								actors.add(actr);
								
							}
						}
						film1.setActors(actors);
						film1.setLanguages(languages);
						System.out.println(film1);
						films.add(film1);
				} }catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
				
			}
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return films;
		}
	
	

	

public int updateFilm(int id,Film film) {
	//System.out.println(id+"dao");
		int  count=0;
		Connection con=getConnection();
		String sql="update film set title=?,description=?,releaseYear=?,originalLanguage=?,rentalDuration=?,LENGTH=?,replacementCost=?,ratings=?,specialFeatures=?,category=? where filmid=?";
		String sql1="delete from film_language where film_id=?";
		String sql4="delete from film_actors where film_id=?";
		
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			//pst.setString(1, film.getTitle());
			pst.setString(1, film.getTittle());
			pst.setString(2, film.getDescription());
			pst.setDate(3, new Date(film.getReleaseYear().getTime()));
			int language=film.getOriginalLanguage().getLanguage_id();
			pst.setInt(4, language);
			pst.setDate(5, new Date(film.getRetalDuration().getTime()));
			pst.setInt(6, film.getLength());
			pst.setDouble(7,film.getReplacementCost());
			
			pst.setInt(8,film.getRatings());
			pst.setString(9,film.getSpecialFeature());
			int category=film.getCategory().getCategory_id();
			pst.setInt(10,category);
			pst.setInt(11, id);
			count=pst.executeUpdate();
			//delete from film_language
			PreparedStatement pst1=con.prepareStatement(sql1);
			pst1.setInt(1, id);
		    count=pst1.executeUpdate();
		    
		  //delete from film_actors
			PreparedStatement pst4=con.prepareStatement(sql4);
			pst4.setInt(1, id);
		    count=pst4.executeUpdate();
		    
		    //insert into film_language
		  //insert into film_languages
			String sql2="insert into film_language values(?,?)";
			PreparedStatement pst2=con.prepareStatement(sql2);
		     List<Language> lang=film.getLanguages();
		     System.out.println(lang);
			for(Language lang1:lang){
			pst2.setInt(1, id);
			pst2.setInt(2,lang1.getLanguage_id());
		    count=pst2.executeUpdate();
			}
		    
			String sql3="insert into film_actors values(?,?)";
			PreparedStatement pst3=con.prepareStatement(sql3);
		    List<Actor> actor=film.getActors();
			for(Actor act1:actor){
			pst3.setInt(1, id);
			pst3.setInt(2,act1.getActor_Id());
			 count=pst3.executeUpdate();
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
		
	}


@Override
public Film getSearchFilmByID(int id) {
	Connection con=getConnection();
	Film film=new Film();
	String sql="select * from film where filmid=?";
	
	try {
		PreparedStatement pst=con.prepareStatement(sql);
		pst.setInt(1, id);
		ResultSet rs=pst.executeQuery();
		while(rs.next()){
		/*	Film film=new Film();*/
			//film.setFilm_id(rs.getInt(1));
			film.setFilm_id(rs.getInt(1));
			film.setTittle(rs.getString(2));
			film.setDescription(rs.getString(3));
			film.setReleaseYear(rs.getDate(4).valueOf(rs.getDate(4).toString()));
			film.setRetalDuration(rs.getDate(5).valueOf(rs.getDate(5).toString()));
			film.setLength(rs.getInt(6));
			
			//ORIGINAL LAnguage
		    int lang_id=rs.getInt(7);
		   Language lang=getLanguageName(lang_id);
		   film.setOriginalLanguage(lang);
		   
		   
		 /*  System.out.println(lang);*/
		   film.setReplacementCost(rs.getDouble(8));
		   film.setRatings(rs.getInt(9));
		   film.setSpecialFeature(rs.getString(10));
		   
		   //catEGORY

			int category_id=rs.getInt(11);
			Category category=getCategoryforListing(category_id);
			film.setCategory(category);
		   
		   
		 /*  List<Integer> lang_ids = getLanguageIds(film.getFilm_id());
		   List<Language> lang_name=new ArrayList<>();
		   for(Integer langid:lang_ids){
			   lang_name=getLangName(langid);
		   }
		   film.setCategory(lang_name);*/
		   
		   //ACTORS
		   List<Integer> actor_ids=getActorsIds(film.getFilm_id());
		   List<Actor> actor_name=new ArrayList<>();
		   for(Integer actid:actor_ids){
		     actor_name=getActorName(actid);
		   }
		   film.setActors(actor_name);
		   
		   
		   // OTHER LANGUAGE
		   
		   List<Integer> langids=getLangIDS(film.getFilm_id());
		  
		    List<Language>langName=new ArrayList<>();
		   for(Integer langid:langids){
			  langName.add(getLanguageName(langid));
		   }
		   
		   film.setLanguages(langName);
			/*
			List<Actor> act=new ArrayList<>();
			List<Integer> actor_id=getActorsIds(film.getFilm_id());
			for(Integer actor:actor_id){
				act.add(getActorName(actor));
			}*/
			
			/*films.add(film);*/
			
			
		}
		
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return film;
}



}

