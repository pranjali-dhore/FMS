package org.capgemini.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.capgemini.pOJO.Category;
import org.capgemini.pOJO.Film;
import org.capgemini.pOJO.Language;
//import java.util.Locale.Category;

public interface IFilmService {
	public List<Language> getLanguage();

	public List<Category> getCategory();

	void addFilm(Film film);
	public ArrayList<Film> getAllFilms();
	//public Map<Integer, Film> getAllFilms();
//	public void deleteFilm(int filmid);
	//public Map<Integer, Film> searchFilms();
	public Boolean deleteFilm(int filmid);
	ArrayList<Film> searchFilm(Film film);
	public int updateFilm(int id,Film film);
	public Film getSearchFilmByID(int id);
}
