package org.capgemini.Service;

import java.util.List;
import java.util.Map;

import org.capgemini.pOJO.Category;
import org.capgemini.pOJO.Film;
import org.capgemini.pOJO.Language;
//import java.util.Locale.Category;

public interface IFilmService {
	public List<Language> getLanguage();

	public List<Category> getCategory();

	void addFilm(Film film);

	public Map<Integer, Film> getAllFilms();
	public Map<Integer, Film> searchFilms();
	public Map<Integer, Film> removeFilm();
}
