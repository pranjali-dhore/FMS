package org.capgemini.Service;

import java.util.List;
import java.util.Map;

import org.capgemini.DAO.IActorDao;
import org.capgemini.DAO.IActorImpl;
import org.capgemini.DAO.IFilmDao;
import org.capgemini.DAO.IFilmDaoIml;
import org.capgemini.pOJO.Category;
import org.capgemini.pOJO.Film;
import org.capgemini.pOJO.Language;

public class iFilmServiceImpl  implements IFilmService{
	IFilmDao filmDao=new IFilmDaoIml();
	@Override
	public List<Language> getLanguage() {
		
		return filmDao.getOriginalLanguage() ;
	}

	@Override
	public List<Category> getCategory() {
		
		return filmDao.getCategory();
	}

	@Override
	public void addFilm(Film film) {

	    //film.setFilm_id(film_id);
		filmDao.addFilm(film);
		
	}

	@Override
	public Map<Integer, Film> getAllFilms() {
		
		return filmDao.getAllFilms();
	}

	@Override
	public Map<Integer, Film> searchFilms() {
	
		return filmDao.searchFilm();
	}

	@Override
	public Map<Integer, Film> removeFilm() {
	
		return filmDao.removeFilm();
	}

}
