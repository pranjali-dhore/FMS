package org.cap.Springproject;

public class Adress {

	private int stno;
	private String sname;
	
	public Adress(){}
	
	
	public Adress(int stno, String sname) {
		super();
		this.stno = stno;
		this.sname = sname;
	}


	public int getStno() {
		return stno;
	}
	public void setStno(int stno) {
		this.stno = stno;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	@Override
	public String toString() {
		return "Adress [stno=" + stno + ", sname=" + sname + "]";
	}
	
	
	
	
}
