 DELETE FROM film LEFT JOIN film_actors LEFT JOIN film_language 
   WHERE film_actors.film_id = film.filmid AND film.filmid=film_language.film_id 
  
  
  
  DELETE film ,film_actors,film_language 
  FROM film LEFT JOIN film_actors ON film .filmid = film_actors.film_id
            LEFT JOIN film_language ON film_language.film_id = film.filmid WHERE film .filmid=7
            
       DELETE * FROM  film_actors
            
           actoractorID
WHERE event_id=1139

film_actors
film_actorsactor_id



event , magnitude, trace, POINT
DELETE 1 , 2, 3, 4
FROM 1 LEFT JOIN 2 ON 1.evt_id = 2.evt_id
   LEFT JOIN 4 ON 1.evt_id = 4.evt_id
       LEFT JOIN 3 ON 4.pt_id = 3.trace_id
WHERE event_id=1139