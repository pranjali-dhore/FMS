package org.capgemini.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.capgemini.Pojo.Language;
import org.capgemini.Pojo.Category;
import org.capgemini.Pojo.Film;

public class IfilmDaoImpl implements IfilmDao{
	private Map<Integer, Film> film_Repository=new HashMap<>();
	
	public List<Language> getOriginalLanguage() {
		   
		List<Language>languages=new ArrayList<>();
		return null;
		Connection con=getConnection();
		String sql="select * from LANGUAGE";
		try {
			PreparedStatement pst=con.prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				Language lang=new Language();
				lang.setLanguage_id(rs.getInt(1));
				lang.setLanguage_name(rs.getString(2));
				
				
				languages.add(lang);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return languages;
	}
	@Override
	public List<Category> getCategory() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void addFilm(Film film) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public Map<Integer, Film> getAllFilms() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Map<Integer, Film> searchFilm() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Map<Integer, Film> removeFilm() {
		// TODO Auto-generated method stub
		return null;
	}
}

