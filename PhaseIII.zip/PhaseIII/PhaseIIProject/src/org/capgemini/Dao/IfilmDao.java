package org.capgemini.Dao;

import java.util.List;
import java.util.Map;

import org.capgemini.Pojo.Category;
import org.capgemini.Pojo.Film;
import org.capgemini.Pojo.Language;

public interface IfilmDao {
	public List<Language>getOriginalLanguage();
	public List<Category>getCategory();
	public void addFilm(Film film);
	public Map<Integer, Film> getAllFilms();
	public Map<Integer, Film> searchFilm();
	public Map<Integer, Film> removeFilm();
}
