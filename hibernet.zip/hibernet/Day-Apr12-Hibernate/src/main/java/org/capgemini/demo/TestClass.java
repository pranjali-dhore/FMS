package org.capgemini.demo;



import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class TestClass {

	public static void main(String[] args) {
		
		//Configuration
		AnnotationConfiguration config=new AnnotationConfiguration();
		config.addAnnotatedClass(Student.class);
		config.configure();
		
		//Re-create the schema EveryTime
		//new SchemaExport(config).create(true, true);
		
		//Session Factory
		SessionFactory factory= config.buildSessionFactory();
		
		/*//Session and Transaction
		Session session=factory.openSession();
		
		Student student=new Student( "ram"	, "Singh","ram@gmail.com",3400,new Date());
		Student student1=new Student( "Emi"	, "Jack","Emi@yahoo.com",78900,new Date(1991, 5, 21));
		Student student2=new Student( "annie"	, "fred","fred@gmail.com",9000,new Date());
		Student student3=new Student( "Kamal"	, "singh","singh@gmail.com",1100,new Date());
		
		session.beginTransaction();
		session.save(student);
		session.save(student1);
		session.save(student2);
		session.save(student3);
		
		session.getTransaction().commit();
		session.close();
		*/
		
		//Read operation
		//Delete operation
		//update 
		//get and load method
	/*	
		Session session=factory.openSession();
		session.beginTransaction();
		//Student stud=(Student)session.get(Student.class, 12);
		Student stud=(Student)session.load(Student.class, 3);
		System.out.println(stud);
		stud.setFeesAmt(45000);
		stud.setStudDob(new Date(1990, 2, 12));
		
		session.update(stud);
		
		
		if(stud!=null)
			session.delete(stud);
		
		
		session.getTransaction().commit();
		session.close();
		
		*/
		
		
		
	/*	Session session=factory.openSession();
		session.beginTransaction();
		//Query query=session.createQuery("select firstName from Student where feesAmt>8000");
		
		Query query=session.getNamedQuery("selectAll");
		
		List<Student> students= query.list();
		
		//List<String> students= query.list();
		session.getTransaction().commit();
		session.close();
		

		for(Student student:students)
			System.out.println(student);*/
		
	/*
		for(String str:students)
			System.out.println(str);
	*/
		
		
		Session session=factory.openSession();
		session.beginTransaction();
		Criteria criteria=session.createCriteria(Student.class);
		/*criteria.add(Restrictions.ge("feesAmt", 8000.0));
		criteria.add(Restrictions.like("firstName", "_a%"));
		*/
		/*Criteria c1=criteria.add(Restrictions.between("studId", 7, 9));
		Criteria c2=criteria.add(Restrictions.between("studId", 2, 4));
		*/
	
		criteria.addOrder(Order.asc("firstName"));
		
				Projections.max("feesAmt");
		
		List<Student> students=criteria.list();
		
		
		for(Student student:students)
			System.out.println(student);
			}

}
