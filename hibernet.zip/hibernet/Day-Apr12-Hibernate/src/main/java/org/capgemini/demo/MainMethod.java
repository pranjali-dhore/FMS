package org.capgemini.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class MainMethod {

	public static void main(String[] args) {
		
		
		AnnotationConfiguration config=new AnnotationConfiguration();
		config.addAnnotatedClass(Book.class);
		config.configure();
		
		new SchemaExport(config).create(true, true);
		
		
		
		SessionFactory sessionFactory= config.buildSessionFactory();
		
		
		Session  session= sessionFactory.openSession();
		
		session.beginTransaction();
		
		BookId bookId=new BookId(1001,111);
		Book book=new Book(bookId, "Java Complete Ref", "Robert", 1500);
		
		
		BookId bookId1=new BookId(1001,222);
		Book book1=new Book(bookId1, "Java Guidence", "Jackson", 700);
		
		session.save(book1);
		session.save(book);
		
		session.getTransaction().commit();
		session.close();
		
		
		
		
		
		
		
		

	}

}
