package org.capgemini.demo;



import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.tool.hbm2ddl.SchemaExport;

public class TestClass {

	public static void main(String[] args) {
		
		//Configuration
		AnnotationConfiguration config=new AnnotationConfiguration();
		config.addAnnotatedClass(Student.class);
		config.configure();
		
		//Re-create the schema EveryTime
		new SchemaExport(config).create(true, true);
		
		//Session Factory
		SessionFactory factory= config.buildSessionFactory();
		
		//Session and Transaction
		Session session=factory.openSession();
		
		Student student=new Student( "Tom"	, "Jerry","tom@gmail.com",1200,new Date());
		Student student1=new Student( "Jack"	, "Son","jack@yahoo.com",12900,new Date(1991, 5, 21));
		Student student2=new Student( "Ram"	, "Kumar","ram@gmail.com",5000,new Date());
		Student student3=new Student( "Sasi"	, "Jerry","Sasi@gmail.com",2300,new Date());
		
		session.beginTransaction();
		session.save(student);
		session.save(student1);
		session.save(student2);
		session.save(student3);
		
		session.getTransaction().commit();
		session.close();
		
	}

}
