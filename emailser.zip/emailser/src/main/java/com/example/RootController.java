package com.example;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.messaging.MessagingException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RootController {
@Autowired
private SmtpMailSender smtpmailsender;

@RequestMapping("/send-mail")
public void sendMail() throws javax.mail.MessagingException
{
	smtpmailsender.Send("vaishali.b.pawar@capgemini.com", "Hello its Demo", "hi ...");
}
	
	
	
}
