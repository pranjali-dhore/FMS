package com.flp.fms.domain;

public class Language {
private int Language_id;
private String Language_name;
//private int Film_id;

//No Argument Constructor
public Language(){}

// Argument Constructor
public Language(int language_id, String language_name) {
	super();
	Language_id = language_id;
	Language_name = language_name;
	//this.Film_id = film_id;
}

//getter and setter
public int getLanguage_id() {
	return Language_id;
}
public void setLanguage_id(int language_id) {
	Language_id = language_id;
}
public String getLanguage_name() {
	return Language_name;
}
public void setLanguage_name(String language_name) {
	Language_name = language_name;
}
/*public int getFilm_id() {
	return Film_id;
}
public void setFilm_id(int film_id) {
	this.Film_id = film_id;
}*/
//ToString method
@Override
public String toString() {
	return "Language [Language_id=" + Language_id + ", Language_name=" + Language_name + ", film_id="  + "]";
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + Language_id;
	result = prime * result + ((Language_name == null) ? 0 : Language_name.hashCode());
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Language other = (Language) obj;
	if (Language_id != other.Language_id)
		return false;
	if (Language_name == null) {
		if (other.Language_name != null)
			return false;
	} else if (!Language_name.equals(other.Language_name))
		return false;
	return true;
}

}
