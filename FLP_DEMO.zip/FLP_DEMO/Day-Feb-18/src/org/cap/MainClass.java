package org.cap;

public class MainClass {

	public static void main(String[] args) {
		//Employee e1=new Employee(1, "Tom");
		
		Employee e2=new Employee(1, "Tom");
		Employee e1=e2;
		
		System.out.println(e1==e2);
		
		System.out.println(e1.equals(e2));
		
	}

}
