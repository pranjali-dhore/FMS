package com.flp.fms.view;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.flp.fms.domain.Film;
import com.flp.fms.domain.Language;
import com.flp.fms.util.Validate;

public class UserInteraction {
	
	Scanner sc=new Scanner(System.in);
	
	//Return fully qualified film object
	public Film addFilm(List<Language> languages){
		
		//Create Film Object
		Film film=new Film();
		boolean flag=true;
		
		//Get Title and validate it
		String title=null;
		do{
		System.out.println("Enter Film Title");
		title=sc.nextLine();
		flag=Validate.isValidTitle(title);
			if(!flag)
				System.out.println("Invalid Title. Please Enter Valid Title!");
		}while(!flag);
		film.setTitle(title);
		
		
		
		//Release Date Validation
		String releaseDate;
		boolean date_flag=false;
		Date release_Date=null;
		do{
			
			//Verify Date Format
			do{
				System.out.println("Enter Release Date:");
				releaseDate=sc.next();
				flag=Validate.isValidDate(releaseDate);
				if(!flag)
					System.out.println("Please enter date in this Format(dd-MMM-yyyy)!");
			}while(!flag);
			
			//Verifies Release Date  
			Date today=new Date();
			release_Date=new Date(releaseDate);
			if(release_Date.before(today)|| release_Date.equals(today))
				date_flag=true;
		
			if(!date_flag)
				System.out.println("Invalid Date! Date should be current date or Past Date!");
		}while(!date_flag);
		film.setRealeaseYear(release_Date);
		
		
		//Choose Language
		System.out.println("Choose Original Language");
		Language language= selectLanguage(languages);
		film.setOriginalLanguage(language);
		
		
		return film;
	}
	
	
	
	
	
	//Choose Valid Language Object from the list of Languages
	public Language selectLanguage(List<Language>  languages){
		
		Language sel_language=null;
		boolean flag;
		do{	
			//Print Langauge Details
			for(Language language:languages)
				System.out.println(language.getLanguage_Id() + "\t" + language.getLanguage_Name());
			
			System.out.println("Choose the Language:");
			int option=sc.nextInt();
			
			flag=false;
			
			//Check the Language Object
			for(Language language: languages)
			{
				if(option==language.getLanguage_Id())
				{
					sel_language=language;
					flag=true;
					break;
				}
			}
			
			//Print Error Message
			if(!flag)
				System.out.println("Please select valid Language Id");
		}while(!flag);	
		
		return sel_language;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

}
