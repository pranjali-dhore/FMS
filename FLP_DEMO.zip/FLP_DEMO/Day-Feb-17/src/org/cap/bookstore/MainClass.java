package org.cap.bookstore;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		
		
		Book book=new Book();
		BookDaoImpl bookDaoImpl=new BookDaoImpl();
		Scanner sc=new Scanner(System.in);
		int option;
		String choice;
		
		do{
		
			System.out.println("1.Save Book");
			System.out.println("2.ListAll Books");
			System.out.println("3.Search Book");
			System.out.println("4.Delete Book");
			System.out.println("Enter your Option:");
			option=sc.nextInt();
			
			if(option==1){
				book=book.getBookDetails();
				bookDaoImpl.saveBook(book);
			}else if(option==2)
				bookDaoImpl.listAllBooks();
			
			System.out.println("Wish to Continue?[y|n]");
			choice=sc.next();
		
		}while(choice.charAt(0)=='Y'|| choice.charAt(0) =='y');
	}

}
