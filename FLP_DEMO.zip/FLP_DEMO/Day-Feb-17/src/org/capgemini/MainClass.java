package org.capgemini;

public class MainClass {

	public static void main(String[] args) {
		/*Student student=new Student();
		student.getDetails();
		student.printDetails();
*/
		/*
		Result result=new Result();
		result.calculateAverage();
		result.printResult();*/
		
	/*
		Person person=new Student();
		person.show();
	*/
		
		//Person person2=new Result();
		
		//Person.myMethod();
		Student.myMethod();
		
		
	}

}
