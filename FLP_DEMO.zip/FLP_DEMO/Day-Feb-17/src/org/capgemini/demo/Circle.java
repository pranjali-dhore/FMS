package org.capgemini.demo;

public class Circle extends Shape{
	public void draw(){
		System.out.println("Circle Class Draw Method");
	}
}
