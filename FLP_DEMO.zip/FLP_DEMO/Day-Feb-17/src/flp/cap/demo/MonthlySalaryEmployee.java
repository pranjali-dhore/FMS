package flp.cap.demo;

import java.util.Scanner;

public class MonthlySalaryEmployee extends Employee {
	
	float no_of_days;
	float salary_per_day;
	
	@Override
	public double calculateSalary() {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter no_of_days");
		no_of_days=scanner.nextFloat();
		
		System.out.println("Enter salary_per_day");
		salary_per_day=scanner.nextFloat();
		
		return salary_per_day*no_of_days;
	}
	

}
