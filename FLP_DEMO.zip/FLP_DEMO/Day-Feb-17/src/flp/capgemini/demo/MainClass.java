package flp.capgemini.demo;

public class MainClass {

	public static void main(String[] args) {
		
		Circle circle=new Circle();
		//Shape circle=new Circle();
		//Color circle=new Circle();
		//Graphics circle=new Circle();
		
		circle.draw();
		circle.myCircleInfo();
		circle.fillColor();
		circle.findArea();
		circle.getColor();
		circle.animate();
		circle.move_shape();
		
		
	}

}
