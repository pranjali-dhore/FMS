package flp.capgemini.demo;

public interface Shape extends Graphics,Info {
	
	float PI=3.14f;
	void draw();
	public void findArea();

}
