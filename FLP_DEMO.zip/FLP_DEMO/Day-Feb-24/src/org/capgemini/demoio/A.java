package org.capgemini.demoio;

public class A {
	
	public void print(A a){
		System.out.println("A");
	}
}


