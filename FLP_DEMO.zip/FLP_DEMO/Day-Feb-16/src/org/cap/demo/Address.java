package org.cap.demo;

import java.util.Scanner;

public class Address {
	
	private int doorNo;
	private String stName;
	private String city;
	private String state;
	private String pincode;
	
	public Address(){}
	
	
	public Address(int doorNo, String stName) {
		super();
		this.doorNo = doorNo;
		this.stName = stName;
	}





	public Address(int doorNo, String stName, String city, String state, String pincode) {
		this.doorNo = doorNo;
		this.stName = stName;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
	}





	public void getAddress(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter doorNo:");
		doorNo=sc.nextInt();
		System.out.println("Enter stName:");
		stName=sc.next();
		System.out.println("Enter city:");
		city=sc.next();
		System.out.println("Enter state:");
		state=sc.next();
		System.out.println("Enter Pincode:");
		pincode=sc.next();
		
		
	}
	
	public String printAddress(){
	return doorNo +"," + stName +"," + "\n" + city +"," +
				"\n" + state +"-" + pincode; 
	}
	

}
