package org.cap.demo;

public class MainClass {

	public static void main(String[] args) {
		Customer customer=new Customer();
		customer.getCustomer();
		customer.printCustomer();
		
		
		
		
		/*String cName="Jack";
		int cNo=1001;
		double regFees=2300;
		
		String stName="XYZ ST",city="Hyderabad",state="Andra",pincode="234324";
		int dNo=23;
		
		Address address=new Address(dNo, stName, city, state, pincode);
		
		
		Customer customer2=new Customer(cNo, cName, regFees,address );
		customer2.printCustomer();
		
*/
	}

}
