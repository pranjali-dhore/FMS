package org.capgemini;

public class Employee {
	//instance Variable
	int empId;
	String firstName,lastName;
	//static variable
	static int compId=1001;
	
	
	static
	{
		System.out.println("Company Id:" + compId);
		System.out.println("Employee Class Static Block");
	}
	
	
	
	
	public void printEmployee(){
		System.out.println("Id:" + empId + "\tFirstName:" + firstName +
				"\tLastName:" + lastName + "\tCompanyId:" + compId);
	}
	
	
	
	
	public static void myMethod(){
		//local variable
		int count=0;
		
		System.out.println("Static Method");
		System.out.println("Company Id:" + compId);
		System.out.println("Count:" + count);
	//	System.out.println("Id:" + empId );
	}

}
