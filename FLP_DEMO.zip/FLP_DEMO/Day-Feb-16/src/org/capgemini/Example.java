package org.capgemini;

public class Example {
	
	public void myMethod(int ... args){
		
		for(int i=0;i<args.length;i++)
			System.out.println(args[i]);
		
		/*for(int element : args)
			System.out.println(element);*/
	}
	
	public void myMethod(String myName,int ... args){
		
		System.out.println("Name :" +myName);
		 
		for(int element : args)
			System.out.println(element);
	}
	
	public void myMethod(int  args,String ... myName){
		
		System.out.println("Name :" +myName);
		 
		//for(int element : args)
			System.out.println(args);
	}
	
public void myMethod(int[]  args,String ... myName){
		
		System.out.println("Name :" +myName);
		 
		//for(int element : args)
			System.out.println(args);
	}
	
	
	public static void main(String[] args) {
		
		Example example=new Example();
		example.findArea(3.14f, 3.5f);
		
		/*example.myMethod(12,40,50,70);
		example.myMethod(12,40,50,70,90,100);
		//example.myMethod(129);
		
		example.myMethod("Tom", 1,2,3,45,55);*/
	}

	
	
	
	public void findArea( float PI, float radius){
		PI=1.3f;
		System.out.println("Area : " + PI * radius*radius);
	}
	
	
	
	
	
	
	
	
	
	
	
	

	/*public static void main(String ... args) {
		
		Example example=new Example();
		example.myMethod(12,40,50,70);
		example.myMethod(12,40,50,70,90,100);
		//example.myMethod(129);
		
		example.myMethod("Tom", 1,2,3,45,55);
	}*/

}
