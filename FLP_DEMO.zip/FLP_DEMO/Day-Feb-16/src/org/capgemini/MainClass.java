package org.capgemini;

public class MainClass {

	public static void main(String[] args) {
		Student student=new Student();
		student.printStudentDetails();
		
		Student stud=new Student(123, "Ram", "Singh", 1200);
		stud.printStudentDetails();
		
		Student stud1=new Student(190, "Jack");
		stud1.printStudentDetails();
		
		Student stud2=new Student(1890, "Emi","Jack");
		stud2.printStudentDetails();
		
		
		Student student2=new Student(stud2);
		student2.printStudentDetails();
		

	}

}
