package org.cap;

public class MainClass {

	public static void main(String[] args) {
		Employee employee=new Employee();
		employee.getDetails();
		employee.printEmployee();
	}

}
