package org.cap;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DemoFormat {

	public static void main(String[] args) {
		
		Date myDate=new Date();
		
		System.out.println(myDate);
		
		
	//SimpleDateFormat myFormat=new SimpleDateFormat("dd-MMM-yyyy G HH:mm:ss E");
	SimpleDateFormat myFormat=new SimpleDateFormat("dd-MM-yyyy");
	String myDateFormat=myFormat.format(myDate);
	
	System.out.println(myDateFormat);
	

	}

}
