package org.cap;

import java.util.Scanner;

public class Employee {
	
	private String kinId;
	private String name;
	
	
	public void getDetails(){
		Scanner sc=new Scanner(System.in);
		boolean flag;
		
		do{
			System.out.println("Enter KinID:");
			kinId=sc.next();
			
			flag=Validation.isValidKinid(kinId);
			if(!flag)
				System.out.println("InValid KinId. Please try Again!");
			/*if(Validation.isValidKinid(kinId)){
				System.out.println("Valid Id");
			}else
				System.out.println("InValid Id");*/
		}while(!flag);
		
		
		

		do{
			System.out.println("Enter Name:");
			name=sc.next();
			
			flag=Validation.isValidName(name);
			if(!flag)
				System.out.println("InValid Name. Please try Again!");
			/*if(Validation.isValidKinid(kinId)){
				System.out.println("Valid Id");
			}else
				System.out.println("InValid Id");*/
		}while(!flag);
		
	}

	
	public void printEmployee(){
		System.out.println(kinId + "--"+ name);
	}
	
	
	
	
}
