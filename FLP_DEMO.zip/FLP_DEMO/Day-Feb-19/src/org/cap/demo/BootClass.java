package org.cap.demo;

public class BootClass {

	public static void main(String[] args) {
		
		UserInteraction interaction=new UserInteraction();
		Employee emp=interaction.getEmployee();
		
		System.out.println(emp);
		

	}

}
