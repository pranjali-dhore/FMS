package org.capgemini;

public class Customer extends Person{

	private double regFees;
	private String contactNo;
	
	public Customer(){
		System.out.println("Customer-No Arg");
	}

	public Customer(double regFees, String contactNo) {
		
		
		System.out.println("Customer-Overloaded Constructor");
		this.regFees = regFees;
		this.contactNo = contactNo;
	}
	
		public Customer(int personId,String firstName,double regFees, String contactNo) {
			//super(personId,firstName);
			this();
		System.out.println("Customer-Overloaded Constructor");
		
		this.regFees = regFees;
		this.contactNo = contactNo;
	}
		@Override
		public void show(){
			super.show();
			System.out.println("Customer - Show method");
		}
		
	
}
