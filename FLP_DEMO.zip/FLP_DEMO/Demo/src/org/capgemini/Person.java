package org.capgemini;

public class Person {
	private int personId;
	private String firstName;
	
	public Person(){
		System.out.println("Person-No Arg");
	}

	
	public Person(int personId,String firstName){
		System.out.println("PErson-Overloaded Constructor");
		this.personId=personId;
		this.firstName=firstName;
	}
	
	
	public void show(){
		System.out.println("Person - Show method");
	}
	
}
