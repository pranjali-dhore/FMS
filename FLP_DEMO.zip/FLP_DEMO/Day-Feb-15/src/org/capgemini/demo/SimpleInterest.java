package org.capgemini.demo;

import java.util.Scanner;

public class SimpleInterest {
	
	double principle=12000;
	float int_rate=3.5f;
	float no_of_years=5.6f;
	
	
	public void getInput(){
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Principle:");
		principle=sc.nextDouble();
		
		System.out.println("Enter Rate of interest:");
		int_rate=sc.nextFloat();
		
		System.out.println("Enter no_of_years:");
		no_of_years=sc.nextFloat();
	}
	
	
	/*public void findSimpleInterest(){
		
	}*/
	
	public double findSimpleInterest(){
		return principle*int_rate*no_of_years;
	}

	public double findSimpleInterest(double principle){
		return principle*int_rate*no_of_years;
	}
	
	public double findSimpleInterest(double principle,float int_rate){
		return principle*int_rate*no_of_years;
	}
	
	
	public static void main(String[] args) {
		
		SimpleInterest simpleInterest=new SimpleInterest();
		//simpleInterest.getInput();
		System.out.println("INterest :" + simpleInterest.findSimpleInterest());
		System.out.println("INterest :" + simpleInterest.findSimpleInterest(4500));
		System.out.println("INterest :" + simpleInterest.findSimpleInterest(23400,6.5f));

	}

}













