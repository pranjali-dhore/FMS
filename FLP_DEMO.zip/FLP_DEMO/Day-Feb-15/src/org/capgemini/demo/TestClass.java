package org.capgemini.demo;

public class TestClass {

	public static void main(String[] args) {
	
		Person person=new Person();
		person.getPersonDetails();
		person.printPersonDetails();

	}

}
