package org.capgemini.demo;

import java.util.Scanner;

public class Employee {
	
	//instance variable
	private int empId;
	
	public String firstName;
	
	protected String lastName;
	
	double salary;
	
	
	
	public void getEmployee(){
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee Id:");
		empId=sc.nextInt();
		
		System.out.println("Enter FirstName:");
		firstName=sc.next();
		
		System.out.println("Enter lastName:");
		lastName=sc.next();
		
		System.out.println("Enter Salary:");
		salary=sc.nextDouble();
		
	}
	
	
	
	public void printEmployee(){
		System.out.println("Id:" + empId + "\nFirstName:" + firstName + "\nLastName:"
				+lastName + "\nSalary :" +salary);
	}
	
	
	
	public int getEmpId(){
		return empId;
	}
	

}
 