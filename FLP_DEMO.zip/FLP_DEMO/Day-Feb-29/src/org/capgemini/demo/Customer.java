package org.capgemini.demo;

public class Customer implements Comparable<Customer>{
	private int custId;
	private String custName;
	private double regFees;
	
	public Customer(){}
	
	
	public Customer(int custId, String custName, double regFees) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.regFees = regFees;
	}


	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public double getRegFees() {
		return regFees;
	}
	public void setRegFees(double regFees) {
		this.regFees = regFees;
	}

	
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + custId;
		result = prime * result + ((custName == null) ? 0 : custName.hashCode());
		long temp;
		temp = Double.doubleToLongBits(regFees);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (custId != other.custId)
			return false;
		if (custName == null) {
			if (other.custName != null)
				return false;
		} else if (!custName.equals(other.custName))
			return false;
		if (Double.doubleToLongBits(regFees) != Double.doubleToLongBits(other.regFees))
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", regFees=" + regFees + "]";
	}


	@Override
	public int compareTo(Customer cust) {
		if(this.getCustId()>cust.getCustId())
			return 1;
		else if(this.custId<cust.getCustId())
			return -1;
		else
			return 0;
		
	/*	if(this.getCustName().compareTo(cust.getCustName())>0)
			return -1;
		else if(this.getCustName().compareTo(cust.getCustName())<0)
			return 1;
		else
			return 0;*/
	}
	
	
	
}













