package org.capgemini.demo;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class MainClass {

	public static void main(String[] args) {
		LinkedHashSet<Employee> employees=new LinkedHashSet<>();
		
		employees.add(new Employee(1,"Tom","Jerry",2300));
		employees.add(new Employee(2,"JAck","Thomson",2500));
		employees.add(new Employee(1,"Tom","Jerry",2300));
		employees.add(new Employee(2,"JAck","Thomson",2500));
		employees.add(new Employee(1,"Tom","Jerry",2300));
	employees.add(null);
	employees.add(null);
	
	
	
	Iterator<Employee> it=employees.iterator();
	while(it.hasNext())
		System.out.println(it.next());
	
			
	}

}
