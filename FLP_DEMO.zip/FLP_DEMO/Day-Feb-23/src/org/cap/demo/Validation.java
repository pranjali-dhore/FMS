package org.cap.demo;

public class Validation {

	public static boolean isValidSalary(double salary)throws InvalidSalaryException{
		if(salary>=2000 && salary<=50000)
			return true;
		else
		{
			throw new InvalidSalaryException("Invalid Salary!");
		}
	}
}
