package org.capgemini.demo;

public class MyClass<T extends A> {

	private T obj;
	
	public MyClass(T obj){
		this.obj=obj;
	}
	
	public void printClass(){
		System.out.println(obj.getClass().getName());
		obj.show();
	}
	
}
