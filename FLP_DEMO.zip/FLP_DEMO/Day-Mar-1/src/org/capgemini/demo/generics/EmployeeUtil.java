package org.capgemini.demo.generics;

public class EmployeeUtil<T extends Employee> {

	private T empobj;
	
	public T getempObj(){
		return empobj;
	}
	
	public EmployeeUtil(T empobj){
		this.empobj=empobj;
	}
	
	public void printClass(){
		System.out.println(empobj.getClass().getName());
	}
	
	
	public void compareSalary(EmployeeUtil<?> emp){
		if(empobj.getSalary()==emp.getempObj().getSalary())
			System.out.println("Equal");
		else
			System.out.println("UnEqual");
	}
	
	
}
