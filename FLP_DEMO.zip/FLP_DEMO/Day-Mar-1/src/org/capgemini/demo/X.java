package org.capgemini.demo;

public class X implements InterA{

	@Override
	public void show() {
		System.out.println("X class Method");
		
	}

}
