package org.capgemini.demo;

public class B extends A{
	public void show(){
		System.out.println("B class Method");
	}
}
