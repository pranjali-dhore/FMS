package org.capgemini.demo;

public class C extends B{
	public void show(){
		System.out.println("C class Method");
	}
}
