package org.capgemini.demo;

public class Circle<T,U> {
	
	private T obj;
	private U obj2;
	
	public Circle(T obj,U obj2){
		this.obj=obj;
		this.obj2=obj2;
	}
	
	public void showInfo(){
		System.out.println("T -->"+ obj + obj.getClass().getName());
		System.out.println("U -->"+ obj2 + obj2.getClass().getName());
	}
	
	
	
}
