package org.capgemini.demo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class TestArryList {

	public static void main(String[] args) {
		
		//Collection lst=new ArrayList();
		//List lst=new ArrayList();
		//ArrayList<Integer> lst=new ArrayList<Integer>();
		ArrayList<Integer> lst=new ArrayList<>();//jdk 1.7
		lst.add(23);
		lst.add(100);
		lst.add(100);
		/*lst.add(1000042432432l);
		lst.add("Tom");
		lst.add('V');
		lst.add(34.56);
		lst.add("Tom");
		lst.add(3.5f);*/
		lst.add(null);
		//lst.add("Tom");
		lst.add(null);
		lst.add(null);
		lst.add(100);
		
		System.out.println(lst);
		
		

		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
